import { GoogleGenAI, Type } from "@google/genai";
import type { IntelItem, NewsItem, Operator, FootfallData, Requirement, TeamMember, ChatMessage, PotentialMatch } from '../types';
import { searchGoogleNews, searchGoogle } from './serpApiService';

const API_KEY = process.env.API_KEY;

// We do not throw here to allow the app to load and show a UI error if key is missing
const ai = API_KEY ? new GoogleGenAI({ apiKey: API_KEY }) : null;

const DEMO_MODE_ITEM: IntelItem = {
    id: `mock-error-${Date.now()}`,
    timestamp: new Date().toISOString(),
    source: 'System Alert',
    sourceCategory: 'General',
    headline: 'API Key Error or Quota Exceeded - DEMO DATA',
    summary: 'The system could not connect to a live data service. This is likely due to a missing/invalid SerpAPI key in Settings, or reaching a free daily usage limit. Displaying a sample item. Real-time data will resume once a valid key is provided.',
    url: '#',
    triggerKeywords: ['API Error', 'Demo Mode'],
    confidenceScore: 99,
    propertyType: 'Retail',
    sizeSqFt: 1500,
};


const extractJson = (text: string): string => {
    const match = text.match(/```(json)?([\s\S]*?)```/);
    if (match && match[2]) {
        return match[2].trim();
    }
    // Fallback for cases where Gemini doesn't use markdown
    const firstBrace = text.indexOf('{');
    const firstBracket = text.indexOf('[');
    const lastBrace = text.lastIndexOf('}');
    const lastBracket = text.lastIndexOf(']');
    
    let startIndex = -1;
    let endIndex = -1;
    
    // Prioritize array if it's the outermost structure
    if (firstBracket !== -1 && (firstBrace === -1 || firstBracket < firstBrace)) {
        startIndex = firstBracket;
        endIndex = lastBracket;
    } else if (firstBrace !== -1) {
        startIndex = firstBrace;
        endIndex = lastBrace;
    }

    if (startIndex !== -1 && endIndex > startIndex) {
        return text.substring(startIndex, endIndex + 1);
    }

    return text; // Return as-is if no JSON structure is found
};


export const generateIntel = async (serpApiKey: string): Promise<IntelItem[]> => {
    if (!ai) return [DEMO_MODE_ITEM];
    
    const searchQueries = [
        `"prime retail unit to let" "london" site:savills.co.uk`,
        `"restaurant property for lease" "manchester" site:cbre.co.uk`,
        `"company administration" "retail" site:thegazette.co.uk`,
        `"new instruction" "leisure property" site:knightfrank.co.uk`,
        `"Shaftesbury Capital" "new leasing opportunity"`,
        `"Landsec" "retail space available"`,
    ];

    try {
        const searchPromises = searchQueries.map(q => searchGoogleNews(serpApiKey, q));
        const searchResults = await Promise.allSettled(searchPromises);

        let rawIntel = '';
        searchResults.forEach(result => {
            if (result.status === 'fulfilled' && result.value?.news_results) {
                result.value.news_results.forEach((item: any) => {
                    rawIntel += `Source: ${item.source}\nTitle: ${item.title}\nLink: ${item.link}\nSnippet: ${item.snippet}\nDate: ${item.date}\n\n`;
                });
            }
        });

        if (!rawIntel) {
            console.warn("SerpAPI returned no news results for any of the intel queries.");
            return [];
        }

        const prompt = `
            You are an elite UK commercial property intelligence data aggregator.
            TASK: Analyze the following raw data from a news search and extract up to 10 unique, structured intelligence items.

            RAW DATA:
            ---
            ${rawIntel}
            ---

            CRITICAL FILTERS:
            1.  Property Types: ONLY include 'Retail', 'Leisure', 'F&B', 'Gyms', 'Nurseries'.
            2.  EXCLUSION: DO NOT include any 'Office' space.
            3.  URL VERIFICATION: The 'url' MUST be the direct link provided in the raw data.
            4.  Size: Extract or realistically estimate the size in sq ft if mentioned. It must be between 400 and 25,000 sq ft.
            5.  Categorization: Set 'sourceCategory' to 'Distress' if keywords like 'administration', 'insolvency', 'liquidation' are present. Otherwise, 'General'.

            For each item, create a structured JSON object.
            -   'id' must be a unique string.
            -   'timestamp' must be in ISO 8601 format.
            -   Assign a confidence score from 40-95 based on data quality.
            -   Return a JSON array enclosed in a markdown code block. If no valid items are found, return an empty array.
        `;
        
        const response = await ai.models.generateContent({ model: "gemini-2.5-flash", contents: prompt });

        const jsonText = extractJson(response.text);
        const parsedData = JSON.parse(jsonText);

        if (!Array.isArray(parsedData)) {
            return [];
        }
        
        return parsedData.map((item: any, idx: number) => ({
            ...item,
            id: `gen-${Date.now()}-${idx}`,
            timestamp: new Date().toISOString(),
            sizeSqFt: item.sizeSqFt ?? 0,
        }));

    } catch (error) {
        console.error("Error generating intel with Gemini/SerpAPI:", error);
        return [DEMO_MODE_ITEM];
    }
};

export const generateIndustryNews = async (serpApiKey: string): Promise<NewsItem[]> => {
    if (!ai) return [];

    const sites = ['propelinfonews.com', 'bighospitality.co.uk', 'mca-insight.com'];
    const keywords = '(new restaurant opening OR expansion OR market trend OR administration)';

    try {
        const searchPromises = sites.map(site => {
            const query = `${keywords} site:${site}`;
            // 'qdr:w' is the parameter for "query date range: week"
            return searchGoogleNews(serpApiKey, query, 'qdr:w');
        });

        const searchResults = await Promise.allSettled(searchPromises);

        let rawNews = '';
        searchResults.forEach(result => {
            if (result.status === 'fulfilled' && result.value?.news_results) {
                result.value.news_results.slice(0, 5).forEach((item: any) => {
                    rawNews += `Source: ${item.source}\nTitle: ${item.title}\nLink: ${item.link}\nSnippet: ${item.snippet}\nDate: ${item.date}\n\n`;
                });
            }
        });

        if (!rawNews) {
            console.warn("SerpAPI returned no news results for industry news queries.");
            return [];
        }
        
        const prompt = `
            You are a senior editor for a UK trade publication.
            TASK: Analyze the following raw news snippets and extract up to 6 of the MOST RECENT and unique structured news items.
            
            RAW DATA:
            ---
            ${rawNews}
            ---

            RULES:
            - Create a concise, professional summary of 2-3 sentences.
            - Extract 2-3 relevant tags (e.g., "New Entrant", "UK Expansion", "Market Trend").
            - The 'url' MUST be the direct link provided.
            - Return your response as a JSON array inside a markdown code block.
        `;

        const response = await ai.models.generateContent({ model: "gemini-2.5-flash", contents: prompt });
        
        const jsonText = extractJson(response.text.trim());
        const parsedData = JSON.parse(jsonText);

        if (!Array.isArray(parsedData)) {
            return [];
        }

        return parsedData.map((item: any, idx: number) => ({
             ...item,
            id: `news-${Date.now()}-${idx}`,
            timestamp: new Date().toISOString(),
        }));

    } catch (error) {
        console.error("Error generating industry news with Gemini/SerpAPI:", error);
        // The error is caught here, but the JSONP script error is likely what the user sees in the console.
        // This change should prevent that script error from happening in the first place.
        return [];
    }
};

export const assessOperatorRisk = async (operators: Operator[], serpApiKey: string): Promise<Operator[]> => {
    if (!ai) return operators;

    try {
        const riskAssessments = await Promise.all(operators.map(async (op) => {
            const query = `"${op.name}" financial results OR store closures OR administration "last 3 months"`;
            const serpResult = await searchGoogleNews(serpApiKey, query);
            
            let rawNews = 'No recent news found.';
            if (serpResult?.news_results) {
                rawNews = serpResult.news_results.slice(0, 5).map((item: any) => `Title: ${item.title}\nSnippet: ${item.snippet}`).join('\n\n');
            }

            const prompt = `
                You are a financial risk analyst. Based on the following news snippets for "${op.name}", assign a 'distressScore' from 0 (healthy) to 100 (in administration) and provide a one-sentence 'riskSummary'.
                
                If the news is positive (expansion, profits), score below 20.
                If neutral or no news, score between 20-40.
                If there are signs of trouble (closures, warnings), score 40-70.
                If administration/insolvency is mentioned, score 70-100.

                NEWS FOR ${op.name}:
                ---
                ${rawNews}
                ---

                Respond in a pure JSON object format: {"distressScore": number, "riskSummary": "string"}. No other text.
            `;
            const response = await ai.models.generateContent({ model: 'gemini-2.5-flash', contents: prompt });
            
            const jsonText = extractJson(response.text);
            const assessment = JSON.parse(jsonText);

            return {
                ...op,
                distressScore: assessment.distressScore,
                riskSummary: assessment.riskSummary,
                lastRiskCheck: new Date().toISOString(),
            };
        }));
        return riskAssessments;

    } catch (error) {
        console.error("Operator Risk API Error:", error);
        return operators;
    }
};

export const analyzeSocialIntel = async (text: string): Promise<IntelItem> => {
    if (!ai) throw new Error("API Key not found.");

    const prompt = `
      You are an expert commercial property analyst. Analyze the following text (likely from a LinkedIn post or other social/portal source) and extract a single, structured intelligence item.
      TEXT: "${text}"

      RULES:
      - Find the location, property type, and size.
      - Create a concise headline.
      - Write a brief summary.
      - Identify trigger keywords.
      - Assign a confidence score (40-95).
      - Set 'source' to "Manual Input / Social".
      - Set 'sourceCategory' to "Social".
      
      OUTPUT: Return ONLY a single, pure JSON object. No markdown, no text. If you can't find a property, return a JSON object with a headline indicating failure.
    `;
    try {
        const response = await ai.models.generateContent({ model: "gemini-2.5-flash", contents: prompt });
        const jsonText = extractJson(response.text);
        const parsed = JSON.parse(jsonText);
        
        return {
            ...parsed,
            id: `social-${Date.now()}`,
            timestamp: new Date().toISOString(),
            source: 'Manual Input / Social',
            sourceCategory: 'Social',
            url: '#',
        };
    } catch (e) {
        console.error("Social Intel Parse Error:", e);
        throw new Error("Failed to parse social intel.");
    }
};

// FIX: Add getFootfallAnalysis function
export const getFootfallAnalysis = async (headline: string, propertyType: string): Promise<FootfallData> => {
    if (!ai) throw new Error("API Key not found.");

    const prompt = `
        Analyze the footfall and local demographics for a commercial property located at or near "${headline}".
        The property is a "${propertyType}".
        
        Perform a live Google Search to find:
        1.  Typical weekday and weekend footfall estimates for the immediate area (e.g., high street, shopping centre).
        2.  The density of competing and complementary business categories nearby (e.g., other restaurants, retail shops, offices, residential).
        3.  The year-on-year (YoY) footfall variance for the area if available.
        4.  The primary data source for your footfall estimates.
        5.  The date of the data source.

        Return your findings as a pure JSON object, with no markdown. The object must conform to this structure:
        {
          "weekdayAverage": number,
          "weekendAverage": number,
          "categoryDensity": { "Retail": number, "F&B": number, "Offices": number, "Residential": number },
          "yoyVariance": number,
          "dataSource": "string",
          "lastUpdated": "string"
        }
    `;

    try {
        const response = await ai.models.generateContent({
            model: "gemini-2.5-pro",
            contents: prompt,
            config: {
                tools: [{ googleSearch: {} }],
            },
        });

        const jsonText = extractJson(response.text);
        return JSON.parse(jsonText);
    } catch (e) {
        console.error("Footfall Analysis Error:", e);
        throw new Error("Failed to analyze footfall data.");
    }
};

// FIX: Add generateEmailDraft function
export const generateEmailDraft = async (intel: IntelItem, operator: Operator, requirement: Requirement, currentUser: TeamMember): Promise<string> => {
    if (!ai) throw new Error("API Key not found.");
    const prompt = `
        You are an experienced acquisitions surveyor named ${currentUser.name} from Acquire Commercial.
        Draft a professional, concise, and compelling introductory email to a property agent about a potential opportunity.

        CONTEXT:
        - Your Company: Acquire Commercial
        - Your Name: ${currentUser.name}
        - Your Title: ${currentUser.title}
        - Your Email: ${currentUser.email}
        - Operator You Represent: ${operator.name}
        - The Property of Interest: "${intel.headline}", a ${intel.sizeSqFt} sq ft ${intel.propertyType} unit.
        - Operator's Requirement: Looking for ${requirement.sizeMin}-${requirement.sizeMax} sq ft units in ${requirement.locations.join(', ')}.
        - Source of Intel: You found this via your internal market intelligence platform. Do not mention the source name (${intel.source}). Refer to it as "market data".

        TASK:
        Write an email draft.
        - The email should be polite, direct, and show you've done your research.
        - It should state your interest on behalf of your retained client (${operator.name}).
        - Ask for more details (e.g., a marketing brochure, quoting terms).
        - Suggest a call or a viewing.
        - Format the output cleanly, starting with a "Subject Line:".
    `;

    try {
        const response = await ai.models.generateContent({ model: 'gemini-2.5-flash', contents: prompt });
        return response.text.trim();
    } catch (e) {
        console.error("Email Draft Error:", e);
        throw new Error("Failed to generate email draft.");
    }
};

// FIX: Add generateInvestmentMemo function
export const generateInvestmentMemo = async (intel: IntelItem, operator: Operator, requirement: Requirement): Promise<string> => {
    if (!ai) throw new Error("API Key not found.");
    const prompt = `
        You are a senior investment analyst at a commercial property firm.
        Generate a concise, structured investment memo for an internal committee.

        PROPERTY DETAILS:
        - Address/Headline: ${intel.headline}
        - Property Type: ${intel.propertyType}
        - Size: ${intel.sizeSqFt} sq ft
        - Use Class: ${intel.useClass || 'Not specified'}
        - Source: ${intel.source}
        - Summary: ${intel.summary}

        MATCH DETAILS:
        - Potential Tenant (Operator): ${operator.name}
        - Operator Category: ${operator.category}
        - Operator Requirement Fit: The operator is seeking ${requirement.sizeMin}-${requirement.sizeMax} sq ft units in ${requirement.locations.join(', ')}.

        TASK:
        Write the investment memo. Structure it with the following markdown headings:
        1.  **## Executive Summary:** A brief two-sentence overview of the opportunity.
        2.  **## Property Overview:** Key details of the property.
        3.  **## Tenant Rationale:** Why ${operator.name} is a strong fit for this location and property.
        4.  **## Strategic Fit:** How this property aligns with the operator's known expansion requirements.
        5.  **## Initial Risks & Mitigations:** Identify 2-3 potential risks (e.g., competition, planning, condition) and suggest next steps to mitigate them.
        6.  **## Recommendation:** Conclude with a clear recommendation (e.g., "Proceed to preliminary due diligence and schedule a viewing.").
    `;

    try {
        const response = await ai.models.generateContent({ model: 'gemini-2.5-pro', contents: prompt });
        return response.text.trim();
    } catch (e) {
        console.error("Investment Memo Error:", e);
        throw new Error("Failed to generate investment memo.");
    }
};

// FIX: Add generateRequirementsBroadcastEmail function
export const generateRequirementsBroadcastEmail = async (requirements: Requirement[], operators: Operator[], currentUser: TeamMember): Promise<string> => {
    if (!ai) throw new Error("API Key not found.");

    const requirementsText = requirements.map(r => {
        const op = operators.find(o => o.id === r.operatorId);
        return `- **${op ? op.name : 'Unknown Operator'}:** Seeking ${r.sizeMin.toLocaleString()}-${r.sizeMax.toLocaleString()} sq ft in ${r.locations.join('/')}. Notes: ${r.notes}`;
    }).join('\n');

    const prompt = `
        You are ${currentUser.name}, ${currentUser.title} at Acquire Commercial.
        Draft a professional requirements circular to be sent to your network of property agents.

        YOUR DETAILS:
        - Name: ${currentUser.name}
        - Title: ${currentUser.title}
        - Email: ${currentUser.email}
        - Company: Acquire Commercial

        REQUIREMENTS TO INCLUDE:
        ${requirementsText}

        TASK:
        - Write a clear and concise email.
        - Start with a professional subject line.
        - Briefly introduce that you are circulating your clients' latest property requirements.
        - List the requirements clearly.
        - End with a call to action, asking agents to send suitable on and off-market opportunities.
        - Keep the tone professional and engaging.
    `;
    try {
        const response = await ai.models.generateContent({ model: 'gemini-2.5-flash', contents: prompt });
        return response.text.trim();
    } catch (e) {
        console.error("Broadcast Email Error:", e);
        throw new Error("Failed to generate broadcast email.");
    }
};

// FIX: Add getAIChatResponse function
export const getAIChatResponse = async (history: ChatMessage[], newMsg: string, context: string): Promise<string> => {
    if (!ai) return "The AI service is currently unavailable. Please check your API key in Settings.";

    const recentHistory = history.slice(-6).map(h => ({
        role: h.role,
        parts: [{ text: h.text }]
    }));
    
    const systemInstruction = `You are a helpful AI assistant for a commercial property acquisitions firm. Your name is "Radar".
    This is a summary of the current application state for your context, do not mention it unless asked:
    ---
    ${context}
    ---
    Keep your answers concise and relevant to commercial real estate. Use markdown for formatting.`;

    try {
        const chat = ai.chats.create({
            model: 'gemini-2.5-pro',
            config: {
                systemInstruction: systemInstruction,
            },
            history: recentHistory
        });

        const response = await chat.sendMessage({ message: newMsg });
        return response.text.trim();

    } catch (e) {
        console.error("AI Chat Error:", e);
        return "Sorry, I encountered an error. Please try again.";
    }
};

// FIX: Add searchProperties function
interface PropertySearchOptions {
    location: string;
    radius: string;
    type: string;
    minSize?: number;
    maxSize?: number;
    dateFilter: string;
}

export const searchProperties = async (serpApiKey: string, options: PropertySearchOptions): Promise<IntelItem[]> => {
    if (!ai) throw new Error("API Key not found.");

    let query = `"${options.type === 'All' ? 'commercial property' : options.type}" to let in "${options.location}"`;
    if (options.minSize) query += ` min ${options.minSize} sq ft`;
    if (options.maxSize) query += ` max ${options.maxSize} sq ft`;
    query += ` site:rightmove.co.uk OR site:loopnet.co.uk OR site:realla.co.uk`;

    let tbs = '';
    if (options.dateFilter === '24h') tbs = 'qdr:d';
    if (options.dateFilter === '7d') tbs = 'qdr:w';
    if (options.dateFilter === '30d') tbs = 'qdr:m';

    try {
        const searchResults = await searchGoogle(serpApiKey, query, options.location);
        
        let rawHtml = '';
        if(searchResults?.organic_results) {
             rawHtml = searchResults.organic_results.map((r: any) => 
                `Title: ${r.title}\nLink: ${r.link}\nSnippet: ${r.snippet}`
            ).join('\n\n---\n\n');
        }

        if(!rawHtml) return [];

        const prompt = `
            You are a property data extraction specialist.
            Analyze the following Google Search results for commercial property listings and extract structured data for up to 10 properties.

            SEARCH RESULTS:
            ---
            ${rawHtml}
            ---

            RULES:
            - Extract headline, summary, url, property type, use class (if mentioned), and size in sq ft.
            - If size is in sq m, convert it to sq ft (1 sqm = 10.764 sqft).
            - Infer the date listed from the snippet if possible (e.g., "2 days ago").
            - Try to extract agent details from the snippet.
            - Return a JSON array in a markdown code block.
        `;

        const response = await ai.models.generateContent({ model: "gemini-2.5-pro", contents: prompt });
        const jsonText = extractJson(response.text);
        const parsed = JSON.parse(jsonText);

        return parsed.map((item: any, idx: number) => ({
            ...item,
            id: `search-${Date.now()}-${idx}`,
            timestamp: new Date().toISOString(),
            sourceCategory: 'General',
            confidenceScore: 85,
        }));

    } catch (e) {
        console.error("Property Search Error:", e);
        throw new Error("Failed to search properties.");
    }
};

// FIX: Add findOperatorMatches function
export const findOperatorMatches = async (property: IntelItem, operators: Operator[], requirements: Requirement[]): Promise<PotentialMatch[]> => {
    if (!ai) throw new Error("API Key not found.");
    
    const context = `
        PROPERTY TO MATCH:
        - Headline: ${property.headline}
        - Type: ${property.propertyType}
        - Size: ${property.sizeSqFt} sq ft
        - Use Class: ${property.useClass || 'N/A'}
        - Summary: ${property.summary}

        OPERATOR REQUIREMENTS DATABASE:
        ${operators.map(op => {
            const req = requirements.find(r => r.operatorId === op.id);
            if (!req) return '';
            return `- Operator: ${op.name} (Category: ${op.category})\n  - Seeking: ${req.sizeMin}-${req.sizeMax} sq ft, Use Class: ${req.useClass}, Locations: ${req.locations.join(', ')}\n`;
        }).join('')}
    `;

    const prompt = `
        You are an AI property matching engine.
        Based on the provided property and operator database, identify the top 3 best-fit operators for the property.
        
        CONTEXT:
        ${context}

        For each of the top 3 matches, provide a confidence score (0-100) and a brief summary explaining *why* it's a good match (mentioning size, location, and use class alignment).

        Return a pure JSON array of objects with this structure:
        [
            {
                "operatorId": "string",
                "confidenceScore": number,
                "summary": "string"
            }
        ]
        If no good matches are found, return an empty array.
    `;
    
    try {
        const response = await ai.models.generateContent({ model: "gemini-2.5-pro", contents: prompt });
        const jsonText = extractJson(response.text);
        const results: {operatorId: string, confidenceScore: number, summary: string}[] = JSON.parse(jsonText);

        return results.map(res => {
            const operator = operators.find(o => o.id === res.operatorId);
            const requirement = requirements.find(r => r.operatorId === res.operatorId);
            if (!operator || !requirement) return null;
            // FIX: Reconstruct the object to match the PotentialMatch interface and fix the type predicate error.
            return {
                operator,
                requirement,
                confidenceScore: res.confidenceScore,
                summary: res.summary,
            };
        }).filter((match): match is PotentialMatch => match !== null);

    } catch (e) {
        console.error("Find Matches Error:", e);
        throw new Error("Failed to find operator matches.");
    }
};
