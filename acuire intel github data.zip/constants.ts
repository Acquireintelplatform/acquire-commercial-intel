import type { Operator, Requirement, Source, OperatorCategory, CategoryColorMap, Agent, TeamMember, Landlord } from './types';

export const OPERATOR_CATEGORY_COLORS: CategoryColorMap = {
    'Restaurant': { bg: 'bg-red-50', text: 'text-red-800', border: 'border-red-300', accent: 'bg-red-500' },
    'QSR': { bg: 'bg-orange-50', text: 'text-orange-800', border: 'border-orange-300', accent: 'bg-orange-500' },
    'Coffee': { bg: 'bg-amber-50', text: 'text-amber-800', border: 'border-amber-300', accent: 'bg-amber-500' },
    'Bakery': { bg: 'bg-yellow-50', text: 'text-yellow-800', border: 'border-yellow-300', accent: 'bg-yellow-500' },
    'Grocer': { bg: 'bg-lime-50', text: 'text-lime-800', border: 'border-lime-300', accent: 'bg-lime-500' },
    'Pubs': { bg: 'bg-green-50', text: 'text-green-800', border: 'border-green-300', accent: 'bg-green-500' },
    'Leisure': { bg: 'bg-cyan-50', text: 'text-cyan-800', border: 'border-cyan-300', accent: 'bg-cyan-500' },
    'Gyms': { bg: 'bg-sky-50', text: 'text-sky-800', border: 'border-sky-300', accent: 'bg-sky-500' },
    'Nursery': { bg: 'bg-violet-50', text: 'text-violet-800', border: 'border-violet-300', accent: 'bg-violet-500' },
    'Retail': { bg: 'bg-purple-50', text: 'text-purple-800', border: 'border-purple-300', accent: 'bg-purple-500' },
    'Mixed': { bg: 'bg-indigo-50', text: 'text-indigo-800', border: 'border-indigo-300', accent: 'bg-indigo-500' },
    'Default': { bg: 'bg-gray-50', text: 'text-gray-800', border: 'border-gray-300', accent: 'bg-gray-500' },
};

export const initialOperators: Operator[] = [
    { id: 'op-01', name: 'Nando’s', category: 'Restaurant', companyNumber: '02580031' },
    { id: 'op-02', name: 'Starbucks', category: 'Coffee', companyNumber: '02996151' },
    { id: 'op-03', name: 'Five Guys', category: 'QSR', companyNumber: '07817997' },
    { id: 'op-04', name: 'Tesco', category: 'Grocer', companyNumber: '00445790' },
    { id: 'op-05', name: 'Greggs', category: 'Bakery', companyNumber: '00621453' },
    { id: 'op-06', name: 'Pret A Manger', category: 'Coffee', companyNumber: '01854213' },
    { id: 'op-07', name: 'Costa Coffee', category: 'Coffee', companyNumber: '01270695' },
    { id: 'op-08', name: 'Subway', category: 'QSR' },
    { id: 'op-09', name: 'KFC', category: 'QSR' },
    { id: 'op-10', name: 'McDonald’s', category: 'QSR', companyNumber: '01076177' },
    { id: 'op-11', name: 'Burger King', category: 'QSR', companyNumber: '01622953' },
    { id: 'op-12', name: 'Pizza Express', category: 'Restaurant', companyNumber: '01405364' },
    { id: 'op-13', name: 'Wagamama', category: 'Restaurant', companyNumber: '02605381' },
    { id: 'op-14', name: 'Tortilla', category: 'QSR', companyNumber: '06132935' },
    { id: 'op-15', name: 'Itsu', category: 'QSR', companyNumber: '03288926' },
    { id: 'op-16', name: 'Leon', category: 'QSR', companyNumber: '04818788' },
    { id: 'op-17', name: 'Dishoom', category: 'Restaurant', companyNumber: '06231227' },
    { id: 'op-18', name: 'Popeyes', category: 'QSR' },
    { id: 'op-19', name: 'Wingstop', category: 'QSR' },
    { id: 'op-20', name: 'Black Sheep Coffee', category: 'Coffee', companyNumber: '08870142' },
    { id: 'op-21', name: 'Giggling Squid', category: 'Restaurant', companyNumber: '06813799' },
    { id: 'op-22', name: 'Honest Burgers', category: 'Restaurant', companyNumber: '07490279' },
    { id: 'op-23', name: 'PureGym', category: 'Gyms', companyNumber: '06690189' },
    { id: 'op-24', name: 'Greene King', category: 'Pubs', companyNumber: '03298903' },
    { id: 'op-25', name: 'Kids Planet', category: 'Nursery', companyNumber: '06699314' },
];

export const initialRequirements: Requirement[] = [
    { id: 'req-01', operatorId: 'op-01', sizeMin: 2500, sizeMax: 4000, locations: ['London', 'Manchester', 'Birmingham'], useClass: 'Class E', notes: 'High footfall, city centres.' },
    { id: 'req-02', operatorId: 'op-02', sizeMin: 1200, sizeMax: 2000, locations: ['High Streets', 'Travel Hubs'], useClass: 'Class E', notes: 'Corner units preferred.' },
    { id: 'req-03', operatorId: 'op-03', sizeMin: 2000, sizeMax: 3500, locations: ['Major Cities'], useClass: 'Class E', notes: 'Prominent locations, good visibility.' },
    { id: 'req-04', operatorId: 'op-04', sizeMin: 3000, sizeMax: 5000, locations: ['Nationwide'], useClass: 'Class E', notes: 'Express/Metro format.' },
    { id: 'req-05', operatorId: 'op-05', sizeMin: 800, sizeMax: 1500, locations: ['Nationwide'], useClass: 'Class E', notes: 'High street and transport locations.' },
    { id: 'req-06', operatorId: 'op-06', sizeMin: 1500, sizeMax: 2500, locations: ['London', 'Office Districts'], useClass: 'Class E', notes: 'High density of office workers.' },
    { id: 'req-18', operatorId: 'op-18', sizeMin: 1000, sizeMax: 3000, locations: ['London', 'Major Cities'], useClass: 'Class E', notes: 'Drive-thru sites are a key target.' },
    { id: 'req-19', operatorId: 'op-19', sizeMin: 1500, sizeMax: 2500, locations: ['Shopping Centres', 'Retail Parks'], useClass: 'Class E', notes: 'Focus on delivery catchments.' },
    { id: 'req-20', operatorId: 'op-20', sizeMin: 1000, sizeMax: 1800, locations: ['London', 'Manchester'], useClass: 'Class E', notes: 'Trendy, urban locations.' },
    { id: 'req-21', operatorId: 'op-21', sizeMin: 3000, sizeMax: 5000, locations: ['Affluent Towns', 'City Suburbs'], useClass: 'Class E', notes: 'Character buildings preferred.' },
    { id: 'req-22', operatorId: 'op-22', sizeMin: 1800, sizeMax: 3000, locations: ['London', 'Bristol', 'Brighton'], useClass: 'Class E', notes: 'Looking for sites with outdoor seating potential.' },
    { id: 'req-23', operatorId: 'op-23', sizeMin: 10000, sizeMax: 20000, locations: ['Nationwide'], useClass: 'Class E', notes: 'Large, open-plan spaces in retail parks or town centres.' },
    { id: 'req-24', operatorId: 'op-24', sizeMin: 3000, sizeMax: 6000, locations: ['Community Hubs', 'Suburban areas'], useClass: 'Sui Generis (Pub)', notes: 'Requires beer garden / outdoor space.' },
    { id: 'req-25', operatorId: 'op-25', sizeMin: 4000, sizeMax: 8000, locations: ['North West', 'Midlands'], useClass: 'Class E', notes: 'Must have secure outdoor play area and good parking.' },
];

export const initialAgents: Agent[] = [
    { id: 'ag-01', name: 'David Abramson', company: 'Cedar Dean', category: 'Restaurant', phone: '020 7100 7500', email: 'da@cedardean.com' },
    { id: 'ag-02', name: 'Tracey Mills', company: 'Davis Coffer Lyons', category: 'Restaurant', phone: '020 7299 0743', email: 'tmills@dcl.co.uk' },
    { id: 'ag-03', name: 'Victoria O\'Driscoll', company: 'Restaurant Property', category: 'Restaurant', phone: '020 7935 2222', email: 'victoria@restaurant-property.co.uk' },
    { id: 'ag-04', name: 'David Bell', company: 'Savills', category: 'Leisure', phone: '020 7409 8164', email: 'dbell@savills.com' },
    { id: 'ag-05', name: 'Paul Tallentyre', company: 'Davis Coffer Lyons', category: 'Pubs', phone: '020 7299 0740', email: 'ptallentyre@dcl.co.uk' },
    { id: 'ag-06', name: 'Richard Bruce', company: 'Bruce Gillingham Pollard', category: 'Retail', phone: '020 3551 5612', email: 'richard.bruce@brucegillinghampollard.com' },
    { id: 'ag-07', name: 'David Rawlinson', company: 'Restaurant Property', category: 'Restaurant', phone: '020 7935 2222', email: 'david@restaurant-property.co.uk' },
    { id: 'ag-08', name: 'Theo Benedyk', company: 'Shelley Sandzer', category: 'Mixed', phone: '020 7580 3366', email: 'theo@shelleysandzer.co.uk' },
    { id: 'ag-09', name: 'Camilla Topham', company: 'Shelley Sandzer', category: 'Restaurant', phone: '020 7580 3366', email: 'camilla@shelleysandzer.co.uk' },
    { id: 'ag-10', name: 'Phil Daniels', company: 'GCW', category: 'Retail', phone: '020 7647 4815', email: 'phil.daniels@gcw.co.uk' },
    { id: 'ag-11', name: 'David Shackleton', company: 'Cushman & Wakefield', category: 'Retail', phone: '020 7152 5299', email: 'david.shackleton@cushwake.com' },
    { id: 'ag-12', name: 'Nick Weir', company: 'Shelley Sandzer', category: 'Mixed', phone: '020 7580 3366', email: 'nick@shelleysandzer.co.uk' },
    { id: 'ag-13', name: 'Salvatore Di Natale', company: 'CDG Leisure', category: 'Restaurant', phone: '020 7100 5550', email: 'salvi@cdgleisure.com' },
    { id: 'ag-14', name: 'Tom Peasnell', company: 'CDG Leisure', category: 'Leisure', phone: '020 7100 5550', email: 'tom@cdgleisure.com' },
    { id: 'ag-15', name: 'George Oppenheim', company: 'CBRE', category: 'Retail', phone: '020 7182 2315', email: 'george.oppenheim@cbre.com' },
];

export const TRIGGER_KEYWORDS = ['closure', 'assignment', 'lease expiry', 'insolvency', 'administration', 'surrender', 'liquidation', 'opening', 'for sale', 'to let', 'under offer', 'tenant breaking', 'late filing', 'planning application', 'change of use'];

export const ALL_SOURCES: Source[] = [
    { name: 'EGI / Radius', category: 'Property Portal' },
    { name: 'CoStar', category: 'Property Portal' },
    { name: 'Realla', category: 'Property Portal' },
    { name: 'Rightmove Commercial', category: 'Property Portal' },
    { name: 'Zoopla Commercial', category: 'Property Portal' },
    { name: 'NovaLoca', category: 'Property Portal' },
    { name: 'LoopNet', category: 'Property Portal' },

    { name: 'The Crown Estate', category: 'Major Landlord / Transport Hub' },
    { name: 'Landsec', category: 'Major Landlord / Transport Hub' },
    { name: 'British Land', category: 'Major Landlord / Transport Hub' },
    { name: 'Shaftesbury Capital', category: 'Major Landlord / Transport Hub' },
    { name: 'Grosvenor Estate', category: 'Major Landlord / Transport Hub' },
    { name: 'Cadogan Estate', category: 'Major Landlord / Transport Hub' },
    { name: 'Howard de Walden Estate', category: 'Major Landlord / Transport Hub' },
    { name: 'The Portman Estate', category: 'Major Landlord / Transport Hub' },
    { name: 'Canary Wharf Group', category: 'Major Landlord / Transport Hub' },
    { name: 'Hammerson', category: 'Major Landlord / Transport Hub' },
    { name: 'SEGRO', category: 'Major Landlord / Transport Hub' },
    { name: 'Derwent London', category: 'Major Landlord / Transport Hub' },
    { name: 'Great Portland Estates', category: 'Major Landlord / Transport Hub' },
    { name: 'The Mercers\' Company', category: 'Major Landlord / Transport Hub' },
    { name: 'The Drapers\' Company', category: 'Major Landlord / Transport Hub' },
    { name: 'The Corporation of London', category: 'Major Landlord / Transport Hub' },
    { name: 'TfL Commercial Property', category: 'Major Landlord / Transport Hub' },
    { name: 'Network Rail Property', category: 'Major Landlord / Transport Hub' },
    { name: 'Westfield London (White City)', category: 'Major Landlord / Transport Hub' },
    { name: 'Westfield Stratford City', category: 'Major Landlord / Transport Hub' },
    { name: 'The O2, London', category: 'Major Landlord / Transport Hub' },
    { name: 'Heathrow Airport Retail', category: 'Major Landlord / Transport Hub' },
    { name: 'Gatwick Airport Retail', category: 'Major Landlord / Transport Hub' },
    { name: 'Manchester Arndale', category: 'Major Landlord / Transport Hub' },
    { name: 'Bullring & Grand Central, Birmingham', category: 'Major Landlord / Transport Hub' },
    { name: 'Westgate Oxford', category: 'Major Landlord / Transport Hub' },
    
    { name: 'CBRE', category: 'Property Agency' },
    { name: 'JLL', category: 'Property Agency' },
    { name: 'Savills', category: 'Property Agency' },
    { name: 'Cushman & Wakefield', category: 'Property Agency' },
    { name: 'Knight Frank', category: 'Property Agency' },
    { name: 'Colliers International', category: 'Property Agency' },
    { name: 'GCW', category: 'Property Agency' },
    { name: 'CDG Leisure', category: 'Property Agency' },
    { name: 'Bruce Gillingham Pollard', category: 'Property Agency' },
    { name: 'Restaurant Property', category: 'Property Agency' },
    { name: 'Davis Coffer Lyons', category: 'Property Agency' },
    { name: 'Shelley Sandzer', category: 'Property Agency' },

    { name: 'The Gazette', category: 'Distress Feed' },
    { name: 'Companies House', category: 'Distress Feed' },
    { name: 'Business Sale Report', category: 'Distress Feed' },
    { name: 'Insolvency Insider', category: 'Distress Feed' },

    { name: 'Propel Info', category: 'Industry News' },
    { name: 'Big Hospitality', category: 'Industry News' },
    { name: 'MCA Insight', category: 'Industry News' },
    { name: 'Hot Dinners', category: 'Industry News' },
    { name: 'Retail Gazette', category: 'Industry News' },
    { name: 'The Caterer', category: 'Industry News' },
    { name: 'Property Week', category: 'Industry News' },

    { name: 'The Requirement List', category: 'Expansion / Requirements' },
    { name: 'Nimbus Maps', category: 'Ownership / Mapping' },
    { name: 'Local Authority Planning Portals', category: 'Planning & Development' },
    { name: 'Google News Alerts', category: 'Supplementary' },
    { name: 'Twitter/X', category: 'Supplementary' },
];

// FIX: Add TEAM_MEMBERS constant
export const TEAM_MEMBERS: TeamMember[] = [
    { id: 'user-01', name: 'Alex Thompson', initials: 'AT', title: 'Acquisitions Director', email: 'alex.thompson@acquire.com' },
    { id: 'user-02', name: 'Ben Carter', initials: 'BC', title: 'Acquisitions Surveyor', email: 'ben.carter@acquire.com' },
];

// FIX: Add PROPERTY_TYPE_MAPPING constant
export const PROPERTY_TYPE_MAPPING: Record<string, OperatorCategory> = {
    'Restaurant': 'Restaurant',
    'F&B': 'Restaurant',
    'Retail': 'Retail',
    'Leisure': 'Leisure',
    'Gym': 'Gyms',
    'Gyms': 'Gyms',
    'Nursery': 'Nursery',
    'Pub': 'Pubs',
    'Pubs': 'Pubs',
    'Coffee': 'Coffee',
    'QSR': 'QSR',
    'Grocer': 'Grocer',
    'Bakery': 'Bakery',
    'Mixed': 'Mixed'
};

// FIX: Add initialLandlords constant
export const initialLandlords: Landlord[] = [
  { id: 'll-01', name: 'The Crown Estate', contactTeam: 'Central London Leasing', email: 'leasing@thecrownestate.co.uk', focusNotes: 'Regent Street, St James\'s. Prime retail and F&B.', lastUpdated: '2023-10-26' },
  { id: 'll-02', name: 'Landsec', contactTeam: 'Retail Asset Management', email: 'retail.leasing@landsec.com', focusNotes: 'Major shopping centres (Bluewater, Trinity Leeds) and London assets.', lastUpdated: '2023-10-25' },
  { id: 'll-03', name: 'Shaftesbury Capital', contactTeam: 'Leasing Team', email: 'leasing@shaftesburycapital.com', focusNotes: 'Covent Garden, Carnaby, Soho. Focus on unique, experience-led brands.', lastUpdated: '2023-11-01' },
  { id: 'll-04', name: 'Grosvenor Estate', contactTeam: 'Mayfair & Belgravia Leasing', email: 'london.leasing@grosvenor.com', focusNotes: 'Luxury retail and dining in Mayfair and Belgravia.', lastUpdated: '2023-09-15' },
  { id: 'll-05', name: 'Network Rail Property', contactTeam: 'Retail Leasing', email: 'retail@networkrail.co.uk', focusNotes: 'Major train stations across the UK. High footfall, travel-oriented retail.', lastUpdated: '2023-10-20' },
  { id: 'll-06', name: 'Transport for London (TfL)', contactTeam: 'Commercial Property', email: 'commercial@tfl.gov.uk', focusNotes: 'Retail units within London Underground stations and on TfL property.', lastUpdated: '2023-10-18' },
];
