
import React from 'react';
import type { NewsItem } from '../types';
import { ArrowPathIcon } from './icons/Icons';

interface IndustryNewsViewProps {
    newsItems: NewsItem[];
    isLoading: boolean;
    error: string | null;
    onRefresh: () => void;
}

const NewsCard: React.FC<{ item: NewsItem }> = ({ item }) => {
    return (
        <div className="bg-white rounded-lg shadow-md hover:shadow-xl transition-shadow duration-300 overflow-hidden border-l-4 border-brand-blue flex flex-col">
            <div className="p-5 flex-grow">
                <p className="text-sm text-gray-500">{new Date(item.timestamp).toLocaleDateString()}</p>
                <h3 className="text-lg font-bold text-brand-blue mt-1">{item.headline}</h3>
                <p className="text-gray-700 mt-3 text-sm">{item.summary}</p>
                <div className="mt-4 flex flex-wrap gap-2">
                    {item.tags.map(tag => (
                        <span key={tag} className="bg-indigo-100 text-indigo-800 text-xs font-semibold px-2.5 py-0.5 rounded-full">{tag}</span>
                    ))}
                </div>
            </div>
            <div className="bg-gray-50 px-5 py-3 flex justify-between items-center text-sm">
                <p className="text-gray-600">Source: <span className="font-semibold">{item.source}</span></p>
                <a href={item.url} target="_blank" rel="noopener noreferrer" className="text-brand-blue hover:text-brand-gold font-semibold transition-colors">
                    Read More &rarr;
                </a>
            </div>
        </div>
    );
};

export const IndustryNewsView: React.FC<IndustryNewsViewProps> = ({ newsItems, isLoading, error, onRefresh }) => {
    return (
        <div>
            <div className="flex justify-between items-center mb-6">
                <div>
                    <h2 className="text-3xl font-bold text-gray-800">Industry News</h2>
                    <p className="text-gray-600 mt-1">High-level market updates, trends, and breaking news.</p>
                </div>
                <button
                    onClick={onRefresh}
                    disabled={isLoading}
                    className="flex items-center bg-brand-blue text-white px-4 py-2 rounded-lg shadow hover:bg-brand-blue/90 transition-all duration-200 disabled:bg-gray-400 disabled:cursor-not-allowed"
                >
                    <ArrowPathIcon className={`w-5 h-5 mr-2 ${isLoading ? 'animate-spin' : ''}`} />
                    {isLoading ? 'Refreshing...' : 'Refresh All Data'}
                </button>
            </div>
            
            {error && (
                 <div className="bg-red-100 border border-red-400 text-red-700 px-4 py-3 rounded-md relative mb-6" role="alert">
                    <strong className="font-bold">Error: </strong>
                    <span className="block sm:inline">{error}</span>
                </div>
            )}
            
            {isLoading && newsItems.length === 0 && (
                 <div className="text-center py-10">
                    <p className="text-gray-600">Fetching the latest industry news...</p>
                 </div>
            )}

            {!isLoading && newsItems.length === 0 && !error && (
                 <div className="text-center py-10 bg-white rounded-lg shadow">
                    <h3 className="text-xl font-semibold text-gray-700">No News Available</h3>
                    <p className="text-gray-500 mt-2">Refresh the data to fetch the latest industry news.</p>
                 </div>
            )}

            <div className="grid grid-cols-1 lg:grid-cols-2 2xl:grid-cols-3 gap-6">
                {newsItems.map(item => (
                    <NewsCard key={item.id} item={item} />
                ))}
            </div>
        </div>
    );
};
