import React, { useState } from 'react';
import type { Requirement, Operator, Agent, TeamMember } from '../types';
import { OPERATOR_CATEGORY_COLORS } from '../constants';
import { PaperAirplaneIcon, DocumentTextIcon, PlusIcon } from './icons/Icons';
import { generateRequirementsBroadcastEmail } from '../services/geminiService';

interface RequirementsViewProps {
    requirements: Requirement[];
    setRequirements?: React.Dispatch<React.SetStateAction<Requirement[]>>;
    operators: Operator[];
    agents: Agent[];
    currentUser: TeamMember;
}

interface BroadcastModalProps {
    isOpen: boolean;
    onClose: () => void;
    content: string;
    isLoading: boolean;
    recipientCount: number;
    currentUser: TeamMember;
}

const BroadcastModal: React.FC<BroadcastModalProps> = ({ isOpen, onClose, content, isLoading, recipientCount, currentUser }) => {
    if (!isOpen) return null;

    return (
        <div className="fixed inset-0 bg-black bg-opacity-50 z-50 flex items-center justify-center p-4">
            <div className="bg-white rounded-lg shadow-2xl max-w-2xl w-full max-h-[80vh] flex flex-col">
                <div className="p-4 border-b bg-brand-blue text-white rounded-t-lg">
                    <div className="flex justify-between items-start">
                        <div>
                            <h3 className="text-lg font-bold flex items-center">
                                <PaperAirplaneIcon className="w-5 h-5 mr-2" />
                                Broadcast Requirements
                            </h3>
                            <p className="text-xs text-blue-200 mt-1">Sending to {recipientCount} registered agents (BCC)</p>
                        </div>
                        <div className="text-right">
                            <p className="text-xs text-blue-200">From</p>
                            <p className="text-sm font-bold">{currentUser.name}</p>
                        </div>
                    </div>
                </div>
                <div className="p-6 overflow-y-auto flex-grow">
                    {isLoading ? (
                        <div className="flex flex-col items-center justify-center h-40">
                            <div className="animate-spin rounded-full h-10 w-10 border-b-2 border-brand-gold"></div>
                            <p className="mt-4 text-gray-500">Generating circular email...</p>
                        </div>
                    ) : (
                        <div className="bg-gray-50 p-4 rounded border border-gray-200 font-mono text-sm whitespace-pre-wrap text-gray-800 leading-relaxed">
                            {content}
                        </div>
                    )}
                </div>
                <div className="p-4 border-t bg-gray-50 flex justify-end gap-3 rounded-b-lg">
                    <button onClick={onClose} className="px-4 py-2 text-gray-600 hover:bg-gray-200 rounded-md transition-colors">Cancel</button>
                    <button 
                        onClick={() => {
                            const subject = content.match(/Subject Line: (.*)/)?.[1] || "Acquire Commercial: Requirements Update";
                            const body = encodeURIComponent(content);
                            window.location.href = `mailto:?subject=${subject}&body=${body}`;
                        }} 
                        className="px-4 py-2 bg-brand-gold text-white font-bold rounded-md hover:bg-teal-500 shadow-sm transition-colors flex items-center disabled:opacity-50"
                        disabled={isLoading}
                    >
                        <DocumentTextIcon className="w-4 h-4 mr-2"/>
                        Open in Outlook
                    </button>
                </div>
            </div>
        </div>
    );
}

export const RequirementsView: React.FC<RequirementsViewProps> = ({ requirements, setRequirements, operators, agents, currentUser }) => {
    const [modalOpen, setModalOpen] = useState(false);
    const [emailContent, setEmailContent] = useState('');
    const [isLoading, setIsLoading] = useState(false);

    // Add Requirement Modal State
    const [isAddModalOpen, setIsAddModalOpen] = useState(false);
    const [newRequirement, setNewRequirement] = useState<Partial<Requirement>>({
        useClass: 'Class E'
    });
    const [selectedLocations, setSelectedLocations] = useState('');


    const getOperator = (operatorId: string): Operator | undefined => {
        return operators.find(op => op.id === operatorId);
    };

    const handleBroadcastClick = async () => {
        setModalOpen(true);
        setIsLoading(true);
        setEmailContent('');
        
        const draft = await generateRequirementsBroadcastEmail(requirements, operators, currentUser);
        
        setEmailContent(draft);
        setIsLoading(false);
    };

    const handleAddRequirement = (e: React.FormEvent) => {
        e.preventDefault();
        if (setRequirements && newRequirement.operatorId && newRequirement.sizeMin && newRequirement.sizeMax) {
            const locationsArray = selectedLocations.split(',').map(l => l.trim()).filter(l => l.length > 0);
            
            const reqToAdd: Requirement = {
                id: `req-${Date.now()}`,
                operatorId: newRequirement.operatorId,
                sizeMin: Number(newRequirement.sizeMin),
                sizeMax: Number(newRequirement.sizeMax),
                locations: locationsArray.length > 0 ? locationsArray : ['Nationwide'],
                useClass: newRequirement.useClass || 'Class E',
                notes: newRequirement.notes || ''
            };
            
            setRequirements(prev => [reqToAdd, ...prev]);
            setIsAddModalOpen(false);
            setNewRequirement({ useClass: 'Class E' });
            setSelectedLocations('');
        }
    };

    return (
         <div className="bg-white p-6 rounded-lg shadow-lg">
            <div className="flex justify-between items-center mb-6">
                <h2 className="text-3xl font-bold text-gray-800">Requirements Master</h2>
                <div className="flex gap-2">
                    {setRequirements && (
                        <button 
                            onClick={() => setIsAddModalOpen(true)}
                            className="flex items-center bg-white text-gray-700 border border-gray-300 px-4 py-2 rounded-lg shadow-sm hover:bg-gray-50 transition-colors"
                        >
                            <PlusIcon className="w-5 h-5 mr-2" />
                            Add Requirement
                        </button>
                    )}
                    <button 
                        onClick={handleBroadcastClick}
                        className="flex items-center bg-brand-gold text-white px-4 py-2 rounded-lg shadow hover:bg-teal-500 transition-all duration-200 font-bold"
                    >
                        <PaperAirplaneIcon className="w-5 h-5 mr-2" />
                        Broadcast to Agents
                    </button>
                </div>
            </div>
            
            <div className="overflow-x-auto">
                <table className="min-w-full bg-white">
                    <thead className="bg-teal-50 text-teal-800">
                        <tr>
                            <th className="text-left py-3 px-4 uppercase font-semibold text-sm">Operator</th>
                            <th className="text-left py-3 px-4 uppercase font-semibold text-sm">Size (sqft)</th>
                            <th className="text-left py-3 px-4 uppercase font-semibold text-sm">Target Locations</th>
                            <th className="text-left py-3 px-4 uppercase font-semibold text-sm">Use Class</th>
                            <th className="text-left py-3 px-4 uppercase font-semibold text-sm">Notes</th>
                        </tr>
                    </thead>
                    <tbody className="text-gray-700">
                        {requirements.map(req => {
                            const operator = getOperator(req.operatorId);
                            const color = operator ? (OPERATOR_CATEGORY_COLORS[operator.category] || OPERATOR_CATEGORY_COLORS.Default) : OPERATOR_CATEGORY_COLORS.Default;
                            return (
                                <tr key={req.id} className="border-b border-gray-200 hover:bg-gray-50">
                                    <td className="py-3 px-4 font-semibold">
                                        <div className="flex items-center">
                                            <span className={`w-3 h-3 rounded-full mr-3 ${color.accent}`}></span>
                                            {operator?.name || 'Unknown Operator'}
                                        </div>
                                    </td>
                                    <td className="py-3 px-4">{`${(req.sizeMin || 0).toLocaleString()} - ${(req.sizeMax || 0).toLocaleString()}`}</td>
                                    <td className="py-3 px-4">{req.locations.join(', ')}</td>
                                    <td className="py-3 px-4">{req.useClass}</td>
                                    <td className="py-3 px-4">{req.notes}</td>
                                </tr>
                            );
                        })}
                    </tbody>
                </table>
            </div>
            <div className="mt-4 p-3 bg-teal-50 border border-teal-100 rounded-md text-sm text-teal-800">
                This sheet contains the property requirements for each operator. Data is considered editable.
            </div>

            <BroadcastModal 
                isOpen={modalOpen} 
                onClose={() => setModalOpen(false)} 
                content={emailContent} 
                isLoading={isLoading}
                recipientCount={agents ? agents.length : 0}
                currentUser={currentUser}
            />

            {/* Add Requirement Modal */}
            {isAddModalOpen && (
                <div className="fixed inset-0 bg-black bg-opacity-50 z-50 flex items-center justify-center p-4">
                    <div className="bg-white rounded-lg shadow-xl max-w-md w-full p-6">
                        <h3 className="text-xl font-bold text-gray-800 mb-4">Add New Requirement</h3>
                        <form onSubmit={handleAddRequirement} className="space-y-4">
                            <div>
                                <label className="block text-sm font-medium text-gray-700">Operator</label>
                                <select 
                                    required
                                    className="mt-1 block w-full border border-gray-300 rounded-md shadow-sm p-2 focus:ring-brand-blue focus:border-brand-blue"
                                    value={newRequirement.operatorId || ''}
                                    onChange={e => setNewRequirement({...newRequirement, operatorId: e.target.value})}
                                >
                                    <option value="">Select an Operator...</option>
                                    {operators.map(op => (
                                        <option key={op.id} value={op.id}>{op.name}</option>
                                    ))}
                                </select>
                            </div>
                            <div className="grid grid-cols-2 gap-4">
                                <div>
                                    <label className="block text-sm font-medium text-gray-700">Min Size (sqft)</label>
                                    <input 
                                        required 
                                        type="number" 
                                        className="mt-1 block w-full border border-gray-300 rounded-md shadow-sm p-2 focus:ring-brand-blue focus:border-brand-blue"
                                        value={newRequirement.sizeMin || ''}
                                        onChange={e => setNewRequirement({...newRequirement, sizeMin: Number(e.target.value)})}
                                    />
                                </div>
                                <div>
                                    <label className="block text-sm font-medium text-gray-700">Max Size (sqft)</label>
                                    <input 
                                        required 
                                        type="number" 
                                        className="mt-1 block w-full border border-gray-300 rounded-md shadow-sm p-2 focus:ring-brand-blue focus:border-brand-blue"
                                        value={newRequirement.sizeMax || ''}
                                        onChange={e => setNewRequirement({...newRequirement, sizeMax: Number(e.target.value)})}
                                    />
                                </div>
                            </div>
                            <div>
                                <label className="block text-sm font-medium text-gray-700">Locations (comma separated)</label>
                                <input 
                                    type="text" 
                                    placeholder="London, Manchester, Bristol"
                                    className="mt-1 block w-full border border-gray-300 rounded-md shadow-sm p-2 focus:ring-brand-blue focus:border-brand-blue"
                                    value={selectedLocations}
                                    onChange={e => setSelectedLocations(e.target.value)}
                                />
                            </div>
                            <div>
                                <label className="block text-sm font-medium text-gray-700">Use Class</label>
                                <input 
                                    type="text" 
                                    className="mt-1 block w-full border border-gray-300 rounded-md shadow-sm p-2 focus:ring-brand-blue focus:border-brand-blue"
                                    value={newRequirement.useClass || ''}
                                    onChange={e => setNewRequirement({...newRequirement, useClass: e.target.value})}
                                />
                            </div>
                            <div>
                                <label className="block text-sm font-medium text-gray-700">Notes</label>
                                <textarea 
                                    className="mt-1 block w-full border border-gray-300 rounded-md shadow-sm p-2 focus:ring-brand-blue focus:border-brand-blue"
                                    value={newRequirement.notes || ''}
                                    onChange={e => setNewRequirement({...newRequirement, notes: e.target.value})}
                                />
                            </div>
                            <div className="flex justify-end gap-3 mt-6">
                                <button type="button" onClick={() => setIsAddModalOpen(false)} className="px-4 py-2 text-gray-700 hover:bg-gray-100 rounded-md">Cancel</button>
                                <button type="submit" className="px-4 py-2 bg-brand-blue text-white rounded-md hover:bg-brand-blue/90">Save Requirement</button>
                            </div>
                        </form>
                    </div>
                </div>
            )}
        </div>
    );
};
