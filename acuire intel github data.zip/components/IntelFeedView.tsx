
import React from 'react';
import type { IntelItem } from '../types';
import { ArrowPathIcon } from './icons/Icons';

interface IntelFeedViewProps {
    title: string;
    items: IntelItem[];
    isLoading: boolean;
    onRefresh: () => void;
}

export const IntelFeedView: React.FC<IntelFeedViewProps> = ({ title, items, isLoading, onRefresh }) => {
    return (
        <div className="bg-white p-6 rounded-lg shadow-lg">
            <div className="flex justify-between items-center mb-6">
                <h2 className="text-3xl font-bold text-gray-800">{title}</h2>
                 <button
                    onClick={onRefresh}
                    disabled={isLoading}
                    className="flex items-center bg-brand-blue text-white px-4 py-2 rounded-lg shadow hover:bg-brand-blue/90 transition-all duration-200 disabled:bg-gray-400"
                >
                    <ArrowPathIcon className={`w-5 h-5 mr-2 ${isLoading ? 'animate-spin' : ''}`} />
                    {isLoading ? 'Refreshing...' : 'Refresh Intel'}
                </button>
            </div>
            
            <div className="overflow-x-auto">
                <table className="min-w-full bg-white">
                    <thead className="bg-blue-100 text-brand-blue">
                        <tr>
                            <th className="text-left py-3 px-4 uppercase font-semibold text-sm">Timestamp</th>
                            <th className="text-left py-3 px-4 uppercase font-semibold text-sm">Source</th>
                            <th className="text-left py-3 px-4 uppercase font-semibold text-sm w-1/3">Headline</th>
                            <th className="text-left py-3 px-4 uppercase font-semibold text-sm">Triggers</th>
                            <th className="text-left py-3 px-4 uppercase font-semibold text-sm">Confidence</th>
                            <th className="text-left py-3 px-4 uppercase font-semibold text-sm">Link</th>
                        </tr>
                    </thead>
                    <tbody className="text-gray-700">
                        {items.map(item => (
                            <tr key={item.id} className="border-b border-gray-200 hover:bg-gray-50">
                                <td className="py-3 px-4">{new Date(item.timestamp).toLocaleString()}</td>
                                <td className="py-3 px-4 font-medium">{item.source}</td>
                                <td className="py-3 px-4">{item.headline}</td>
                                <td className="py-3 px-4">
                                    <div className="flex flex-wrap gap-1">
                                    {item.triggerKeywords.slice(0, 2).map(k => <span key={k} className="bg-gray-200 text-gray-700 text-xs px-2 py-0.5 rounded-full">{k}</span>)}
                                    </div>
                                </td>
                                <td className="py-3 px-4">
                                    <div className="flex items-center">
                                        <div className="w-full bg-gray-200 rounded-full h-2.5">
                                            <div className="bg-brand-gold h-2.5 rounded-full" style={{ width: `${item.confidenceScore}%` }}></div>
                                        </div>
                                        <span className="ml-2 font-semibold">{item.confidenceScore}%</span>
                                    </div>
                                </td>
                                <td className="py-3 px-4">
                                    <a href={item.url} target="_blank" rel="noopener noreferrer" className="text-brand-blue hover:underline">Source</a>
                                </td>
                            </tr>
                        ))}
                    </tbody>
                </table>
                 {items.length === 0 && !isLoading && (
                    <div className="text-center py-8 text-gray-500">
                        No intel data available. Click "Refresh Intel" to fetch data.
                    </div>
                )}
            </div>
        </div>
    );
};
