import React, { useState, useMemo } from 'react';
import type { Requirement, Operator, IntelItem } from '../types';
import { BriefcaseIcon, MapPinIcon, ArrowsRightLeftIcon, BuildingOfficeIcon } from './icons/Icons';
import { OPERATOR_CATEGORY_COLORS } from '../constants';

interface OpportunityFinderViewProps {
    requirements: Requirement[];
    operators: Operator[];
    intelFeed: IntelItem[];
    distressFeed: IntelItem[];
    onAddToDealFlow: (intelItem: IntelItem, operator: Operator, requirement: Requirement) => void;
}

export const OpportunityFinderView: React.FC<OpportunityFinderViewProps> = ({
    requirements,
    operators,
    intelFeed,
    distressFeed,
    onAddToDealFlow,
}) => {
    const [selectedReqId, setSelectedReqId] = useState<string | null>(null);
    const [operatorFilter, setOperatorFilter] = useState('');
    const [sizeFilter, setSizeFilter] = useState<string>('');

    const getOperator = (operatorId: string) => {
        return operators.find(op => op.id === operatorId);
    };

    const filteredRequirements = useMemo(() => {
        return requirements.filter(req => {
            const operator = getOperator(req.operatorId);
            if (!operator) return false;

            const operatorName = operator.name.toLowerCase();
            const size = parseInt(sizeFilter, 10);
            
            const operatorMatch = operatorName.includes(operatorFilter.toLowerCase());
            const sizeMatch = !size || (size >= req.sizeMin && size <= req.sizeMax);

            return operatorMatch && sizeMatch;
        });
    }, [requirements, operators, operatorFilter, sizeFilter]);

    const selectedRequirement = useMemo(() => {
        return requirements.find(r => r.id === selectedReqId) || null;
    }, [requirements, selectedReqId]);

    const matchingIntel = useMemo(() => {
        if (!selectedRequirement) return [];
        
        const allIntel = [...intelFeed, ...distressFeed];
        
        return allIntel.filter(item => {
            const sizeMatch = item.sizeSqFt >= selectedRequirement.sizeMin && item.sizeSqFt <= selectedRequirement.sizeMax;
            
            const locationMatch = selectedRequirement.locations.some(loc => 
                item.headline.toLowerCase().includes(loc.toLowerCase()) || 
                item.summary.toLowerCase().includes(loc.toLowerCase())
            );
            
            return sizeMatch && locationMatch;
        }).sort((a,b) => new Date(b.timestamp).getTime() - new Date(a.timestamp).getTime());
    }, [selectedRequirement, intelFeed, distressFeed]);

    return (
        <div className="flex flex-col h-full">
            <h2 className="text-3xl font-bold text-gray-800 mb-6">Opportunity Finder</h2>
            <div className="flex-grow grid grid-cols-1 lg:grid-cols-3 gap-6 h-full overflow-hidden">
                
                {/* Left Column: Requirements & Filters */}
                <div className="lg:col-span-1 bg-white p-4 rounded-lg shadow-md flex flex-col h-full">
                    <h3 className="text-xl font-bold text-brand-blue mb-4">Find Requirements</h3>
                    <div className="mb-4 space-y-3">
                        <input
                            type="text"
                            placeholder="Filter by Operator Name..."
                            value={operatorFilter}
                            onChange={(e) => setOperatorFilter(e.target.value)}
                            className="w-full px-3 py-2 border border-gray-300 rounded-md shadow-sm focus:outline-none focus:ring-brand-blue focus:border-brand-blue"
                        />
                         <input
                            type="number"
                            placeholder="Filter by Target Size (sqft)..."
                            value={sizeFilter}
                            onChange={(e) => setSizeFilter(e.target.value)}
                            className="w-full px-3 py-2 border border-gray-300 rounded-md shadow-sm focus:outline-none focus:ring-brand-blue focus:border-brand-blue"
                        />
                    </div>
                    <div className="flex-grow overflow-y-auto pr-2">
                        {filteredRequirements.map(req => {
                            const operator = getOperator(req.operatorId);
                            if (!operator) return null;
                            const color = OPERATOR_CATEGORY_COLORS[operator.category] || OPERATOR_CATEGORY_COLORS.Default;
                            const isSelected = selectedReqId === req.id;

                            return (
                                <div
                                    key={req.id}
                                    onClick={() => setSelectedReqId(req.id)}
                                    className={`p-4 mb-3 border rounded-lg cursor-pointer transition-all border-t-4 ${
                                        isSelected 
                                            ? 'bg-blue-50 border-brand-blue ring-1 ring-brand-blue shadow-md' 
                                            : `bg-white hover:bg-gray-50 ${color.border}`
                                    }`}
                                >
                                    <div className="flex justify-between items-start">
                                        <h4 className="font-bold text-gray-800">{operator.name}</h4>
                                        {!isSelected && (
                                            <span className={`w-2 h-2 rounded-full ${color.accent}`}></span>
                                        )}
                                    </div>
                                    
                                    {isSelected && (
                                         <span className={`inline-block mt-1 text-xs font-semibold px-2 py-0.5 rounded-full ${color.bg} ${color.text}`}>
                                            {operator.category}
                                        </span>
                                    )}

                                    <div className="text-sm text-gray-600 mt-2 space-y-1">
                                        <p className="flex items-center"><MapPinIcon className="w-4 h-4 mr-2" />{req.locations.join(', ')}</p>
                                        <p className="flex items-center"><ArrowsRightLeftIcon className="w-4 h-4 mr-2" />{(req.sizeMin || 0).toLocaleString()} - {(req.sizeMax || 0).toLocaleString()} sqft</p>
                                    </div>
                                </div>
                            )
                        })}
                    </div>
                </div>

                {/* Right Column: Matching Intel */}
                <div className="lg:col-span-2 bg-white p-4 rounded-lg shadow-md flex flex-col h-full">
                    <h3 className="text-xl font-bold text-brand-blue mb-4">
                        {selectedRequirement ? `Matching Intel for ${getOperator(selectedRequirement.operatorId)?.name}` : 'Select a Requirement'}
                    </h3>
                    <div className="flex-grow overflow-y-auto pr-2">
                        {!selectedRequirement ? (
                            <div className="text-center text-gray-500 pt-10">
                                <p>Select a requirement on the left to see matching opportunities.</p>
                            </div>
                        ) : matchingIntel.length === 0 ? (
                            <div className="text-center text-gray-500 pt-10">
                                <p>No matching intel found for this requirement.</p>
                            </div>
                        ) : (
                            matchingIntel.map(item => {
                                const operator = operators.find(o => o.id === selectedRequirement.operatorId);
                                if (!operator) return null;
                                const color = OPERATOR_CATEGORY_COLORS[operator.category] || OPERATOR_CATEGORY_COLORS.Default;
                                return (
                                    <div key={item.id} className="p-4 mb-3 bg-gray-50 rounded-lg border border-gray-200 hover:shadow-md transition-shadow">
                                        <div className="flex justify-between items-start">
                                            <h5 className="font-semibold text-gray-900 flex-1 pr-2">{item.headline}</h5>
                                            <span className={`text-xs font-semibold px-2 py-0.5 rounded-full whitespace-nowrap ${color.bg} ${color.text} border ${color.border}`}>
                                                {operator.category}
                                            </span>
                                        </div>
                                        <p className="text-sm text-gray-600 mt-1">{item.summary}</p>
                                        <div className="flex items-center text-xs text-gray-500 mt-3">
                                            <BuildingOfficeIcon className="w-4 h-4 mr-1.5" />
                                            <span>{item.propertyType}</span>
                                            <span className="mx-1.5">|</span>
                                            <ArrowsRightLeftIcon className="w-4 h-4 mr-1.5" />
                                            <span>{(item.sizeSqFt || 0).toLocaleString()} sqft</span>
                                             <span className="mx-1.5">|</span>
                                            <span className="font-medium">Source: {item.source}</span>
                                        </div>
                                        <div className="mt-3 flex justify-end">
                                             <button onClick={() => onAddToDealFlow(item, operator, selectedRequirement)} className="flex items-center text-sm bg-green-100 text-green-800 font-semibold px-3 py-1 rounded-md hover:bg-green-200 transition-colors" title="Add to Deal Flow">
                                                <BriefcaseIcon className="w-4 h-4 mr-2"/>
                                                Track
                                            </button>
                                        </div>
                                    </div>
                                );
                            })
                        )}
                    </div>
                </div>
            </div>
        </div>
    );
};
