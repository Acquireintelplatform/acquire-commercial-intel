
import React from 'react';
import type { Source } from '../types';

interface SourceIndexViewProps {
    sources: Source[];
}

export const SourceIndexView: React.FC<SourceIndexViewProps> = ({ sources }) => {
    const categories = [...new Set(sources.map(s => s.category))];

    return (
        <div className="bg-white p-6 rounded-lg shadow-lg">
            <h2 className="text-3xl font-bold text-gray-800 mb-6">Source Index</h2>
            <p className="text-gray-600 mb-8">This is an index of all data sources the Off-Market Radar monitors to generate intelligence.</p>

            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
                {categories.map(category => (
                    <div key={category} className="bg-gray-50 p-4 rounded-md border">
                        <h3 className="text-lg font-semibold text-brand-blue mb-3">{category}</h3>
                        <ul className="space-y-2">
                            {sources.filter(s => s.category === category).map(source => (
                                <li key={source.name} className="text-gray-700 text-sm">{source.name}</li>
                            ))}
                        </ul>
                    </div>
                ))}
            </div>
        </div>
    );
};
