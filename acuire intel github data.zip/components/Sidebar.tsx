import React from 'react';
import type { View } from '../types';
// FIX: Replaced CalendarDaysIcon with CalendarIcon as suggested by the error, and corrected the import list.
import { ChartBarIcon, DocumentTextIcon, ExclamationTriangleIcon, CustomLogoIcon, IdentificationIcon, ListBulletIcon, BeakerIcon, BuildingLibraryIcon, BellIcon, BriefcaseIcon, MagnifyingGlassIcon, GlobeAltIcon, UsersIcon, MapIcon, ChatBubbleIcon, CalendarIcon } from './icons/Icons';

interface SidebarProps {
    currentView: View;
    setView: (view: View) => void;
}

const NavItem: React.FC<{
    icon: React.ReactNode;
    label: string;
    viewName: View;
    currentView: View;
    setView: (view: View) => void;
    isNew?: boolean;
}> = ({ icon, label, viewName, currentView, setView, isNew }) => {
    const isActive = currentView === viewName;
    return (
        <li
            onClick={() => setView(viewName)}
            className={`flex items-center justify-between p-3 my-1 rounded-lg cursor-pointer transition-colors duration-200 ${
                isActive
                    ? 'bg-brand-gold text-brand-blue font-bold shadow-md'
                    : 'text-gray-200 hover:bg-brand-blue/50 hover:text-white'
            }`}
        >
            <div className="flex items-center">
                <span className="w-6 h-6 mr-3">{icon}</span>
                <span>{label}</span>
            </div>
            {isNew && <span className="text-xs bg-brand-gold/80 text-brand-blue font-bold px-2 py-0.5 rounded-full">New</span>}
        </li>
    );
};


export const Sidebar: React.FC<SidebarProps> = ({ currentView, setView }) => {
    return (
        <aside className="w-64 bg-brand-blue text-white flex flex-col p-4 shadow-lg custom-scrollbar overflow-y-auto">
            <div className="flex items-center mb-6 border-b border-brand-blue/50 pb-4">
                 <CustomLogoIcon className="w-10 h-10 text-brand-gold" />
                <h1 className="text-xl font-bold ml-2">Acquire Intel</h1>
            </div>
            <nav className="flex-1">
                <p className="text-xs uppercase text-blue-200 font-bold tracking-wider px-3 mb-2">Intelligence</p>
                <ul>
                    <NavItem icon={<ChartBarIcon />} label="Dashboard" viewName="DASHBOARD" currentView={currentView} setView={setView} />
                    <NavItem icon={<MagnifyingGlassIcon />} label="Property Search" viewName="PROPERTY_SEARCH" currentView={currentView} setView={setView} isNew/>
                    <NavItem icon={<GlobeAltIcon />} label="Industry News" viewName="INDUSTRY_NEWS" currentView={currentView} setView={setView} />
                    <NavItem icon={<MapIcon />} label="Map Index" viewName="MAP_INDEX" currentView={currentView} setView={setView} isNew/>
                </ul>

                <p className="text-xs uppercase text-blue-200 font-bold tracking-wider px-3 mt-6 mb-2">Workflow</p>
                 <ul>
                    <NavItem icon={<BriefcaseIcon />} label="Deal Flow" viewName="DEAL_FLOW" currentView={currentView} setView={setView} />
                    <NavItem icon={<MagnifyingGlassIcon />} label="Opportunity Finder" viewName="OPPORTUNITY_FINDER" currentView={currentView} setView={setView} />
                    <NavItem icon={<DocumentTextIcon />} label="Social Intel" viewName="SOCIAL_INTEL" currentView={currentView} setView={setView} isNew/>
                    {/* FIX: Replaced CalendarDaysIcon with CalendarIcon as suggested by the error. */}
                    <NavItem icon={<CalendarIcon />} label="Calendar" viewName="CALENDAR_VIEW" currentView={currentView} setView={setView} isNew/>
                </ul>

                <p className="text-xs uppercase text-blue-200 font-bold tracking-wider px-3 mt-6 mb-2">Database</p>
                <ul>
                    <NavItem icon={<IdentificationIcon />} label="Operators Master" viewName="OPERATORS_MASTER" currentView={currentView} setView={setView} />
                    <NavItem icon={<UsersIcon />} label="Landlords Master" viewName="LANDLORDS_MASTER" currentView={currentView} setView={setView} isNew/>
                    <NavItem icon={<UsersIcon />} label="Acquisition Agents" viewName="ACQUISITION_AGENTS" currentView={currentView} setView={setView} />
                    <NavItem icon={<ListBulletIcon />} label="Requirements Master" viewName="REQUIREMENTS_MASTER" currentView={currentView} setView={setView} />
                </ul>

                 <p className="text-xs uppercase text-blue-200 font-bold tracking-wider px-3 mt-6 mb-2">System</p>
                <ul>
                    <NavItem icon={<BeakerIcon />} label="Intel Log" viewName="INTEL_LOG" currentView={currentView} setView={setView} />
                    <NavItem icon={<BellIcon />} label="Settings" viewName="SETTINGS" currentView={currentView} setView={setView} />
                </ul>

            </nav>
            <div className="mt-auto pt-4 border-t border-brand-blue/50">
                <div 
                    onClick={() => setView('AI_ASSISTANT')}
                    className={`flex items-center p-3 rounded-lg cursor-pointer transition-colors duration-200 ${currentView === 'AI_ASSISTANT' ? 'bg-brand-gold text-brand-blue font-bold' : 'bg-brand-gold/20 text-white hover:bg-brand-gold/30'}`}
                >
                    <ChatBubbleIcon className="w-6 h-6 mr-3"/>
                    <span className="font-semibold">AI Assistant</span>
                </div>
                <div className="mt-4 text-center text-xs text-gray-400">
                    <p>Acquire Commercial © {new Date().getFullYear()}</p>
                    <p>v2.0.0</p>
                </div>
            </div>
        </aside>
    );
};