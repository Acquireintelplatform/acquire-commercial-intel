import React from 'react';
import { useStore } from '../store/useStore';
import { KeyIcon } from './icons/Icons';

export const SettingsView: React.FC = () => {
    
    const settings = useStore(state => state.settings);
    const setSettings = useStore(state => state.setSettings);

    const handleFieldChange = (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement>) => {
        setSettings({ ...settings, [e.target.name]: e.target.value });
    };

    return (
        <div className="bg-white p-6 rounded-lg shadow-lg max-w-4xl mx-auto">
            <h2 className="text-3xl font-bold text-gray-800 mb-2">Settings</h2>
            <p className="text-gray-600 mb-8">Manage API keys, integrations, and notification preferences.</p>

            <div className="space-y-12">
                 <div>
                    <h3 className="text-xl font-semibold text-gray-800 mb-4 pb-2 border-b flex items-center"><KeyIcon className="w-5 h-5 mr-2"/>Credential Configuration</h3>
                     <div className="space-y-8">
                        {/* Essential APIs */}
                        <div className="p-4 rounded-lg border border-teal-300 bg-teal-50">
                            <h4 className="font-bold text-teal-800 mb-3">Essential APIs (Core Functionality)</h4>
                            <div className="space-y-4">
                                <div>
                                    <label htmlFor="serpApiKey" className="block text-sm font-medium text-gray-700">SerpAPI Key</label>
                                    <input type="password" id="serpApiKey" name="serpApiKey" value={settings.serpApiKey || ''} onChange={handleFieldChange} className="mt-1 w-full px-3 py-2 border border-gray-300 rounded-md shadow-sm"/>
                                    <p className="text-xs text-gray-500 mt-1">Powers all automated web searches and news feeds. <strong className="text-red-600">This is required for the app to function.</strong> <a href="https://serpapi.com/" target="_blank" rel="noopener noreferrer" className="text-brand-blue hover:underline">Get a key from SerpAPI.</a></p>
                                </div>
                                <div>
                                    <label htmlFor="companiesHouseApiKey" className="block text-sm font-medium text-gray-700">Companies House API Key</label>
                                    <input type="password" id="companiesHouseApiKey" name="companiesHouseApiKey" value={settings.companiesHouseApiKey || ''} onChange={handleFieldChange} className="mt-1 w-full px-3 py-2 border border-gray-300 rounded-md shadow-sm"/>
                                     <p className="text-xs text-gray-500 mt-1">Enables live data sync for operator status on the Operators Master page. <a href="https://developer.company-information.service.gov.uk/" target="_blank" rel="noopener noreferrer" className="text-brand-blue hover:underline">Get a key from the Developer Hub.</a></p>
                                </div>
                                 <div>
                                    <label htmlFor="googleMapsApiKey" className="block text-sm font-medium text-gray-700">Google Maps API Key</label>
                                    <input type="password" id="googleMapsApiKey" name="googleMapsApiKey" value={settings.googleMapsApiKey || ''} onChange={handleFieldChange} className="mt-1 w-full px-3 py-2 border border-gray-300 rounded-md shadow-sm"/>
                                     <p className="text-xs text-gray-500 mt-1">Enables the interactive Map Index view. Requires "Maps JavaScript API". <a href="https://developers.google.com/maps/documentation/javascript/get-api-key" target="_blank" rel="noopener noreferrer" className="text-brand-blue hover:underline">Get a key from Google Cloud.</a></p>
                                </div>
                            </div>
                        </div>

                        {/* Optional Direct Integrations */}
                        <div className="p-4 rounded-lg border border-gray-200">
                             <h4 className="font-bold text-gray-600 mb-2">Optional Direct Integrations (Advanced)</h4>
                             <p className="text-sm text-gray-500 mb-4">
                                These credentials are for future or advanced direct integrations. They are <strong className="font-semibold">not required</strong> for the app's core functionality, which uses your SerpAPI key to monitor these sources.
                            </p>
                            
                            {/* Property Data Portals */}
                            <h5 className="font-semibold text-gray-500 text-sm mb-3 mt-4">Property Data Portals</h5>
                             <div className="space-y-4">
                                <div className="grid grid-cols-2 gap-4">
                                    <div><label className="block text-sm font-medium text-gray-700">Estates Gazette (EGI) Username</label><input type="text" name="egiUsername" value={settings.egiUsername || ''} onChange={handleFieldChange} className="mt-1 w-full px-3 py-2 border border-gray-300 rounded-md"/></div>
                                    <div><label className="block text-sm font-medium text-gray-700">EGI Password</label><input type="password" name="egiPassword" value={settings.egiPassword || ''} onChange={handleFieldChange} className="mt-1 w-full px-3 py-2 border border-gray-300 rounded-md"/></div>
                                </div>
                                <div className="grid grid-cols-2 gap-4">
                                    <div><label className="block text-sm font-medium text-gray-700">CoStar Username</label><input type="text" name="coStarUsername" value={settings.coStarUsername || ''} onChange={handleFieldChange} className="mt-1 w-full px-3 py-2 border border-gray-300 rounded-md"/></div>
                                    <div><label className="block text-sm font-medium text-gray-700">CoStar Password</label><input type="password" name="coStarPassword" value={settings.coStarPassword || ''} onChange={handleFieldChange} className="mt-1 w-full px-3 py-2 border border-gray-300 rounded-md"/></div>
                                </div>
                                <div>
                                    <label className="block text-sm font-medium text-gray-700">Property Data API Key</label>
                                    <input type="password" name="propertyDataApiKey" value={settings.propertyDataApiKey || ''} onChange={handleFieldChange} className="mt-1 w-full px-3 py-2 border border-gray-300 rounded-md"/>
                                </div>
                             </div>

                            {/* Commercial Listing Portals */}
                            <h5 className="font-semibold text-gray-500 text-sm mb-3 mt-6">Commercial Listing Portals</h5>
                             <div className="space-y-4">
                                <div><label className="block text-sm font-medium text-gray-700">Rightmove Commercial API Key</label><input type="password" name="rightmoveApiKey" value={settings.rightmoveApiKey || ''} onChange={handleFieldChange} className="mt-1 w-full px-3 py-2 border border-gray-300 rounded-md"/></div>
                                <div><label className="block text-sm font-medium text-gray-700">Zoopla Commercial API Key</label><input type="password" name="zooplaApiKey" value={settings.zooplaApiKey || ''} onChange={handleFieldChange} className="mt-1 w-full px-3 py-2 border border-gray-300 rounded-md"/></div>
                                <div><label className="block text-sm font-medium text-gray-700">LoopNet API Key</label><input type="password" name="loopnetApiKey" value={settings.loopnetApiKey || ''} onChange={handleFieldChange} className="mt-1 w-full px-3 py-2 border border-gray-300 rounded-md"/></div>
                                <div><label className="block text-sm font-medium text-gray-700">NovaLoca API Key</label><input type="password" name="novaLocaApiKey" value={settings.novaLocaApiKey || ''} onChange={handleFieldChange} className="mt-1 w-full px-3 py-2 border border-gray-300 rounded-md"/></div>
                                <div><label className="block text-sm font-medium text-gray-700">Realla API Key</label><input type="password" name="reallaApiKey" value={settings.reallaApiKey || ''} onChange={handleFieldChange} className="mt-1 w-full px-3 py-2 border border-gray-300 rounded-md"/></div>
                             </div>

                             {/* Industry News & Specialist Data */}
                            <h5 className="font-semibold text-gray-500 text-sm mb-3 mt-6">Industry News & Specialist Data</h5>
                             <div className="space-y-4">
                                <div className="grid grid-cols-2 gap-4">
                                    <div><label className="block text-sm font-medium text-gray-700">Business Sale Report Username</label><input type="text" name="businessSaleReportUsername" value={settings.businessSaleReportUsername || ''} onChange={handleFieldChange} className="mt-1 w-full px-3 py-2 border border-gray-300 rounded-md"/></div>
                                    <div><label className="block text-sm font-medium text-gray-700">Business Sale Report Password</label><input type="password" name="businessSaleReportPassword" value={settings.businessSaleReportPassword || ''} onChange={handleFieldChange} className="mt-1 w-full px-3 py-2 border border-gray-300 rounded-md"/></div>
                                </div>
                                <div className="grid grid-cols-2 gap-4">
                                    <div><label className="block text-sm font-medium text-gray-700">Propel Username</label><input type="text" name="propelUsername" value={settings.propelUsername || ''} onChange={handleFieldChange} className="mt-1 w-full px-3 py-2 border border-gray-300 rounded-md"/></div>
                                    <div><label className="block text-sm font-medium text-gray-700">Propel Password</label><input type="password" name="propelPassword" value={settings.propelPassword || ''} onChange={handleFieldChange} className="mt-1 w-full px-3 py-2 border border-gray-300 rounded-md"/></div>
                                </div>
                                <div className="grid grid-cols-2 gap-4">
                                    <div><label className="block text-sm font-medium text-gray-700">MCA Insight Username</label><input type="text" name="mcaInsightUsername" value={settings.mcaInsightUsername || ''} onChange={handleFieldChange} className="mt-1 w-full px-3 py-2 border border-gray-300 rounded-md"/></div>
                                    <div><label className="block text-sm font-medium text-gray-700">MCA Insight Password</label><input type="password" name="mcaInsightPassword" value={settings.mcaInsightPassword || ''} onChange={handleFieldChange} className="mt-1 w-full px-3 py-2 border border-gray-300 rounded-md"/></div>
                                </div>
                                <div>
                                    <label className="block text-sm font-medium text-gray-700">Insolvency Insider API Key</label>
                                    <input type="password" name="insolvencyInsiderApiKey" value={settings.insolvencyInsiderApiKey || ''} onChange={handleFieldChange} className="mt-1 w-full px-3 py-2 border border-gray-300 rounded-md"/>
                                </div>
                                <div>
                                    <label className="block text-sm font-medium text-gray-700">The Requirement List API Key</label>
                                    <input type="password" name="theRequirementListApiKey" value={settings.theRequirementListApiKey || ''} onChange={handleFieldChange} className="mt-1 w-full px-3 py-2 border border-gray-300 rounded-md"/>
                                </div>
                             </div>
                        </div>
                        
                        <div className="mt-4 p-3 bg-yellow-50 border border-yellow-200 rounded-md text-sm text-yellow-800">
                            <p><strong className="font-semibold">Security Note:</strong> Your credentials are saved to your browser's local storage for convenience. For production-grade security, a backend credential vault is the recommended best practice.</p>
                        </div>
                     </div>
                </div>
            </div>
        </div>
    );
};