
import React, { useState } from 'react';
import type { Deal, DealStatus, TeamMember, Viewing } from '../types';
import { BuildingOfficeIcon, ArrowsRightLeftIcon, DocumentTextIcon, ClipboardDocumentCheckIcon, CalendarIcon, ArrowDownTrayIcon } from './icons/Icons';
import { OPERATOR_CATEGORY_COLORS, TEAM_MEMBERS } from '../constants';
import { generateEmailDraft, generateInvestmentMemo } from '../services/geminiService';

const DEAL_STATUSES: DealStatus[] = ['New', 'Under Review', 'Contacting Agent', 'Offer Made', 'Acquired', 'Rejected'];

const statusColors: Record<DealStatus, { bg: string, text: string, border: string }> = {
    'New': { bg: 'bg-blue-50', text: 'text-blue-800', border: 'border-blue-500' },
    'Under Review': { bg: 'bg-yellow-50', text: 'text-yellow-800', border: 'border-yellow-500' },
    'Contacting Agent': { bg: 'bg-indigo-50', text: 'text-indigo-800', border: 'border-indigo-500' },
    'Offer Made': { bg: 'bg-purple-50', text: 'text-purple-800', border: 'border-purple-500' },
    'Acquired': { bg: 'bg-green-50', text: 'text-green-800', border: 'border-green-500' },
    'Rejected': { bg: 'bg-red-50', text: 'text-red-800', border: 'border-red-500' },
};

interface DealCardProps {
    deal: Deal;
    onNoteChange: (dealId: string, newNote: string) => void;
    onDraftEmail: (deal: Deal) => void;
    onGenerateMemo: (deal: Deal) => void;
    onScheduleViewing: (deal: Deal) => void;
}

const DealCard: React.FC<DealCardProps> = ({ deal, onNoteChange, onDraftEmail, onGenerateMemo, onScheduleViewing }) => {
    const { intel, operator } = deal;
    const categoryColor = OPERATOR_CATEGORY_COLORS[operator.category] || OPERATOR_CATEGORY_COLORS.Default;

    return (
        <div 
            draggable 
            onDragStart={(e) => {
                e.dataTransfer.setData('dealId', deal.id);
                e.currentTarget.classList.add('opacity-50');
            }}
            onDragEnd={(e) => {
                 e.currentTarget.classList.remove('opacity-50');
            }}
            className="bg-white rounded-lg shadow-sm hover:shadow-md transition-shadow duration-200 p-4 mb-4 cursor-grab active:cursor-grabbing border-l-4 group"
            style={{ borderColor: statusColors[deal.status].border.replace('border-', '').replace('-500', '') }}
        >
            <div className="flex justify-between items-start mb-2">
                <span className={`text-xs font-bold px-2 py-0.5 rounded-full ${categoryColor.bg} ${categoryColor.text} border ${categoryColor.border}`}>
                    {operator.category}
                </span>
                {deal.investmentMemo && (
                     <span title="Investment Memo Generated" className="text-green-600">
                        <ClipboardDocumentCheckIcon className="w-4 h-4" />
                     </span>
                )}
            </div>
            <h4 className="font-bold text-brand-blue leading-tight">{intel.headline}</h4>
            <div className="mt-2">
                <p className="text-sm text-gray-600">
                    Match: <span className="font-semibold">{operator.name}</span>
                </p>
            </div>
            <div className="flex items-center text-xs text-gray-500 mt-2">
                <BuildingOfficeIcon className="w-3 h-3 mr-1.5" />
                <span>{intel.propertyType}</span>
                <span className="mx-1.5">|</span>
                <ArrowsRightLeftIcon className="w-3 h-3 mr-1.5" />
                <span>{(intel.sizeSqFt || 0).toLocaleString()} sqft</span>
            </div>
             <textarea
                className="w-full mt-3 p-2 text-sm border border-gray-200 rounded-md focus:ring-1 focus:ring-brand-blue focus:border-brand-blue"
                rows={3}
                placeholder="Add notes..."
                value={deal.notes}
                onChange={(e) => onNoteChange(deal.id, e.target.value)}
                onClick={(e) => e.stopPropagation()} // Prevent card drag
            />
            <div className="flex gap-2 mt-3">
                <button 
                    onClick={() => onDraftEmail(deal)}
                    className="flex-1 flex items-center justify-center px-2 py-1.5 text-xs font-medium text-indigo-700 bg-indigo-50 border border-indigo-200 rounded hover:bg-indigo-100 transition-colors"
                    title="Draft Agent Email"
                >
                    <DocumentTextIcon className="w-3 h-3 mr-1.5" />
                    Email
                </button>
                 <button 
                    onClick={() => onScheduleViewing(deal)}
                    className="flex-1 flex items-center justify-center px-2 py-1.5 text-xs font-medium text-brand-gold bg-teal-50 border border-teal-200 rounded hover:bg-teal-100 transition-colors"
                    title="Schedule Viewing"
                >
                    <CalendarIcon className="w-3 h-3 mr-1.5" />
                    View
                </button>
            </div>
            <button 
                onClick={() => onGenerateMemo(deal)}
                className="w-full mt-2 flex items-center justify-center px-2 py-1.5 text-xs font-medium text-gray-600 bg-gray-50 border border-gray-200 rounded hover:bg-gray-100 transition-colors"
                title="Generate Investment Memo"
            >
                <ClipboardDocumentCheckIcon className="w-3 h-3 mr-1.5" />
                Generate Investment Memo
            </button>
        </div>
    );
};

interface TextModalProps {
    isOpen: boolean;
    onClose: () => void;
    title: string;
    content: string;
    isLoading: boolean;
    currentUser?: TeamMember;
}

const TextModal: React.FC<TextModalProps> = ({ isOpen, onClose, title, content, isLoading, currentUser }) => {
    if (!isOpen) return null;

    return (
        <div className="fixed inset-0 bg-black bg-opacity-50 z-50 flex items-center justify-center p-4">
            <div className="bg-white rounded-lg shadow-2xl max-w-2xl w-full max-h-[80vh] flex flex-col">
                <div className="p-4 border-b flex justify-between items-center">
                    <div>
                        <h3 className="text-lg font-bold text-brand-blue">{title}</h3>
                        {currentUser && <p className="text-xs text-gray-500">Drafting as: <span className="font-semibold">{currentUser.name}</span></p>}
                    </div>
                    <button onClick={onClose} className="text-gray-500 hover:text-gray-700">&times;</button>
                </div>
                <div className="p-6 overflow-y-auto flex-grow">
                    {isLoading ? (
                        <div className="flex flex-col items-center justify-center h-40">
                            <div className="animate-spin rounded-full h-10 w-10 border-b-2 border-brand-blue"></div>
                            <p className="mt-4 text-gray-500">AI is analyzing the deal...</p>
                        </div>
                    ) : (
                        <div className="bg-gray-50 p-4 rounded border border-gray-200 font-mono text-sm whitespace-pre-wrap text-gray-800 leading-relaxed">
                            {content}
                        </div>
                    )}
                </div>
                <div className="p-4 border-t bg-gray-50 flex justify-end gap-3 rounded-b-lg">
                    <button onClick={onClose} className="px-4 py-2 text-gray-600 hover:bg-gray-200 rounded-md transition-colors">Close</button>
                    <button 
                        onClick={() => {
                            // Create a mailto link logic here roughly based on content
                            const subject = content.match(/Subject Line: (.*)/)?.[1] || "Inquiry from Acquire Commercial";
                            const body = encodeURIComponent(content);
                            window.location.href = `mailto:?subject=${subject}&body=${body}`;
                        }} 
                        className="px-4 py-2 bg-brand-blue text-white rounded-md hover:bg-brand-blue/90 shadow-sm transition-colors flex items-center disabled:opacity-50"
                        disabled={isLoading}
                    >
                        <DocumentTextIcon className="w-4 h-4 mr-2"/>
                        Open in Outlook
                    </button>
                </div>
            </div>
        </div>
    );
}

interface ScheduleModalProps {
    isOpen: boolean;
    onClose: () => void;
    deal: Deal | null;
    onSave: (viewing: Viewing) => void;
}

const ScheduleModal: React.FC<ScheduleModalProps> = ({ isOpen, onClose, deal, onSave }) => {
    const [date, setDate] = useState('');
    const [time, setTime] = useState('');
    const [attendeeId, setAttendeeId] = useState(TEAM_MEMBERS[0].id);
    const [notes, setNotes] = useState('');

    if (!isOpen || !deal) return null;

    const handleSubmit = (e: React.FormEvent) => {
        e.preventDefault();
        const dateTime = new Date(`${date}T${time}`);
        
        const newViewing: Viewing = {
            id: `view-${Date.now()}`,
            dealId: deal.id,
            dealHeadline: deal.intel.headline,
            operatorName: deal.operator.name,
            location: deal.intel.headline.split(',')[0] || 'Location TBD', // Rudimentary extraction
            date: dateTime,
            attendeeId: attendeeId,
            notes: notes
        };
        onSave(newViewing);
        onClose();
    };

    return (
        <div className="fixed inset-0 bg-black bg-opacity-50 z-50 flex items-center justify-center p-4">
             <div className="bg-white rounded-lg shadow-2xl max-w-md w-full">
                <div className="p-4 border-b bg-gray-50 rounded-t-lg">
                    <h3 className="text-lg font-bold text-gray-800">Schedule Viewing</h3>
                    <p className="text-sm text-gray-500 truncate">{deal.intel.headline}</p>
                </div>
                <form onSubmit={handleSubmit} className="p-6 space-y-4">
                    <div className="grid grid-cols-2 gap-4">
                        <div>
                            <label className="block text-sm font-medium text-gray-700">Date</label>
                            <input 
                                type="date" 
                                required
                                className="mt-1 block w-full border border-gray-300 rounded-md shadow-sm p-2"
                                value={date}
                                onChange={(e) => setDate(e.target.value)}
                            />
                        </div>
                        <div>
                            <label className="block text-sm font-medium text-gray-700">Time</label>
                            <input 
                                type="time" 
                                required
                                className="mt-1 block w-full border border-gray-300 rounded-md shadow-sm p-2"
                                value={time}
                                onChange={(e) => setTime(e.target.value)}
                            />
                        </div>
                    </div>
                    <div>
                        <label className="block text-sm font-medium text-gray-700">Attendee</label>
                        <select 
                            className="mt-1 block w-full border border-gray-300 rounded-md shadow-sm p-2"
                            value={attendeeId}
                            onChange={(e) => setAttendeeId(e.target.value)}
                        >
                            {TEAM_MEMBERS.map(m => <option key={m.id} value={m.id}>{m.name}</option>)}
                        </select>
                    </div>
                    <div>
                        <label className="block text-sm font-medium text-gray-700">Notes</label>
                        <textarea 
                            className="mt-1 block w-full border border-gray-300 rounded-md shadow-sm p-2"
                            rows={3}
                            placeholder="Meeting point, agent name, access codes..."
                            value={notes}
                            onChange={(e) => setNotes(e.target.value)}
                        />
                    </div>
                    <div className="flex justify-end gap-3 pt-4">
                        <button type="button" onClick={onClose} className="px-4 py-2 text-gray-600 hover:bg-gray-100 rounded-md">Cancel</button>
                        <button type="submit" className="px-4 py-2 bg-brand-gold text-white font-bold rounded-md hover:bg-teal-500">Add to Calendar</button>
                    </div>
                </form>
             </div>
        </div>
    );
}

interface DealFlowViewProps {
    deals: Deal[];
    setDeals: React.Dispatch<React.SetStateAction<Deal[]>>;
    currentUser: TeamMember;
    viewings?: Viewing[];
    setViewings?: React.Dispatch<React.SetStateAction<Viewing[]>>;
}

export const DealFlowView: React.FC<DealFlowViewProps> = ({ deals, setDeals, currentUser, setViewings }) => {
    const [draggedOverColumn, setDraggedOverColumn] = useState<DealStatus | null>(null);
    
    // Modal States
    const [textModalOpen, setTextModalOpen] = useState(false);
    const [modalTitle, setModalTitle] = useState('');
    const [modalContent, setModalContent] = useState('');
    const [isGenerating, setIsGenerating] = useState(false);

    // Schedule Modal
    const [scheduleModalOpen, setScheduleModalOpen] = useState(false);
    const [selectedDeal, setSelectedDeal] = useState<Deal | null>(null);

    const handleDrop = (e: React.DragEvent<HTMLDivElement>, newStatus: DealStatus) => {
        e.preventDefault();
        setDraggedOverColumn(null);
        const dealId = e.dataTransfer.getData('dealId');
        setDeals(prevDeals => prevDeals.map(d => 
            d.id === dealId ? { ...d, status: newStatus } : d
        ).sort((a,b) => a.intel.timestamp > b.intel.timestamp ? -1 : 1));
    };

    const handleDragOver = (e: React.DragEvent<HTMLDivElement>, status: DealStatus) => {
        e.preventDefault();
        setDraggedOverColumn(status);
    };
    
    const handleNoteChange = (dealId: string, newNote: string) => {
        setDeals(prevDeals => prevDeals.map(d => 
            d.id === dealId ? { ...d, notes: newNote } : d
        ));
    };

    const handleDraftEmail = async (deal: Deal) => {
        setModalTitle('AI Agent Inquiry Draft');
        setModalContent('');
        setTextModalOpen(true);
        setIsGenerating(true);
        
        const draft = await generateEmailDraft(deal.intel, deal.operator, deal.requirement, currentUser);
        setModalContent(draft);
        setIsGenerating(false);
    };

    const handleGenerateMemo = async (deal: Deal) => {
        if (deal.investmentMemo) {
            setModalTitle('Investment Memo (Cached)');
            setModalContent(deal.investmentMemo);
            setTextModalOpen(true);
            return;
        }

        setModalTitle('Generating AI Investment Memo...');
        setModalContent('');
        setTextModalOpen(true);
        setIsGenerating(true);

        const memo = await generateInvestmentMemo(deal.intel, deal.operator, deal.requirement);
        
        // Save memo to deal state
        setDeals(prevDeals => prevDeals.map(d => 
            d.id === deal.id ? { ...d, investmentMemo: memo } : d
        ));

        setModalContent(memo);
        setModalTitle('AI Investment Memo');
        setIsGenerating(false);
    };

    const handleScheduleViewing = (deal: Deal) => {
        setSelectedDeal(deal);
        setScheduleModalOpen(true);
    };

    const handleSaveViewing = (viewing: Viewing) => {
        if (setViewings) {
            setViewings(prev => [...prev, viewing]);
            // Optionally update deal status to 'Contacting Agent' or 'Under Review' if it's 'New'
            setDeals(prevDeals => prevDeals.map(d => 
                d.id === viewing.dealId && d.status === 'New' ? { ...d, status: 'Contacting Agent' } : d
            ));
        }
    };

    const handleExport = () => {
        if (!deals.length) return;
        const headers = ["Deal ID", "Headline", "Operator", "Size (sqft)", "Status", "Notes", "Memo Generated?"];
        const csvContent = [
            headers.join(","),
            ...deals.map(d => [
                d.id,
                `"${d.intel.headline.replace(/"/g, '""')}"`,
                d.operator.name,
                d.intel.sizeSqFt,
                d.status,
                `"${d.notes.replace(/"/g, '""')}"`,
                d.investmentMemo ? "Yes" : "No"
            ].join(","))
        ].join("\n");

        const blob = new Blob([csvContent], { type: "text/csv;charset=utf-8;" });
        const url = URL.createObjectURL(blob);
        const link = document.createElement("a");
        link.setAttribute("href", url);
        link.setAttribute("download", `deal_flow_export_${new Date().toISOString().split('T')[0]}.csv`);
        document.body.appendChild(link);
        link.click();
        document.body.removeChild(link);
    };

    return (
        <div>
            <div className="flex justify-between items-center mb-6">
                <h2 className="text-3xl font-bold text-gray-800">Deal Flow</h2>
                <button 
                    onClick={handleExport}
                    className="flex items-center bg-white text-gray-700 border border-gray-300 px-4 py-2 rounded-lg shadow-sm hover:bg-gray-50 transition-colors font-medium"
                >
                    <ArrowDownTrayIcon className="w-5 h-5 mr-2" />
                    Export Pipeline
                </button>
            </div>
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-6 gap-4">
                {DEAL_STATUSES.map(status => (
                    <div 
                        key={status} 
                        className={`p-4 rounded-lg transition-colors ${statusColors[status].bg} ${draggedOverColumn === status ? 'bg-opacity-50' : ''}`}
                        onDrop={(e) => handleDrop(e, status)}
                        onDragOver={(e) => handleDragOver(e, status)}
                        onDragLeave={() => setDraggedOverColumn(null)}
                    >
                        <h3 className={`font-semibold mb-4 pb-2 border-b-2 ${statusColors[status].text} ${statusColors[status].border}`}>
                            {status} ({deals.filter(d => d.status === status).length})
                        </h3>
                        <div className="h-[calc(100vh-14rem)] overflow-y-auto pr-2">
                            {deals.filter(d => d.status === status).map(deal => (
                                <DealCard 
                                    key={deal.id} 
                                    deal={deal} 
                                    onNoteChange={handleNoteChange} 
                                    onDraftEmail={handleDraftEmail}
                                    onGenerateMemo={handleGenerateMemo}
                                    onScheduleViewing={handleScheduleViewing}
                                />
                            ))}
                        </div>
                    </div>
                ))}
            </div>
            <TextModal isOpen={textModalOpen} onClose={() => setTextModalOpen(false)} title={modalTitle} content={modalContent} isLoading={isGenerating} currentUser={currentUser} />
            <ScheduleModal isOpen={scheduleModalOpen} onClose={() => setScheduleModalOpen(false)} deal={selectedDeal} onSave={handleSaveViewing} />
        </div>
    );
};
