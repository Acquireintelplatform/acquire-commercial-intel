import React, { useState, useEffect, useCallback } from 'react';
import { Sidebar } from './components/Sidebar';
import { Dashboard } from './components/Dashboard';
import { IntelFeedView } from './components/IntelFeedView';
import { OperatorsView } from './components/OperatorsView';
import { RequirementsView } from './components/RequirementsView';
import { SourceIndexView } from './components/SourceIndexView';
import { IntelLogView } from './components/IntelLogView';
import { SettingsView } from './components/NotificationSettings';
import { DealFlowView } from './components/DealFlowView';
import { OpportunityFinderView } from './components/OpportunityFinderView';
import { IndustryNewsView } from './components/IndustryNewsView';
import { AgentsView } from './components/AgentsView';
import { SocialIntelView } from './components/SocialIntelView';
import { MapIndexView } from './components/MapIndexView';
import { LeaseExpiryView } from './components/LeaseExpiryView';
import { AIAssistantView } from './components/AIAssistantView';
import { PropertySearchView } from './components/PropertySearchView';
import { CalendarView } from './components/CalendarView';
import { LandlordsView } from './components/LandlordsView';
import { useStore } from './store/useStore';
import type { View, IntelItem, Operator, Requirement } from './types';

const App: React.FC = () => {
    const [view, setView] = useState<View>('DASHBOARD');
    const {
        intelFeed, distressFeed, industryNews, operators, requirements, agents,
        alerts, deals, logs, settings, leaseExpiries, chatHistory, viewings,
        calendarEvents, landlords, currentUser, isLoading, error, lastSync,
        secondsUntilRefresh, fetchAllData, addOpportunityToDealFlow, addAlertToDealFlow,
        setDeals, setOperators, setRequirements, setAgents, setLandlords, setChatHistory,
        setViewings, setCalendarEvents
    } = useStore();

    useEffect(() => {
        // This effect ensures that the first data fetch happens automatically
        // as soon as the user provides an API key, fixing the "blank app" issue.
        const hasFetchedOnce = intelFeed.length > 0 || distressFeed.length > 0 || industryNews.length > 0 || leaseExpiries.length > 0;
        if (settings.serpApiKey && !isLoading && !hasFetchedOnce && !error) {
            console.log("API key found, performing initial data fetch...");
            fetchAllData();
        }
    }, [settings.serpApiKey, fetchAllData, intelFeed.length, distressFeed.length, industryNews.length, leaseExpiries.length, isLoading, error]);


    const addSocialIntel = useCallback((intelItem: IntelItem) => {
        useStore.setState(state => ({ intelFeed: [intelItem, ...state.intelFeed] }));
        setView('INTEL_FEEDS');
    }, []);

    const renderView = () => {
        switch (view) {
            case 'DASHBOARD':
                return <Dashboard alerts={alerts} deals={deals} isLoading={isLoading} error={error} onRefresh={fetchAllData} onAddToDealFlow={addAlertToDealFlow} setView={setView} secondsUntilRefresh={secondsUntilRefresh} lastSync={lastSync} operators={operators}/>;
            case 'DEAL_FLOW':
                return <DealFlowView deals={deals} setDeals={setDeals} currentUser={currentUser} viewings={viewings} setViewings={setViewings} />;
            case 'INDUSTRY_NEWS':
                return <IndustryNewsView newsItems={industryNews} isLoading={isLoading} error={error} onRefresh={fetchAllData} />;
            case 'OPPORTUNITY_FINDER':
                return <OpportunityFinderView requirements={requirements} operators={operators} intelFeed={intelFeed} distressFeed={distressFeed} leaseExpiries={leaseExpiries} onAddToDealFlow={addOpportunityToDealFlow} />;
            case 'INTEL_FEEDS':
                return <IntelFeedView title="Intel Feeds (Property & News)" items={intelFeed} isLoading={isLoading} onRefresh={fetchAllData} />;
            case 'DISTRESS_FEEDS':
                return <IntelFeedView title="Distress Feeds (Insolvency & Triggers)" items={distressFeed} isLoading={isLoading} onRefresh={fetchAllData} />;
            case 'SOCIAL_INTEL':
                return <SocialIntelView onAddIntel={addSocialIntel} />;
            case 'OPERATORS_MASTER':
                return <OperatorsView operators={operators} setOperators={setOperators} notificationSettings={settings} />;
            case 'REQUIREMENTS_MASTER':
                return <RequirementsView requirements={requirements} setRequirements={setRequirements} operators={operators} agents={agents} currentUser={currentUser} />;
            case 'ACQUISITION_AGENTS':
                return <AgentsView agents={agents} setAgents={setAgents} />;
            case 'LANDLORDS_MASTER':
                return <LandlordsView landlords={landlords} setLandlords={setLandlords} />;
            case 'SOURCE_INDEX':
                return <SourceIndexView sources={useStore.getState().sources} />;
            case 'INTEL_LOG':
                return <IntelLogView logs={logs} />;
            case 'MAP_INDEX':
                return <MapIndexView intelFeed={intelFeed} distressFeed={distressFeed} leaseExpiries={leaseExpiries} operators={operators} googleMapsApiKey={settings.googleMapsApiKey} setView={setView} />;
            case 'LEASE_EXPIRY_RADAR':
                return <LeaseExpiryView leaseExpiries={leaseExpiries} isLoading={isLoading} onRefresh={fetchAllData} />;
            case 'AI_ASSISTANT':
                return <AIAssistantView chatHistory={chatHistory} setChatHistory={setChatHistory} operators={operators} deals={deals} intelFeed={intelFeed} currentUser={currentUser} />;
            case 'PROPERTY_SEARCH':
                return <PropertySearchView onAddToDealFlow={addOpportunityToDealFlow} operators={operators} requirements={requirements} serpApiKey={settings.serpApiKey} />;
            case 'CALENDAR_VIEW':
                return <CalendarView viewings={viewings} calendarEvents={calendarEvents} setCalendarEvents={setCalendarEvents} />;
            case 'SETTINGS':
                return <SettingsView />;
            default:
                return <Dashboard alerts={alerts} deals={deals} isLoading={isLoading} error={error} onRefresh={fetchAllData} onAddToDealFlow={addAlertToDealFlow} setView={setView} secondsUntilRefresh={secondsUntilRefresh} lastSync={lastSync} operators={operators} />;
        }
    };

    return (
        <div className="flex h-screen bg-gray-100 font-sans">
            <Sidebar currentView={view} setView={setView} />
            <main className="flex-1 overflow-y-auto p-4 sm:p-6 lg:p-8">
                {renderView()}
            </main>
        </div>
    );
};

export default App;