import React, { useEffect, useRef, useState } from 'react';
import type { IntelItem, Operator, OperatorCategory, LeaseExpiry, View } from '../types';
import { OPERATOR_CATEGORY_COLORS, PROPERTY_TYPE_MAPPING } from '../constants';
import { MagnifyingGlassIcon, TrashIcon, ClockIcon, ExclamationTriangleIcon } from './icons/Icons';

declare global {
    interface Window {
        google: any;
        initMap: () => void;
    }
}

interface MapIndexViewProps {
    intelFeed: IntelItem[];
    distressFeed: IntelItem[];
    leaseExpiries: LeaseExpiry[];
    operators: Operator[];
    googleMapsApiKey?: string;
    setView: (view: View) => void;
}

const CATEGORIES: OperatorCategory[] = ['Restaurant', 'Coffee', 'QSR', 'Retail', 'Leisure', 'Pubs', 'Gyms', 'Nursery', 'Mixed'];

const getCategoryFromPropertyType = (propertyType: string): OperatorCategory | 'Default' => {
    const firstWord = propertyType.split(' ')[0];
    return PROPERTY_TYPE_MAPPING[firstWord] || PROPERTY_TYPE_MAPPING[propertyType] || 'Default';
};

const loadGoogleMapsScript = (apiKey: string, callback: () => void, onError: () => void) => {
    if (window.google && window.google.maps) {
        callback();
        return;
    }
    const existingScript = document.getElementById('googleMapsScript');
    if (existingScript) {
        existingScript.addEventListener('load', callback);
        existingScript.addEventListener('error', onError);
        return;
    }

    const script = document.createElement('script');
    script.id = 'googleMapsScript';
    script.src = `https://maps.googleapis.com/maps/api/js?key=${apiKey}&libraries=drawing,geometry`;
    script.async = true;
    script.defer = true;
    script.onload = callback;
    script.onerror = onError;
    document.head.appendChild(script);
};

export const MapIndexView: React.FC<MapIndexViewProps> = ({ intelFeed, distressFeed, leaseExpiries, operators, googleMapsApiKey, setView }) => {
    const mapRef = useRef<HTMLDivElement>(null);
    const mapInstanceRef = useRef<any>(null);
    const markersRef = useRef<any[]>([]);
    const infoWindowRef = useRef<any>(null);

    const [isApiLoaded, setIsApiLoaded] = useState(false);
    const [apiKeyError, setApiKeyError] = useState(false);
    const [isKeyMissing, setIsKeyMissing] = useState(false);
    const [activeShape, setActiveShape] = useState<{ overlay: any, type: string } | null>(null);
    const [categoryFilter, setCategoryFilter] = useState<OperatorCategory | 'All'>('All');
    const [searchTerm, setSearchTerm] = useState('');
    const [dataSource, setDataSource] = useState<'intel' | 'expiries'>('intel');
    
    useEffect(() => {
        const apiKey = googleMapsApiKey;
        if (apiKey) {
            setIsKeyMissing(false);
            loadGoogleMapsScript(apiKey, () => setIsApiLoaded(true), () => {
                console.error("Google Maps script failed to load. The API key might be invalid or restricted.");
                setApiKeyError(true);
            });
        } else {
            console.error("Google Maps API Key is not set in Settings.");
            setIsKeyMissing(true);
            setApiKeyError(true);
        }
    }, [googleMapsApiKey]);

    useEffect(() => {
        if (!isApiLoaded || !mapRef.current || mapInstanceRef.current) return;

        const map = new window.google.maps.Map(mapRef.current, {
            center: { lat: 54.5, lng: -2.0 },
            zoom: 6,
            mapTypeControl: true,
            mapTypeControlOptions: {
                style: window.google.maps.MapTypeControlStyle.DROPDOWN_MENU,
                mapTypeIds: ["roadmap", "terrain", "satellite", "hybrid"],
            },
            streetViewControl: true,
            fullscreenControl: false,
        });
        mapInstanceRef.current = map;
        infoWindowRef.current = new window.google.maps.InfoWindow();

        const drawingManager = new window.google.maps.drawing.DrawingManager({
            drawingMode: null,
            drawingControl: true,
            drawingControlOptions: {
                position: window.google.maps.ControlPosition.TOP_CENTER,
                drawingModes: ['polygon', 'rectangle', 'circle'],
            },
            circleOptions: { fillColor: '#00c4b4', fillOpacity: 0.2, strokeColor: '#00c4b4', strokeWeight: 2, clickable: false, editable: false, zIndex: 1 },
            polygonOptions: { fillColor: '#00c4b4', fillOpacity: 0.2, strokeColor: '#00c4b4', strokeWeight: 2, clickable: false, editable: false, zIndex: 1 },
            rectangleOptions: { fillColor: '#00c4b4', fillOpacity: 0.2, strokeColor: '#00c4b4', strokeWeight: 2, clickable: false, editable: false, zIndex: 1 },
        });
        drawingManager.setMap(map);

        window.google.maps.event.addListener(drawingManager, 'overlaycomplete', (event: any) => {
            if (activeShape) {
                activeShape.overlay.setMap(null);
            }
            setActiveShape({ overlay: event.overlay, type: event.type });
            drawingManager.setDrawingMode(null);
        });

    }, [isApiLoaded, activeShape]);

    useEffect(() => {
        if (!mapInstanceRef.current) return;

        markersRef.current.forEach(marker => marker.setMap(null));
        markersRef.current = [];
        
        const createMarkerIcon = (color: string, isDistress: boolean, isExpiry: boolean) => {
            if (isExpiry) {
                 return { url: `data:image/svg+xml;charset=UTF-8,${encodeURIComponent(`<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="white" width="28px" height="28px"><path d="M0 0h24v24H0z" fill="none"/><circle cx="12" cy="12" r="10" fill="%232563eb" stroke="%23fff" stroke-width="2"/><path d="M12 6v6h4.5" stroke="%23fff" stroke-width="2" fill="none" stroke-linecap="round"/><path d="M12 2a10 10 0 1 0 0 20 10 10 0 0 0 0-20z"/></svg>`)}`, scaledSize: new window.google.maps.Size(28, 28), anchor: new window.google.maps.Point(14, 14) };
            }
            const iconSvg = isDistress ? `<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="white" width="28px" height="28px"><path d="M0 0h24v24H0z" fill="none"/><circle cx="12" cy="12" r="10" fill="%23f59e0b" stroke="%23fff" stroke-width="2"/><path d="M11 15h2v2h-2zm0-8h2v6h-2z"/></svg>` : `<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="white" width="24px" height="24px"><circle cx="12" cy="12" r="8" fill="${color}" stroke="%23fff" stroke-width="2"/></svg>`;
            return { url: `data:image/svg+xml;charset=UTF-8,${encodeURIComponent(iconSvg)}`, scaledSize: new window.google.maps.Size(isDistress ? 28 : 24, isDistress ? 28 : 24), anchor: new window.google.maps.Point(isDistress ? 14 : 12, isDistress ? 14 : 12) };
        };

        const dataToProcess = dataSource === 'intel' ? [...intelFeed, ...distressFeed] : leaseExpiries;

        dataToProcess.forEach(item => {
            if (!item.coordinates || typeof item.coordinates.lat !== 'number' || typeof item.coordinates.lng !== 'number') return;
            const latLng = new window.google.maps.LatLng(item.coordinates.lat, item.coordinates.lng);
            
            // Shape filtering
            if (activeShape) {
                let isInside = false;
                const shapeType = activeShape.type;
                const shapeOverlay = activeShape.overlay;
                if (shapeType === 'polygon') isInside = window.google.maps.geometry.poly.containsLocation(latLng, shapeOverlay);
                else if (shapeType === 'rectangle') isInside = shapeOverlay.getBounds().contains(latLng);
                else if (shapeType === 'circle') isInside = window.google.maps.geometry.spherical.computeDistanceBetween(latLng, shapeOverlay.getCenter()) <= shapeOverlay.getRadius();
                if (!isInside) return;
            }

            // Text/Category filtering
            if (dataSource === 'intel') {
                const intelItem = item as IntelItem;
                if (searchTerm) {
                    const term = searchTerm.toLowerCase();
                    if (!`${intelItem.headline} ${intelItem.summary} ${intelItem.propertyType}`.toLowerCase().includes(term)) return;
                }
                let category: OperatorCategory | 'Default' = 'Default';
                const matchedOp = operators.find(op => new RegExp(`\\b${op.name}\\b`, 'i').test(intelItem.headline));
                if (matchedOp) category = matchedOp.category;
                else if (intelItem.sourceCategory !== 'Distress') category = getCategoryFromPropertyType(intelItem.propertyType);

                if (categoryFilter !== 'All' && category !== categoryFilter) return;

                const colorDef = OPERATOR_CATEGORY_COLORS[category] || OPERATOR_CATEGORY_COLORS.Default;
                const isDistress = intelItem.sourceCategory === 'Distress';
                const icon = createMarkerIcon(colorDef.accent.replace('bg-', '#'), isDistress, false);
                const popupContent = `<div class="p-1 font-sans"><div class="text-xs uppercase font-bold text-gray-500 mb-1 flex justify-between"><span>${intelItem.propertyType}</span><span style="color:${colorDef.text.replace('text-','')}">${category}</span></div><h3 class="font-bold text-brand-blue text-sm mb-2 leading-tight">${intelItem.headline}</h3><p class="text-xs text-gray-600 mb-3">${intelItem.summary}</p><div class="flex justify-between items-center border-t pt-2"><span class="font-bold text-xs text-gray-700">${(intelItem.sizeSqFt || 0).toLocaleString()} sqft</span><span class="text-xs bg-gray-100 px-2 py-1 rounded text-gray-600">${intelItem.confidenceScore}% Conf.</span></div></div>`;

                const marker = new window.google.maps.Marker({ position: latLng, map: mapInstanceRef.current, icon });
                marker.addListener('click', () => {
                    infoWindowRef.current.setContent(popupContent);
                    infoWindowRef.current.open(mapInstanceRef.current, marker);
                });
                markersRef.current.push(marker);

            } else { // dataSource === 'expiries'
                const expiryItem = item as LeaseExpiry;
                if (searchTerm) {
                    const term = searchTerm.toLowerCase();
                    if (!`${expiryItem.address} ${expiryItem.currentOccupier.name} ${expiryItem.landlord.name}`.toLowerCase().includes(term)) return;
                }

                const icon = createMarkerIcon('', false, true);
                const popupContent = `<div class="p-1 font-sans text-xs"><div class="font-bold text-red-600 mb-1 flex items-center"><svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke-width="2" stroke="currentColor" class="w-4 h-4 mr-1.5"><path stroke-linecap="round" stroke-linejoin="round" d="M12 6v6h4.5m4.5 0a9 9 0 1 1-18 0 9 9 0 0 1 18 0Z" /></svg>${expiryItem.timeRemaining} remaining</div><h3 class="font-bold text-brand-blue text-sm mb-2 leading-tight">${expiryItem.address}</h3><div class="space-y-1 text-gray-700"><div><strong>Occupier:</strong> ${expiryItem.currentOccupier.name}</div><div><strong>Landlord:</strong> ${expiryItem.landlord.name}</div><div><strong>Size:</strong> ${(expiryItem.sizeSqFt || 0).toLocaleString()} sqft</div><div><strong>Use:</strong> ${expiryItem.propertyType} (${expiryItem.useClass})</div></div></div>`;

                const marker = new window.google.maps.Marker({ position: latLng, map: mapInstanceRef.current, icon });
                marker.addListener('click', () => {
                    infoWindowRef.current.setContent(popupContent);
                    infoWindowRef.current.open(mapInstanceRef.current, marker);
                });
                markersRef.current.push(marker);
            }
        });
    }, [intelFeed, distressFeed, leaseExpiries, operators, activeShape, categoryFilter, searchTerm, dataSource, isApiLoaded]);

    const clearDrawing = () => {
        if (activeShape) {
            activeShape.overlay.setMap(null);
        }
        setActiveShape(null);
    };

    if (apiKeyError) {
        return (
            <div className="absolute inset-0 bg-white z-20 flex flex-col items-center justify-center p-8 text-center">
                <ExclamationTriangleIcon className="w-16 h-16 text-red-500 mb-4" />
                <h2 className="text-2xl font-bold text-gray-800">
                    {isKeyMissing ? "Google Maps API Key Missing" : "Google Maps API Error"}
                </h2>
                <p className="text-gray-600 mt-2 max-w-lg">
                    {isKeyMissing
                        ? "Please add your Google Maps JavaScript API key in the Settings page to enable the Map Index."
                        : "The map could not be loaded. This is usually caused by an invalid or restricted API key."
                    }
                </p>
                {isKeyMissing && setView && (
                    <button onClick={() => setView('SETTINGS')} className="mt-6 bg-brand-blue text-white font-bold py-2 px-6 rounded-lg shadow hover:bg-brand-blue/90 transition-colors">
                        Go to Settings
                    </button>
                )}
                <div className="mt-6 text-left bg-red-50 p-4 rounded-lg border border-red-200 text-sm">
                    <h4 className="font-bold text-red-800 mb-2">Troubleshooting Steps:</h4>
                    <ol className="list-decimal list-inside text-red-700 space-y-1">
                        {isKeyMissing ? (
                            <>
                                <li>Navigate to the <strong>Settings</strong> page.</li>
                                <li>Enter your key in the "Google Maps API Key" field.</li>
                            </>
                        ) : (
                            <>
                                <li>Ensure the API Key in <strong>Settings</strong> is correct and has no typos.</li>
                                <li>In your <strong>Google Cloud Console</strong>, verify that the "Maps JavaScript API" is enabled.</li>
                                <li>Check that your project has a valid <strong>billing account</strong> attached.</li>
                                <li>Make sure there are no HTTP referer restrictions on your API key.</li>
                            </>
                        )}
                    </ol>
                </div>
            </div>
        );
    }

    return (
        <div className="flex flex-col h-full relative bg-gray-200">
            <div className="absolute top-4 left-4 right-4 z-[5] flex flex-col md:flex-row gap-4 bg-white/95 backdrop-blur-sm p-4 rounded-xl shadow-xl border border-gray-200">
                <div className="bg-gray-200 p-1 rounded-lg flex">
                    <button onClick={() => setDataSource('intel')} className={`px-4 py-1.5 text-sm font-bold rounded-md transition-colors ${dataSource === 'intel' ? 'bg-white text-brand-blue shadow' : 'text-gray-600 hover:bg-gray-300'}`}>All Intel</button>
                    <button onClick={() => setDataSource('expiries')} className={`px-4 py-1.5 text-sm font-bold rounded-md transition-colors ${dataSource === 'expiries' ? 'bg-white text-brand-blue shadow' : 'text-gray-600 hover:bg-gray-300'}`}>Expiring Leases</button>
                </div>
                <div className="flex-1 relative">
                    <MagnifyingGlassIcon className="absolute left-3 top-1/2 transform -translate-y-1/2 w-5 h-5 text-gray-400" />
                    <input type="text" placeholder={dataSource === 'intel' ? "Search intel..." : "Search expiries..."} className="w-full pl-10 pr-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-brand-blue focus:border-transparent text-sm" value={searchTerm} onChange={(e) => setSearchTerm(e.target.value)} />
                </div>
                {dataSource === 'intel' && (
                    <div className="w-full md:w-48">
                        <select className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-brand-blue focus:border-transparent text-sm bg-white" value={categoryFilter} onChange={(e) => setCategoryFilter(e.target.value as any)}>
                            <option value="All">All Categories</option>
                            {CATEGORIES.map(c => <option key={c} value={c}>{c}</option>)}
                        </select>
                    </div>
                )}
                {activeShape && (
                    <button onClick={clearDrawing} className="p-2 bg-red-100 text-red-600 rounded-lg border border-red-200 hover:bg-red-200 transition-colors" title="Clear search area">
                        <TrashIcon className="w-5 h-5" />
                    </button>
                )}
            </div>
            <div ref={mapRef} className="flex-grow w-full h-full" />
        </div>
    );
};