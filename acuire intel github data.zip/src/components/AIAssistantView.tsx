
import React, { useState, useEffect, useRef } from 'react';
import type { ChatMessage, Operator, Deal, Requirement, IntelItem, TeamMember } from '../types';
import { getAIChatResponse } from '../services/geminiService';
import { ChatBubbleIcon, PaperAirplaneIcon, TrashIcon, UserGroupIcon, SparklesIcon } from './icons/Icons';
import ReactMarkdown from 'react-markdown';

interface AIAssistantViewProps {
    chatHistory: ChatMessage[];
    setChatHistory: React.Dispatch<React.SetStateAction<ChatMessage[]>>;
    operators: Operator[];
    deals: Deal[];
    intelFeed: IntelItem[];
    currentUser: TeamMember;
}

export const AIAssistantView: React.FC<AIAssistantViewProps> = ({
    chatHistory,
    setChatHistory,
    operators,
    deals,
    intelFeed,
    currentUser
}) => {
    const [input, setInput] = useState('');
    const [isTyping, setIsTyping] = useState(false);
    const messagesEndRef = useRef<HTMLDivElement>(null);

    const scrollToBottom = () => {
        messagesEndRef.current?.scrollIntoView({ behavior: "smooth" });
    };

    useEffect(() => {
        scrollToBottom();
    }, [chatHistory]);

    // Construct context summary for the AI
    const getContextSummary = () => {
        const activeDeals = deals.filter(d => d.status !== 'Rejected');
        const operatorNames = operators.map(o => o.name).join(', ');
        
        return `
            Current User: ${currentUser.name} (${currentUser.title}).
            Active Deals in Pipeline: ${activeDeals.length}.
            Key Active Deals: ${activeDeals.map(d => `${d.operator.name} at ${d.intel.headline} (${d.status})`).join('; ')}.
            Tracked Operators: ${operatorNames}.
            Recent Intel Items: ${intelFeed.slice(0, 5).map(i => i.headline).join('; ')}.
        `;
    };

    const handleSend = async (e?: React.FormEvent) => {
        e?.preventDefault();
        if (!input.trim()) return;

        const userMsg: ChatMessage = {
            id: `msg-${Date.now()}`,
            role: 'user',
            text: input,
            timestamp: new Date()
        };

        setChatHistory(prev => [...prev, userMsg]);
        setInput('');
        setIsTyping(true);

        // Simulate network delay for better UX
        // await new Promise(r => setTimeout(r, 500));

        const context = getContextSummary();
        const responseText = await getAIChatResponse(chatHistory, userMsg.text, context);

        const aiMsg: ChatMessage = {
            id: `msg-${Date.now()+1}`,
            role: 'model',
            text: responseText,
            timestamp: new Date()
        };

        setChatHistory(prev => [...prev, aiMsg]);
        setIsTyping(false);
    };

    const clearHistory = () => {
        if (confirm("Are you sure you want to clear the chat history?")) {
            setChatHistory([]);
        }
    };

    return (
        <div className="flex flex-col h-full bg-white rounded-lg shadow-lg overflow-hidden">
            {/* Header */}
            <div className="bg-brand-blue p-4 flex justify-between items-center shadow-md z-10">
                <div className="flex items-center text-white">
                    <div className="bg-white/10 p-2 rounded-lg mr-3">
                        <ChatBubbleIcon className="w-6 h-6" />
                    </div>
                    <div>
                        <h2 className="text-xl font-bold">AI Assistant</h2>
                        <p className="text-xs text-blue-200">Your commercial real estate copilot</p>
                    </div>
                </div>
                <button 
                    onClick={clearHistory}
                    className="text-blue-200 hover:text-white hover:bg-white/10 p-2 rounded-lg transition-colors"
                    title="Clear History"
                >
                    <TrashIcon className="w-5 h-5" />
                </button>
            </div>

            {/* Chat Area */}
            <div className="flex-1 overflow-y-auto p-4 bg-gray-50 space-y-4">
                {chatHistory.length === 0 && (
                    <div className="flex flex-col items-center justify-center h-full text-gray-400 opacity-60">
                        <SparklesIcon className="w-16 h-16 mb-4" />
                        <p className="text-lg font-medium">How can I help you today?</p>
                        <p className="text-sm mt-2">Try asking about recent deals or operator requirements.</p>
                    </div>
                )}
                
                {chatHistory.map(msg => (
                    <div 
                        key={msg.id} 
                        className={`flex ${msg.role === 'user' ? 'justify-end' : 'justify-start'}`}
                    >
                        <div className={`max-w-[80%] rounded-2xl p-4 shadow-sm ${
                            msg.role === 'user' 
                                ? 'bg-brand-blue text-white rounded-br-none' 
                                : 'bg-white text-gray-800 border border-gray-200 rounded-bl-none'
                        }`}>
                            <div className="text-xs opacity-50 mb-1 font-semibold uppercase tracking-wider">
                                {msg.role === 'user' ? currentUser.initials : 'AI Assistant'}
                            </div>
                            <div className={`prose prose-sm ${msg.role === 'user' ? 'prose-invert' : ''}`}>
                                <ReactMarkdown>{msg.text}</ReactMarkdown>
                            </div>
                            <div className="text-[10px] opacity-40 mt-2 text-right">
                                {new Date(msg.timestamp).toLocaleTimeString([], {hour: '2-digit', minute:'2-digit'})}
                            </div>
                        </div>
                    </div>
                ))}
                
                {isTyping && (
                    <div className="flex justify-start animate-pulse">
                        <div className="bg-gray-200 text-gray-500 rounded-2xl rounded-bl-none p-4 shadow-sm flex items-center space-x-2">
                            <div className="w-2 h-2 bg-gray-400 rounded-full animate-bounce"></div>
                            <div className="w-2 h-2 bg-gray-400 rounded-full animate-bounce" style={{ animationDelay: '0.2s' }}></div>
                            <div className="w-2 h-2 bg-gray-400 rounded-full animate-bounce" style={{ animationDelay: '0.4s' }}></div>
                        </div>
                    </div>
                )}
                <div ref={messagesEndRef} />
            </div>

            {/* Input Area */}
            <div className="p-4 bg-white border-t border-gray-200">
                <form onSubmit={handleSend} className="flex gap-2">
                    <input
                        type="text"
                        value={input}
                        onChange={(e) => setInput(e.target.value)}
                        placeholder="Ask about deals, operators, or market intel..."
                        className="flex-1 border border-gray-300 rounded-lg px-4 py-3 focus:ring-2 focus:ring-brand-blue focus:border-transparent outline-none"
                        disabled={isTyping}
                    />
                    <button 
                        type="submit"
                        disabled={!input.trim() || isTyping}
                        className="bg-brand-gold text-white px-6 rounded-lg hover:bg-teal-500 transition-colors disabled:opacity-50 disabled:cursor-not-allowed shadow-sm font-bold"
                    >
                        <PaperAirplaneIcon className="w-5 h-5" />
                    </button>
                </form>
            </div>
        </div>
    );
};
