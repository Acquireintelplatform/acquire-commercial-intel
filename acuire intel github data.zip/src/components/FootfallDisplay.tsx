import React from 'react';
import type { FootfallData } from '../types';

interface FootfallDisplayProps {
    data: FootfallData;
}

export const FootfallDisplay: React.FC<FootfallDisplayProps> = ({ data }) => {
    return (
        <div className="space-y-4 text-sm">
            <div className="grid grid-cols-2 gap-4">
                <div className="bg-white p-3 rounded-lg border">
                    <p className="text-xs text-gray-500">Weekday Average</p>
                    <p className="text-lg font-bold text-brand-blue">{(data.weekdayAverage || 0).toLocaleString()}</p>
                </div>
                <div className="bg-white p-3 rounded-lg border">
                    <p className="text-xs text-gray-500">Weekend Average</p>
                    <p className="text-lg font-bold text-brand-blue">{(data.weekendAverage || 0).toLocaleString()}</p>
                </div>
            </div>
            <div>
                <h5 className="font-semibold text-gray-600 mb-2">Category Density</h5>
                <div className="space-y-2">
                    {Object.entries(data.categoryDensity || {}).map(([category, value]) => (
                        <div key={category} className="flex items-center">
                            <span className="w-20 text-xs text-gray-500">{category}</span>
                            <div className="flex-1 bg-gray-200 rounded-full h-2.5">
                                <div className="bg-brand-teal h-2.5 rounded-full" style={{ width: `${value}%` }}></div>
                            </div>
                            <span className="w-10 text-right text-xs font-semibold">{value}%</span>
                        </div>
                    ))}
                </div>
            </div>
             <div className="bg-white p-3 rounded-lg border">
                <p className="text-xs text-gray-500">Year-on-Year Variance</p>
                <p className={`text-lg font-bold ${data.yoyVariance >= 0 ? 'text-green-600' : 'text-red-600'}`}>{data.yoyVariance >= 0 ? '+' : ''}{data.yoyVariance}%</p>
            </div>
            <div className="text-center text-[10px] text-gray-400 pt-2 border-t mt-4">
                Source: {data.dataSource} (Last Updated: {data.lastUpdated})
            </div>
        </div>
    );
};
