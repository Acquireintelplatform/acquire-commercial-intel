import React from 'react';
import type { LeaseExpiry } from '../types';
import { ArrowPathIcon, ClockIcon, BuildingOfficeIcon, ArrowsRightLeftIcon, IdentificationIcon, KeyIcon } from './icons/Icons';

interface LeaseExpiryViewProps {
    leaseExpiries: LeaseExpiry[];
    isLoading: boolean;
    onRefresh: () => void;
}

export const LeaseExpiryView: React.FC<LeaseExpiryViewProps> = ({ leaseExpiries, isLoading, onRefresh }) => {
    return (
        <div className="bg-white p-6 rounded-lg shadow-lg">
            <div className="flex justify-between items-center mb-6">
                <div>
                    <h2 className="text-3xl font-bold text-gray-800">Lease Expiry Radar</h2>
                    <p className="text-gray-600 mt-1">Off-market opportunities with upcoming lease expirations.</p>
                </div>
                <button
                    onClick={onRefresh}
                    disabled={isLoading}
                    className="flex items-center bg-brand-blue text-white px-4 py-2 rounded-lg shadow hover:bg-brand-blue/90 transition-all duration-200 disabled:bg-gray-400"
                >
                    <ArrowPathIcon className={`w-5 h-5 mr-2 ${isLoading ? 'animate-spin' : ''}`} />
                    {isLoading ? 'Refreshing...' : 'Refresh Radar'}
                </button>
            </div>
            
            <div className="overflow-x-auto border border-gray-200 rounded-lg">
                <table className="min-w-full bg-white">
                    <thead className="bg-gray-50 text-gray-600">
                        <tr>
                            <th className="text-left py-3 px-4 uppercase font-semibold text-sm">Address</th>
                            <th className="text-left py-3 px-4 uppercase font-semibold text-sm">Time Remaining</th>
                            <th className="text-left py-3 px-4 uppercase font-semibold text-sm">Occupier</th>
                            <th className="text-left py-3 px-4 uppercase font-semibold text-sm">Landlord</th>
                            <th className="text-left py-3 px-4 uppercase font-semibold text-sm">Details</th>
                        </tr>
                    </thead>
                    <tbody className="text-gray-700">
                        {leaseExpiries.map(item => (
                            <tr key={item.id} className="border-b border-gray-200 hover:bg-gray-50">
                                <td className="py-3 px-4 font-semibold text-brand-blue">{item.address}</td>
                                <td className="py-3 px-4">
                                    <div className="flex items-center font-bold text-red-600">
                                        <ClockIcon className="w-4 h-4 mr-2" />
                                        {item.timeRemaining}
                                    </div>
                                </td>
                                <td className="py-3 px-4">
                                     <div className="flex items-center">
                                        <IdentificationIcon className="w-4 h-4 mr-2 text-gray-400" />
                                        {item.currentOccupier.name}
                                    </div>
                                </td>
                                <td className="py-3 px-4">
                                    <div className="flex items-center">
                                        <KeyIcon className="w-4 h-4 mr-2 text-gray-400" />
                                        {item.landlord.name}
                                    </div>
                                </td>
                                <td className="py-3 px-4 text-sm">
                                    <div className="flex items-center gap-4 text-gray-600">
                                        <span className="flex items-center">
                                            <BuildingOfficeIcon className="w-4 h-4 mr-1 text-gray-400"/>
                                            {item.propertyType} ({item.useClass})
                                        </span>
                                        <span className="flex items-center">
                                            <ArrowsRightLeftIcon className="w-4 h-4 mr-1 text-gray-400"/>
                                            {(item.sizeSqFt || 0).toLocaleString()} sqft
                                        </span>
                                    </div>
                                </td>
                            </tr>
                        ))}
                    </tbody>
                </table>
                 {leaseExpiries.length === 0 && !isLoading && (
                    <div className="text-center py-8 text-gray-500">
                        No lease expiry data available. Click "Refresh Radar" to search for new opportunities.
                    </div>
                )}
                 {isLoading && leaseExpiries.length === 0 && (
                     <div className="text-center py-8 text-gray-500">
                        Scanning for lease expiry signals...
                    </div>
                 )}
            </div>
             <div className="mt-4 p-3 bg-yellow-50 border border-yellow-200 rounded-md text-sm text-yellow-800">
                <strong className="font-semibold">Disclaimer:</strong> Lease expiry data is AI-inferred from public news and announcements, not from official registries. Dates are estimates and require independent verification before action is taken.
            </div>
        </div>
    );
};