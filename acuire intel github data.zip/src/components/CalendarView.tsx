import React, { useState, useMemo } from 'react';
import type { Viewing, CalendarEvent, CalendarEventType } from '../types';
import { CalendarIcon, ChevronLeftIcon, ChevronRightIcon, ClockIcon, EnvelopeIcon, PlusIcon, XMarkIcon, ArrowDownTrayIcon } from './icons/Icons';

interface CalendarViewProps {
    viewings: Viewing[];
    calendarEvents: CalendarEvent[];
    setCalendarEvents: React.Dispatch<React.SetStateAction<CalendarEvent[]>>;
}

const EVENT_TYPE_COLORS: Record<CalendarEventType, string> = {
    'Viewing': 'bg-brand-gold',
    'Meeting': 'bg-blue-500',
    'Call': 'bg-green-500',
    'Task': 'bg-purple-500',
};

const generateICS = (event: CalendarEvent) => {
    const formatDate = (date: Date) => {
        return date.toISOString().replace(/-|:|\.\d\d\d/g,"");
    }

    const eventEndDate = new Date(event.date.getTime() + 60 * 60 * 1000); // Assume 1 hour duration

    const icsContent = [
        'BEGIN:VCALENDAR',
        'VERSION:2.0',
        'PRODID:-//Acquire Commercial Intel//EN',
        'BEGIN:VEVENT',
        `UID:${event.id}@acquire.com`,
        `DTSTAMP:${formatDate(new Date())}`,
        `DTSTART:${formatDate(event.date)}`,
        `DTEND:${formatDate(eventEndDate)}`,
        `SUMMARY:${event.title}`,
        `DESCRIPTION:${event.notes || ''}`,
        'END:VEVENT',
        'END:VCALENDAR'
    ].join('\r\n');

    const blob = new Blob([icsContent], { type: 'text/calendar;charset=utf-8' });
    const url = URL.createObjectURL(blob);
    const link = document.createElement('a');
    link.href = url;
    link.setAttribute('download', `${event.title.replace(/ /g, '_')}.ics`);
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
};


export const CalendarView: React.FC<CalendarViewProps> = ({ viewings, calendarEvents, setCalendarEvents }) => {
    const [currentDate, setCurrentDate] = useState(new Date());
    const [isAddModalOpen, setIsAddModalOpen] = useState(false);
    const [isDetailsModalOpen, setIsDetailsModalOpen] = useState(false);
    const [selectedDate, setSelectedDate] = useState<Date | null>(null);
    const [selectedEvent, setSelectedEvent] = useState<CalendarEvent | null>(null);

    const [newEventData, setNewEventData] = useState<{
        title: string;
        type: CalendarEventType;
        time: string;
        recipientEmail: string;
        notes: string;
    }>({ title: '', type: 'Meeting', time: '10:00', recipientEmail: '', notes: '' });

    const allEvents: CalendarEvent[] = useMemo(() => {
        const mappedViewings: CalendarEvent[] = viewings.map(v => ({
            id: v.id,
            title: v.operatorName,
            type: 'Viewing',
            date: new Date(v.date),
            notes: v.dealHeadline,
            dealId: v.dealId
        }));
        return [...mappedViewings, ...calendarEvents].sort((a,b) => a.date.getTime() - b.date.getTime());
    }, [viewings, calendarEvents]);

    const handlePrevMonth = () => setCurrentDate(new Date(currentDate.getFullYear(), currentDate.getMonth() - 1, 1));
    const handleNextMonth = () => setCurrentDate(new Date(currentDate.getFullYear(), currentDate.getMonth() + 1, 1));
    const handleToday = () => setCurrentDate(new Date());

    const openAddModalForDate = (date: Date) => {
        setSelectedDate(date);
        setIsAddModalOpen(true);
    };

    const openDetailsModal = (event: CalendarEvent) => {
        setSelectedEvent(event);
        setIsDetailsModalOpen(true);
    };
    
    const handleAddEvent = (e: React.FormEvent) => {
        e.preventDefault();
        if (!selectedDate || !newEventData.title) return;
        
        const [hours, minutes] = newEventData.time.split(':');
        const eventDate = new Date(selectedDate);
        eventDate.setHours(parseInt(hours, 10), parseInt(minutes, 10));

        const newEvent: CalendarEvent = {
            id: `event-${Date.now()}`,
            title: newEventData.title,
            type: newEventData.type,
            date: eventDate,
            recipientEmail: newEventData.recipientEmail,
            notes: newEventData.notes,
        };
        setCalendarEvents(prev => [...prev, newEvent]);
        setIsAddModalOpen(false);
        setNewEventData({ title: '', type: 'Meeting', time: '10:00', recipientEmail: '', notes: '' });
    };

    const renderCalendarGrid = () => {
        const month = currentDate.getMonth();
        const year = currentDate.getFullYear();
        const firstDayOfMonth = new Date(year, month, 1).getDay();
        const daysInMonth = new Date(year, month + 1, 0).getDate();
        const today = new Date();

        const cells = [];
        for (let i = 0; i < (firstDayOfMonth === 0 ? 6 : firstDayOfMonth - 1); i++) {
            cells.push(<div key={`empty-start-${i}`} className="border-r border-b border-gray-100"></div>);
        }

        for (let day = 1; day <= daysInMonth; day++) {
            const date = new Date(year, month, day);
            const isToday = date.toDateString() === today.toDateString();
            const eventsForDay = allEvents.filter(e => new Date(e.date).toDateString() === date.toDateString());

            cells.push(
                <div key={day} className="relative p-2 border-r border-b border-gray-100 h-32 flex flex-col group hover:bg-gray-50 transition-colors">
                    <time className={`text-sm font-semibold ${isToday ? 'bg-brand-blue text-white rounded-full w-6 h-6 flex items-center justify-center' : 'text-gray-600'}`}>
                        {day}
                    </time>
                    <div className="flex-grow overflow-y-auto mt-1 space-y-1">
                        {eventsForDay.map(event => (
                            <div key={event.id} onClick={() => openDetailsModal(event)} className={`p-1 rounded text-white text-[10px] font-bold truncate cursor-pointer ${EVENT_TYPE_COLORS[event.type]}`}>
                                {event.title}
                            </div>
                        ))}
                    </div>
                    <button onClick={() => openAddModalForDate(date)} className="absolute top-1 right-1 opacity-0 group-hover:opacity-100 transition-opacity bg-brand-gold text-white w-5 h-5 flex items-center justify-center rounded-full shadow">
                       <PlusIcon className="w-3 h-3"/>
                    </button>
                </div>
            );
        }
        return cells;
    };

    return (
        <div className="bg-white p-6 rounded-lg shadow-lg h-full flex flex-col">
            <div className="flex items-center justify-between mb-6">
                <div className="flex items-center">
                    <h2 className="text-3xl font-bold text-gray-800">{currentDate.toLocaleString('default', { month: 'long', year: 'numeric' })}</h2>
                    <div className="ml-4 flex items-center gap-1">
                        <button onClick={handlePrevMonth} className="p-2 rounded-full hover:bg-gray-100"><ChevronLeftIcon className="w-5 h-5" /></button>
                        <button onClick={handleToday} className="text-sm font-semibold px-3 py-1 border rounded-md hover:bg-gray-50">Today</button>
                        <button onClick={handleNextMonth} className="p-2 rounded-full hover:bg-gray-100"><ChevronRightIcon className="w-5 h-5" /></button>
                    </div>
                </div>
            </div>

            <div className="grid grid-cols-7 text-center font-bold text-gray-500 text-xs uppercase border-t border-b border-gray-200">
                {['Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat', 'Sun'].map(day => (
                    <div key={day} className="py-2">{day}</div>
                ))}
            </div>

            <div className="grid grid-cols-7 flex-grow border-l border-gray-100">
                {renderCalendarGrid()}
            </div>

            {/* Event Details Modal */}
            {isDetailsModalOpen && selectedEvent && (
                 <div className="fixed inset-0 bg-black bg-opacity-50 z-50 flex items-center justify-center p-4">
                    <div className="bg-white rounded-lg shadow-xl max-w-md w-full">
                        <div className="p-4 border-b flex justify-between items-center">
                             <h3 className="text-xl font-bold text-gray-800">Event Details</h3>
                             <button onClick={() => setIsDetailsModalOpen(false)}><XMarkIcon className="w-6 h-6 text-gray-500"/></button>
                        </div>
                        <div className="p-6 space-y-4">
                            <div>
                                <span className={`px-2 py-1 text-xs font-bold text-white rounded-full ${EVENT_TYPE_COLORS[selectedEvent.type]}`}>{selectedEvent.type}</span>
                            </div>
                            <h4 className="text-lg font-semibold">{selectedEvent.title}</h4>
                            <p className="text-sm text-gray-600 flex items-center"><ClockIcon className="w-4 h-4 mr-2"/> {selectedEvent.date.toLocaleString()}</p>
                            {selectedEvent.notes && <p className="text-sm text-gray-600 bg-gray-50 p-3 rounded-md">{selectedEvent.notes}</p>}
                            <div className="flex justify-end pt-4 gap-3">
                                <button onClick={() => setIsDetailsModalOpen(false)} className="px-4 py-2 text-gray-700 hover:bg-gray-100 rounded-md">Close</button>
                                <button onClick={() => generateICS(selectedEvent)} className="flex items-center px-4 py-2 bg-brand-blue text-white rounded-md hover:bg-brand-blue/90">
                                    <ArrowDownTrayIcon className="w-4 h-4 mr-2"/> Export Invite (.ics)
                                </button>
                            </div>
                        </div>
                    </div>
                 </div>
            )}

            {/* Add Event Modal */}
            {isAddModalOpen && selectedDate && (
                <div className="fixed inset-0 bg-black bg-opacity-50 z-50 flex items-center justify-center p-4">
                    <div className="bg-white rounded-lg shadow-xl max-w-md w-full p-6">
                        <div className="flex justify-between items-center mb-4">
                             <h3 className="text-xl font-bold text-gray-800">Add Event for {selectedDate.toLocaleDateString()}</h3>
                             <button onClick={() => setIsAddModalOpen(false)}><XMarkIcon className="w-6 h-6 text-gray-500"/></button>
                        </div>
                        <form onSubmit={handleAddEvent} className="space-y-4">
                            <div>
                                <label className="block text-sm font-medium text-gray-700">Title</label>
                                <input required type="text" className="mt-1 block w-full border border-gray-300 rounded-md shadow-sm p-2" value={newEventData.title} onChange={e => setNewEventData({...newEventData, title: e.target.value})} />
                            </div>
                             <div className="grid grid-cols-2 gap-4">
                                <div>
                                    <label className="block text-sm font-medium text-gray-700">Type</label>
                                    <select className="mt-1 block w-full border border-gray-300 rounded-md shadow-sm p-2" value={newEventData.type} onChange={e => setNewEventData({...newEventData, type: e.target.value as CalendarEventType})}>
                                        <option>Meeting</option><option>Call</option><option>Viewing</option><option>Task</option>
                                    </select>
                                </div>
                                <div>
                                    <label className="block text-sm font-medium text-gray-700">Time</label>
                                    <input required type="time" className="mt-1 block w-full border border-gray-300 rounded-md shadow-sm p-2" value={newEventData.time} onChange={e => setNewEventData({...newEventData, time: e.target.value})}/>
                                </div>
                             </div>
                            <div>
                                <label className="block text-sm font-medium text-gray-700">Recipient Email (Optional)</label>
                                <input type="email" placeholder="attendee@example.com" className="mt-1 block w-full border border-gray-300 rounded-md shadow-sm p-2" value={newEventData.recipientEmail} onChange={e => setNewEventData({...newEventData, recipientEmail: e.target.value})} />
                            </div>
                             <div>
                                <label className="block text-sm font-medium text-gray-700">Notes</label>
                                <textarea className="mt-1 block w-full border border-gray-300 rounded-md shadow-sm p-2" rows={3} value={newEventData.notes} onChange={e => setNewEventData({...newEventData, notes: e.target.value})} />
                            </div>
                            <div className="flex justify-end gap-3 mt-6">
                                <button type="button" onClick={() => setIsAddModalOpen(false)} className="px-4 py-2 text-gray-700 hover:bg-gray-100 rounded-md">Cancel</button>
                                <button type="submit" className="px-4 py-2 bg-brand-blue text-white rounded-md hover:bg-brand-blue/90">Save Event</button>
                            </div>
                        </form>
                    </div>
                </div>
            )}
        </div>
    );
};