import React, { useState, useMemo } from 'react';
import type { Landlord } from '../types';
import { initialLandlords } from '../constants';
import { ArrowDownTrayIcon, PlusIcon } from './icons/Icons';

interface LandlordsViewProps {
    landlords?: Landlord[];
    setLandlords?: React.Dispatch<React.SetStateAction<Landlord[]>>;
}

export const LandlordsView: React.FC<LandlordsViewProps> = ({ landlords = initialLandlords, setLandlords }) => {
    const [searchTerm, setSearchTerm] = useState('');
    
    // Add Landlord Modal State
    const [isModalOpen, setIsModalOpen] = useState(false);
    const [newLandlord, setNewLandlord] = useState<Partial<Landlord>>({});

    const filteredLandlords = useMemo(() => {
        return landlords.filter(ll => 
            ll.name.toLowerCase().includes(searchTerm.toLowerCase()) || 
            ll.focusNotes.toLowerCase().includes(searchTerm.toLowerCase())
        );
    }, [landlords, searchTerm]);

    const handleExport = () => {
        const headers = ["Landlord Name", "Contact Team", "Email", "Focus Notes", "Last Updated"];
        const csvContent = [
            headers.join(","),
            ...filteredLandlords.map(ll => [
                `"${ll.name}"`,
                `"${ll.contactTeam}"`,
                ll.email,
                `"${ll.focusNotes.replace(/"/g, '""')}"`,
                ll.lastUpdated
            ].join(","))
        ].join("\n");

        const blob = new Blob([csvContent], { type: "text/csv;charset=utf-8;" });
        const url = URL.createObjectURL(blob);
        const link = document.createElement("a");
        link.setAttribute("href", url);
        link.setAttribute("download", `landlords_master_${new Date().toISOString().split('T')[0]}.csv`);
        document.body.appendChild(link);
        link.click();
        document.body.removeChild(link);
    };

    const handleAddLandlord = (e: React.FormEvent) => {
        e.preventDefault();
        if (setLandlords && newLandlord.name && newLandlord.email) {
            const landlordToAdd: Landlord = {
                id: `ll-${Date.now()}`,
                name: newLandlord.name,
                contactTeam: newLandlord.contactTeam || 'Leasing Team',
                email: newLandlord.email,
                focusNotes: newLandlord.focusNotes || '',
                lastUpdated: new Date().toISOString().split('T')[0]
            };
            setLandlords(prev => [landlordToAdd, ...prev]);
            setIsModalOpen(false);
            setNewLandlord({});
        }
    };

    return (
        <div className="bg-white p-6 rounded-lg shadow-lg h-full flex flex-col">
            <div className="flex justify-between items-center mb-6">
                <div>
                    <h2 className="text-3xl font-bold text-gray-800">Landlords Master</h2>
                    <p className="text-gray-600 mt-1">Direct access to key asset management teams at major UK landlords.</p>
                </div>
                <div className="flex gap-2">
                    <button 
                        onClick={handleExport}
                        className="flex items-center bg-white text-gray-700 border border-gray-300 px-4 py-2 rounded-lg shadow-sm hover:bg-gray-50 transition-colors"
                    >
                        <ArrowDownTrayIcon className="w-5 h-5 mr-2" />
                        Export Database
                    </button>
                    {setLandlords && (
                        <button 
                            onClick={() => setIsModalOpen(true)}
                            className="flex items-center bg-brand-blue text-white px-4 py-2 rounded-lg shadow hover:bg-brand-blue/90 transition-all duration-200 font-medium"
                        >
                            <PlusIcon className="w-5 h-5 mr-2" />
                            Add Landlord
                        </button>
                    )}
                </div>
            </div>
            
            <div className="mb-6">
                <input
                    type="text"
                    placeholder="Search landlords or locations..."
                    value={searchTerm}
                    onChange={(e) => setSearchTerm(e.target.value)}
                    className="w-full md:w-1/3 px-4 py-2 border border-gray-300 rounded-lg shadow-sm focus:outline-none focus:ring-2 focus:ring-brand-blue focus:border-transparent"
                />
            </div>

            <div className="flex-grow overflow-auto border rounded-lg">
                <table className="min-w-full bg-white text-sm">
                    <thead className="bg-gray-100 text-gray-700 sticky top-0 z-10 shadow-sm">
                        <tr>
                            <th className="text-left py-3 px-4 font-bold uppercase">Landlord / Estate</th>
                            <th className="text-left py-3 px-4 font-bold uppercase">Contact Team</th>
                            <th className="text-left py-3 px-4 font-bold uppercase">Email</th>
                            <th className="text-left py-3 px-4 font-bold uppercase">Focus / Notes</th>
                            <th className="text-left py-3 px-4 font-bold uppercase">Last Updated</th>
                        </tr>
                    </thead>
                    <tbody className="text-gray-700 divide-y divide-gray-200">
                        {filteredLandlords.map(ll => (
                            <tr key={ll.id} className="hover:bg-gray-50 transition-colors">
                                <td className="py-3 px-4 font-bold text-brand-blue">{ll.name}</td>
                                <td className="py-3 px-4">{ll.contactTeam}</td>
                                <td className="py-3 px-4">
                                    <a href={`mailto:${ll.email}`} className="text-blue-600 hover:underline hover:text-blue-800">
                                        {ll.email}
                                    </a>
                                </td>
                                <td className="py-3 px-4 text-gray-600">{ll.focusNotes}</td>
                                <td className="py-3 px-4 text-gray-500 text-xs">{ll.lastUpdated}</td>
                            </tr>
                        ))}
                    </tbody>
                </table>
                {filteredLandlords.length === 0 && (
                    <div className="p-8 text-center text-gray-500">
                        No landlords found matching your search.
                    </div>
                )}
            </div>
            
            <div className="mt-4 p-3 bg-blue-50 border border-blue-200 rounded-md text-xs text-blue-800 flex items-center">
                <span className="font-bold mr-1">Note:</span> This database replaces your external spreadsheets. Data is secure and integrated directly into the Opportunity Finder.
            </div>

            {/* Add Landlord Modal */}
            {isModalOpen && (
                <div className="fixed inset-0 bg-black bg-opacity-50 z-50 flex items-center justify-center p-4">
                    <div className="bg-white rounded-lg shadow-xl max-w-md w-full p-6">
                        <h3 className="text-xl font-bold text-gray-800 mb-4">Add New Landlord</h3>
                        <form onSubmit={handleAddLandlord} className="space-y-4">
                            <div>
                                <label className="block text-sm font-medium text-gray-700">Landlord / Estate Name</label>
                                <input 
                                    required 
                                    type="text" 
                                    className="mt-1 block w-full border border-gray-300 rounded-md shadow-sm p-2 focus:ring-brand-blue focus:border-brand-blue"
                                    value={newLandlord.name || ''}
                                    onChange={e => setNewLandlord({...newLandlord, name: e.target.value})}
                                />
                            </div>
                            <div>
                                <label className="block text-sm font-medium text-gray-700">Contact Team</label>
                                <input 
                                    type="text" 
                                    placeholder="e.g. Asset Management"
                                    className="mt-1 block w-full border border-gray-300 rounded-md shadow-sm p-2 focus:ring-brand-blue focus:border-brand-blue"
                                    value={newLandlord.contactTeam || ''}
                                    onChange={e => setNewLandlord({...newLandlord, contactTeam: e.target.value})}
                                />
                            </div>
                            <div>
                                <label className="block text-sm font-medium text-gray-700">Email Address</label>
                                <input 
                                    required 
                                    type="email" 
                                    className="mt-1 block w-full border border-gray-300 rounded-md shadow-sm p-2 focus:ring-brand-blue focus:border-brand-blue"
                                    value={newLandlord.email || ''}
                                    onChange={e => setNewLandlord({...newLandlord, email: e.target.value})}
                                />
                            </div>
                            <div>
                                <label className="block text-sm font-medium text-gray-700">Focus / Notes</label>
                                <textarea 
                                    className="mt-1 block w-full border border-gray-300 rounded-md shadow-sm p-2 focus:ring-brand-blue focus:border-brand-blue"
                                    rows={3}
                                    placeholder="e.g. Key assets, regional focus..."
                                    value={newLandlord.focusNotes || ''}
                                    onChange={e => setNewLandlord({...newLandlord, focusNotes: e.target.value})}
                                />
                            </div>
                            <div className="flex justify-end gap-3 mt-6">
                                <button type="button" onClick={() => setIsModalOpen(false)} className="px-4 py-2 text-gray-700 hover:bg-gray-100 rounded-md">Cancel</button>
                                <button type="submit" className="px-4 py-2 bg-brand-blue text-white rounded-md hover:bg-brand-blue/90">Save Landlord</button>
                            </div>
                        </form>
                    </div>
                </div>
            )}
        </div>
    );
};