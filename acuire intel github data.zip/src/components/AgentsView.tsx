import React, { useState, useMemo } from 'react';
import type { Agent, OperatorCategory } from '../types';
import { OPERATOR_CATEGORY_COLORS } from '../constants';
import { PlusIcon, ArrowDownTrayIcon } from './icons/Icons';

interface AgentsViewProps {
    agents: Agent[];
    setAgents?: React.Dispatch<React.SetStateAction<Agent[]>>;
}

const CATEGORIES: OperatorCategory[] = ['Restaurant', 'Coffee', 'QSR', 'Retail', 'Leisure', 'Pubs', 'Gyms', 'Nursery', 'Mixed'];

export const AgentsView: React.FC<AgentsViewProps> = ({ agents, setAgents }) => {
    const [nameFilter, setNameFilter] = useState('');
    const [companyFilter, setCompanyFilter] = useState('');
    const [categoryFilter, setCategoryFilter] = useState<OperatorCategory | ''>('');
    
    // Modal State
    const [isModalOpen, setIsModalOpen] = useState(false);
    const [newAgent, setNewAgent] = useState<Partial<Agent>>({
        category: 'Retail'
    });

    const filteredAgents = useMemo(() => {
        return agents.filter(agent => {
            const nameMatch = agent.name.toLowerCase().includes(nameFilter.toLowerCase());
            const companyMatch = agent.company.toLowerCase().includes(companyFilter.toLowerCase());
            const categoryMatch = !categoryFilter || agent.category === categoryFilter;
            return nameMatch && companyMatch && categoryMatch;
        });
    }, [agents, nameFilter, companyFilter, categoryFilter]);

    const handleAddAgent = (e: React.FormEvent) => {
        e.preventDefault();
        if (setAgents && newAgent.name && newAgent.company && newAgent.email) {
            const agentToAdd: Agent = {
                id: `ag-${Date.now()}`,
                name: newAgent.name,
                company: newAgent.company,
                email: newAgent.email,
                phone: newAgent.phone || '',
                category: newAgent.category as OperatorCategory,
            };
            setAgents(prev => [agentToAdd, ...prev]);
            setIsModalOpen(false);
            setNewAgent({ category: 'Retail' }); // Reset form
        }
    };

    const handleExport = () => {
        const headers = ["Name", "Company", "Category", "Phone", "Email"];
        const csvContent = [
            headers.join(","),
            ...filteredAgents.map(ag => [
                `"${ag.name}"`,
                `"${ag.company}"`,
                ag.category,
                `"${ag.phone}"`,
                ag.email
            ].join(","))
        ].join("\n");

        const blob = new Blob([csvContent], { type: "text/csv;charset=utf-8;" });
        const url = URL.createObjectURL(blob);
        const link = document.createElement("a");
        link.setAttribute("href", url);
        link.setAttribute("download", `acquisition_agents_export_${new Date().toISOString().split('T')[0]}.csv`);
        document.body.appendChild(link);
        link.click();
        document.body.removeChild(link);
    };

    return (
        <div className="bg-white p-6 rounded-lg shadow-lg">
            <div className="flex justify-between items-center mb-6">
                <div>
                    <h2 className="text-3xl font-bold text-gray-800">Acquisition Agents</h2>
                    <p className="text-gray-600 mt-1">A master list of key acquisition agents in the UK market.</p>
                </div>
                <div className="flex gap-2">
                    <button 
                        onClick={handleExport}
                        className="flex items-center bg-white text-gray-700 border border-gray-300 px-4 py-2 rounded-lg shadow-sm hover:bg-gray-50 transition-colors"
                    >
                        <ArrowDownTrayIcon className="w-5 h-5 mr-2" />
                        Export Contacts
                    </button>
                    <button 
                        onClick={() => setIsModalOpen(true)}
                        className="flex items-center bg-brand-blue text-white px-4 py-2 rounded-lg hover:bg-brand-blue/90 transition-colors shadow-md"
                    >
                        <PlusIcon className="w-5 h-5 mr-2" />
                        Add New Agent
                    </button>
                </div>
            </div>
            
            <div className="grid grid-cols-1 md:grid-cols-3 gap-4 mb-6 p-4 bg-gray-50 rounded-lg border">
                <input
                    type="text"
                    placeholder="Filter by Agent Name..."
                    value={nameFilter}
                    onChange={(e) => setNameFilter(e.target.value)}
                    className="px-3 py-2 border border-gray-300 rounded-md shadow-sm focus:outline-none focus:ring-brand-blue focus:border-brand-blue"
                />
                <input
                    type="text"
                    placeholder="Filter by Company..."
                    value={companyFilter}
                    onChange={(e) => setCompanyFilter(e.target.value)}
                    className="px-3 py-2 border border-gray-300 rounded-md shadow-sm focus:outline-none focus:ring-brand-blue focus:border-brand-blue"
                />
                 <select
                    value={categoryFilter}
                    onChange={(e) => setCategoryFilter(e.target.value as OperatorCategory | '')}
                    className="px-3 py-2 border border-gray-300 rounded-md shadow-sm focus:outline-none focus:ring-brand-blue focus:border-brand-blue bg-white"
                >
                    <option value="">All Categories</option>
                    {CATEGORIES.map(cat => <option key={cat} value={cat}>{cat}</option>)}
                </select>
            </div>

            <div className="overflow-x-auto">
                <table className="min-w-full bg-white">
                    <thead className="bg-indigo-100 text-indigo-800">
                        <tr>
                            <th className="text-left py-3 px-4 uppercase font-semibold text-sm">Name</th>
                            <th className="text-left py-3 px-4 uppercase font-semibold text-sm">Company</th>
                            <th className="text-left py-3 px-4 uppercase font-semibold text-sm">Category</th>
                            <th className="text-left py-3 px-4 uppercase font-semibold text-sm">Contact Details</th>
                        </tr>
                    </thead>
                    <tbody className="text-gray-700">
                        {filteredAgents.map(agent => {
                            const color = OPERATOR_CATEGORY_COLORS[agent.category] || OPERATOR_CATEGORY_COLORS.Default;
                            return (
                                <tr key={agent.id} className="border-b border-gray-200 hover:bg-gray-50">
                                    <td className="py-3 px-4 font-semibold">{agent.name}</td>
                                    <td className="py-3 px-4">{agent.company}</td>
                                    <td className="py-3 px-4">
                                        <div className="flex items-center">
                                            <span className={`w-3 h-3 rounded-full mr-3 ${color.accent}`}></span>
                                            {agent.category}
                                        </div>
                                    </td>
                                    <td className="py-3 px-4 text-sm">
                                        <a href={`mailto:${agent.email}`} className="text-brand-blue hover:underline block">{agent.email}</a>
                                        <a href={`tel:${agent.phone.replace(/\s/g, '')}`} className="text-gray-600 hover:underline block mt-1">{agent.phone}</a>
                                    </td>
                                </tr>
                            );
                        })}
                    </tbody>
                </table>
                 {filteredAgents.length === 0 && (
                    <div className="text-center py-8 text-gray-500">
                        No agents match the current filters.
                    </div>
                )}
            </div>

            {/* Add Agent Modal */}
            {isModalOpen && (
                <div className="fixed inset-0 bg-black bg-opacity-50 z-50 flex items-center justify-center p-4">
                    <div className="bg-white rounded-lg shadow-xl max-w-md w-full p-6">
                        <h3 className="text-xl font-bold text-gray-800 mb-4">Add New Agent</h3>
                        <form onSubmit={handleAddAgent} className="space-y-4">
                            <div>
                                <label className="block text-sm font-medium text-gray-700">Full Name</label>
                                <input 
                                    required 
                                    type="text" 
                                    className="mt-1 block w-full border border-gray-300 rounded-md shadow-sm p-2 focus:ring-brand-blue focus:border-brand-blue"
                                    value={newAgent.name || ''}
                                    onChange={e => setNewAgent({...newAgent, name: e.target.value})}
                                />
                            </div>
                            <div>
                                <label className="block text-sm font-medium text-gray-700">Company</label>
                                <input 
                                    required 
                                    type="text" 
                                    className="mt-1 block w-full border border-gray-300 rounded-md shadow-sm p-2 focus:ring-brand-blue focus:border-brand-blue"
                                    value={newAgent.company || ''}
                                    onChange={e => setNewAgent({...newAgent, company: e.target.value})}
                                />
                            </div>
                            <div>
                                <label className="block text-sm font-medium text-gray-700">Email Address</label>
                                <input 
                                    required 
                                    type="email" 
                                    className="mt-1 block w-full border border-gray-300 rounded-md shadow-sm p-2 focus:ring-brand-blue focus:border-brand-blue"
                                    value={newAgent.email || ''}
                                    onChange={e => setNewAgent({...newAgent, email: e.target.value})}
                                />
                            </div>
                            <div>
                                <label className="block text-sm font-medium text-gray-700">Phone Number</label>
                                <input 
                                    type="text" 
                                    className="mt-1 block w-full border border-gray-300 rounded-md shadow-sm p-2 focus:ring-brand-blue focus:border-brand-blue"
                                    value={newAgent.phone || ''}
                                    onChange={e => setNewAgent({...newAgent, phone: e.target.value})}
                                />
                            </div>
                            <div>
                                <label className="block text-sm font-medium text-gray-700">Speciality Category</label>
                                <select 
                                    className="mt-1 block w-full border border-gray-300 rounded-md shadow-sm p-2 focus:ring-brand-blue focus:border-brand-blue"
                                    value={newAgent.category}
                                    onChange={e => setNewAgent({...newAgent, category: e.target.value as OperatorCategory})}
                                >
                                    {CATEGORIES.map(cat => <option key={cat} value={cat}>{cat}</option>)}
                                </select>
                            </div>
                            <div className="flex justify-end gap-3 mt-6">
                                <button type="button" onClick={() => setIsModalOpen(false)} className="px-4 py-2 text-gray-700 hover:bg-gray-100 rounded-md">Cancel</button>
                                <button type="submit" className="px-4 py-2 bg-brand-blue text-white rounded-md hover:bg-brand-blue/90">Save Agent</button>
                            </div>
                        </form>
                    </div>
                </div>
            )}
        </div>
    );
};