import React from 'react';
import type { Alert, View, Deal, Operator } from '../types';
import { ArrowPathIcon, BuildingOfficeIcon, MapPinIcon, ArrowsRightLeftIcon, BriefcaseIcon, CheckCircleIcon, ExclamationTriangleIcon, ClockIcon, ChartBarIcon, IdentificationIcon } from './icons/Icons';
import { OPERATOR_CATEGORY_COLORS } from '../constants';

// --- WIDGETS ---
const MetricWidget: React.FC<{ icon: React.ReactElement; label: string; value: string | number; color: string; }> = ({ icon, label, value, color }) => (
    <div className="bg-white p-4 rounded-lg shadow-md border-l-4 flex items-center" style={{ borderColor: color }}>
        <div className={`p-3 rounded-full mr-4`} style={{ backgroundColor: `${color}20`}}>
            <div className="w-6 h-6" style={{ color }}>
                {icon}
            </div>
        </div>
        <div>
            <p className="text-3xl font-bold text-gray-800">{value}</p>
            <p className="text-sm font-medium text-gray-500">{label}</p>
        </div>
    </div>
);

// --- STATUS BAR ---
interface StatusBarProps {
    error: string | null;
    lastSync: Date | null;
    secondsUntilRefresh: number;
    setView: (view: View) => void;
}

const StatusBar: React.FC<StatusBarProps> = ({ error, lastSync, secondsUntilRefresh, setView }) => {
    const minutes = Math.floor(secondsUntilRefresh / 60);
    const seconds = secondsUntilRefresh % 60;

    const statusConfig = error
        ? {
            Icon: ExclamationTriangleIcon,
            bgColor: 'bg-red-50',
            borderColor: 'border-red-200',
            textColor: 'text-red-700',
            label: 'Configuration Required',
            message: 'System requires attention.',
        }
        : {
            Icon: CheckCircleIcon,
            bgColor: 'bg-green-50',
            borderColor: 'border-green-200',
            textColor: 'text-green-700',
            label: 'Authenticated & Online',
            message: 'All systems operational.',
        };

    return (
        <div className="mb-6 grid grid-cols-1 md:grid-cols-3 gap-4">
            <div className={`p-3 rounded-lg border flex items-center ${statusConfig.bgColor} ${statusConfig.borderColor}`}>
                <statusConfig.Icon className={`w-8 h-8 mr-3 ${statusConfig.textColor}`} />
                <div>
                    <p className={`font-bold text-sm ${statusConfig.textColor}`}>{statusConfig.label}</p>
                    <p className="text-xs text-gray-600">{statusConfig.message}</p>
                    {error && (
                         <button onClick={() => setView('SETTINGS')} className="text-xs font-bold text-red-600 hover:underline">Go to Settings</button>
                    )}
                </div>
            </div>
             <div className="p-3 rounded-lg border bg-white flex items-center">
                <ClockIcon className="w-8 h-8 mr-3 text-gray-400" />
                <div>
                    <p className="font-bold text-sm text-gray-800">Last Sync</p>
                    <p className="text-xs text-gray-600">{lastSync ? lastSync.toLocaleTimeString() : 'Pending...'}</p>
                </div>
            </div>
             <div className="p-3 rounded-lg border bg-white flex items-center">
                <ArrowPathIcon className="w-8 h-8 mr-3 text-gray-400" />
                <div>
                    <p className="font-bold text-sm text-gray-800">Next Scheduled Refresh</p>
                    <p className="text-xs text-gray-600">in {minutes}:{seconds.toString().padStart(2, '0')}</p>
                </div>
            </div>
        </div>
    );
};

// --- ALERT CARD ---
interface AlertCardProps {
     alert: Alert; 
     onAddToDealFlow: (alertId: string) => void; 
}
const AlertCard: React.FC<AlertCardProps> = ({ alert, onAddToDealFlow }) => {
    const { intel, operator, requirement } = alert;
    const categoryColor = OPERATOR_CATEGORY_COLORS[operator.category] || OPERATOR_CATEGORY_COLORS.Default;

    return (
        <div className="bg-white rounded-lg shadow-md hover:shadow-xl transition-shadow duration-300 overflow-hidden border flex flex-col">
            <div className="p-4 flex-grow">
                 <div className="flex justify-between items-start">
                    <span className={`text-xs font-bold px-2 py-1 rounded-full ${categoryColor.bg} ${categoryColor.text} border ${categoryColor.border}`}>
                        {operator.category}
                    </span>
                     <div className="text-right">
                        <p className="text-xs text-gray-500">Confidence</p>
                        <p className="font-bold text-gray-800">{intel.confidenceScore}%</p>
                    </div>
                </div>
                <h3 className="text-md font-bold text-brand-blue mt-2">{intel.headline}</h3>
                <p className="text-sm font-semibold text-gray-700 mt-2">Operator Match: {operator.name}</p>
                <div className="flex items-center text-xs text-gray-500 mt-2">
                   <BuildingOfficeIcon className="w-4 h-4 mr-2" />
                   <span>{intel.propertyType}</span>
                   <span className="mx-2">|</span>
                   <ArrowsRightLeftIcon className="w-4 h-4 mr-2" />
                   <span>{intel.sizeSqFt.toLocaleString()} sqft</span>
                </div>
            </div>
            <div className="bg-gray-50 px-4 py-2 flex justify-between items-center text-sm">
                <p className="text-gray-600 text-xs">Source: <span className="font-semibold">{intel.source}</span></p>
                <button onClick={() => onAddToDealFlow(alert.id)} className="flex items-center text-xs bg-green-100 text-green-800 font-semibold px-2 py-1 rounded-md hover:bg-green-200 transition-colors" title="Add to Deal Flow">
                    <BriefcaseIcon className="w-3 h-3 mr-1.5"/>
                    Track
                </button>
            </div>
        </div>
    );
};

// --- MAIN DASHBOARD COMPONENT ---
interface DashboardProps {
    alerts: Alert[];
    deals: Deal[];
    operators: Operator[];
    isLoading: boolean;
    error: string | null;
    onRefresh: () => void;
    onAddToDealFlow: (alertId: string) => void;
    setView: (view: View) => void;
    secondsUntilRefresh: number;
    lastSync?: Date | null;
}

export const Dashboard: React.FC<DashboardProps> = ({ alerts, deals, operators, isLoading, error, onRefresh, onAddToDealFlow, setView, secondsUntilRefresh, lastSync }) => {
    const highRiskOperators = operators.filter(op => (op.distressScore || 0) > 70).length;
    
    return (
        <div>
            <div className="flex justify-between items-center mb-4">
                <h2 className="text-3xl font-bold text-gray-800">Command Center</h2>
                <button
                    onClick={onRefresh}
                    disabled={isLoading}
                    className="flex items-center bg-brand-blue text-white px-4 py-2 rounded-lg shadow hover:bg-brand-blue/90 transition-all duration-200 disabled:bg-gray-400 disabled:cursor-not-allowed"
                >
                    <ArrowPathIcon className={`w-5 h-5 mr-2 ${isLoading ? 'animate-spin' : ''}`} />
                    {isLoading ? 'Refreshing...' : 'Refresh Intel'}
                </button>
            </div>
            
            <StatusBar error={error} lastSync={lastSync} secondsUntilRefresh={secondsUntilRefresh} setView={setView} />

            <div className="mb-6 grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
                <MetricWidget icon={<ExclamationTriangleIcon />} label="High-Confidence Alerts" value={alerts.length} color="#00c4b4" />
                <MetricWidget icon={<BriefcaseIcon />} label="Active Deals in Pipeline" value={deals.filter(d => d.status !== 'Rejected' && d.status !== 'Acquired').length} color="#1a3a6e" />
                <MetricWidget icon={<IdentificationIcon />} label="Tracked Operators" value={operators.length} color="#4f46e5" />
                <MetricWidget icon={<ExclamationTriangleIcon />} label="High-Risk Operators" value={highRiskOperators} color="#ef4444" />
            </div>
            
            <h3 className="text-2xl font-bold text-gray-800 mb-4">High-Priority Alerts</h3>

            {isLoading && alerts.length === 0 && (
                 <div className="text-center py-10 bg-white rounded-lg shadow-md">
                    <p className="text-gray-600">Fetching first batch of intel...</p>
                 </div>
            )}

            {!isLoading && alerts.length === 0 && !error && (
                 <div className="text-center py-10 bg-white rounded-lg shadow-md">
                    <h3 className="text-xl font-semibold text-gray-700">No High-Confidence Alerts</h3>
                    <p className="text-gray-500 mt-2">The system is monitoring all sources. New alerts will appear here as they are found.</p>
                 </div>
            )}

            <div className="grid grid-cols-1 lg:grid-cols-2 2xl:grid-cols-3 gap-6">
                {alerts.map(alert => (
                    <AlertCard key={alert.id} alert={alert} onAddToDealFlow={onAddToDealFlow} />
                ))}
            </div>
        </div>
    );
};