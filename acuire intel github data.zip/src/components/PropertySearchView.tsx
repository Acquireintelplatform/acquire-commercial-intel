import React, { useState, useEffect } from 'react';
import { MagnifyingGlassIcon, BuildingOfficeIcon, ArrowsRightLeftIcon, ArrowPathIcon, XMarkIcon, SparklesIcon, BriefcaseIcon, UserGroupIcon } from './icons/Icons';
import type { IntelItem, Operator, Requirement, FootfallData, PotentialMatch } from '../types';
import { searchProperties, getFootfallAnalysis, findOperatorMatches } from '../services/geminiService';
import { PROPERTY_TYPE_MAPPING, OPERATOR_CATEGORY_COLORS } from '../constants';
import { FootfallDisplay } from './FootfallDisplay';

interface PropertySearchViewProps {
    onAddToDealFlow: (intelItem: IntelItem, operator: Operator, requirement: Requirement) => void;
    operators: Operator[];
    requirements: Requirement[];
    serpApiKey?: string;
}

// --- Property Card Component ---
const PropertyCard: React.FC<{ item: IntelItem; onSelect: () => void }> = ({ item, onSelect }) => {
    return (
        <div onClick={onSelect} className="bg-white rounded-lg shadow-md hover:shadow-xl transition-shadow duration-300 overflow-hidden border-l-4 border-brand-teal cursor-pointer flex flex-col">
            <div className="p-5 flex-grow">
                <div className="flex justify-between items-start">
                    <p className="text-xs font-bold text-brand-teal uppercase tracking-wider">{item.propertyType}</p>
                    <span className="text-xs text-gray-500 bg-gray-100 px-2 py-1 rounded">{item.dateListed || 'Recent'}</span>
                </div>
                <h3 className="text-md font-bold text-brand-blue mt-2 leading-tight">{item.headline}</h3>
                <div className="flex items-center text-sm text-gray-600 mt-3">
                    <ArrowsRightLeftIcon className="w-4 h-4 mr-2 text-gray-400" />
                    <span>{(item.sizeSqFt || 0).toLocaleString()} sqft</span>
                    <span className="mx-2">|</span>
                    <span className="font-semibold">{item.useClass || 'N/A'}</span>
                </div>
                <p className="text-gray-600 mt-3 text-sm line-clamp-3">{item.summary}</p>
            </div>
            <div className="bg-gray-50 px-5 py-3 flex justify-between items-center text-sm">
                <p className="text-gray-600">Source: <span className="font-semibold">{item.source}</span></p>
                <span className="text-brand-blue hover:text-brand-gold font-semibold transition-colors">
                    View Details &rarr;
                </span>
            </div>
        </div>
    );
};


// --- Property Details Modal Component ---
interface PropertyDetailsModalProps {
    property: IntelItem;
    onClose: () => void;
    onAddToDealFlow: (intelItem: IntelItem, operator: Operator, requirement: Requirement) => void;
    matches: PotentialMatch[];
    isMatching: boolean;
    hasSearchedMatches: boolean;
    onFindMatches: (property: IntelItem) => void;
}
const PropertyDetailsModal: React.FC<PropertyDetailsModalProps> = ({ 
    property, onClose, onAddToDealFlow,
    matches, isMatching, hasSearchedMatches, onFindMatches
}) => {

    const handleTrackDeal = (match: PotentialMatch) => {
        onAddToDealFlow(property, match.operator, match.requirement);
        onClose();
    };

    return (
        <div className="fixed inset-0 bg-black bg-opacity-60 z-50 flex items-center justify-center p-4">
            <div className="bg-white rounded-lg shadow-2xl max-w-4xl w-full h-[90vh] flex flex-col">
                <div className="p-4 border-b flex justify-between items-start">
                    <div>
                        <h2 className="text-xl font-bold text-brand-blue">{property.headline}</h2>
                        <p className="text-sm text-gray-500">{property.propertyType} | {(property.sizeSqFt || 0).toLocaleString()} sqft</p>
                    </div>
                    <button onClick={onClose} className="p-1 rounded-full hover:bg-gray-200"><XMarkIcon className="w-6 h-6 text-gray-600" /></button>
                </div>
                <div className="flex-grow grid grid-cols-1 md:grid-cols-2 overflow-hidden">
                    <div className="p-6 overflow-y-auto border-r">
                        <div className="space-y-6">
                            <div>
                                <h4 className="font-bold text-gray-700 mb-2">Summary</h4>
                                <p className="text-gray-600 text-sm leading-relaxed">{property.summary}</p>
                            </div>
                            <div className="grid grid-cols-2 gap-4 text-sm">
                                <div className="bg-gray-50 p-3 rounded-md border"><span className="block font-semibold text-gray-800">{(property.sizeSqFt || 0).toLocaleString()} sqft</span><span className="text-xs text-gray-500">Size</span></div>
                                <div className="bg-gray-50 p-3 rounded-md border"><span className="block font-semibold text-gray-800">{property.useClass || 'N/A'}</span><span className="text-xs text-gray-500">Use Class</span></div>
                                <div className="bg-gray-50 p-3 rounded-md border"><span className="block font-semibold text-gray-800">{property.source}</span><span className="text-xs text-gray-500">Source</span></div>
                                <div className="bg-gray-50 p-3 rounded-md border"><span className="block font-semibold text-gray-800">{property.dateListed}</span><span className="text-xs text-gray-500">Listed</span></div>
                            </div>
                            <div className="pt-4 border-t">
                                <a href={property.url} target="_blank" rel="noopener noreferrer" className="text-brand-blue hover:underline font-semibold text-sm">
                                    View Canonical Source URL &rarr;
                                </a>
                            </div>
                            {property.agent && (
                                <div className="pt-4 border-t">
                                    <h4 className="font-bold text-gray-700 mb-2">Agent Details</h4>
                                    <p className="text-gray-600 text-sm">{property.agent.name}, {property.agent.company}</p>
                                    <div className="flex gap-4 mt-1">
                                    <a href={`tel:${property.agent.phone}`} className="text-brand-blue hover:underline text-sm">{property.agent.phone}</a>
                                    <a href={`mailto:${property.agent.email}`} className="text-brand-blue hover:underline text-sm">{property.agent.email}</a>
                                    </div>
                                </div>
                            )}
                        </div>
                    </div>
                    <div className="p-6 bg-gray-50 overflow-y-auto flex flex-col">
                         <h4 className="font-bold text-gray-700 mb-4 flex-shrink-0">Matching Engine</h4>
                         <div className="flex-grow">
                            {!hasSearchedMatches && !isMatching && (
                                <div className="text-center h-full flex flex-col justify-center items-center">
                                    <UserGroupIcon className="w-12 h-12 mx-auto mb-3 text-gray-300"/>
                                    <p className="text-sm text-gray-500 mb-4 max-w-xs">Evaluate this property against your entire operator database to find the best fits.</p>
                                    <button onClick={() => onFindMatches(property)} className="flex items-center bg-brand-blue text-white font-bold py-2 px-4 rounded-md shadow hover:bg-brand-blue/90">
                                        <SparklesIcon className="w-5 h-5 mr-2"/> Find Top Matches
                                    </button>
                                </div>
                            )}

                            {isMatching && (
                                <div className="text-center h-full flex flex-col justify-center items-center text-gray-500">
                                    <ArrowPathIcon className="w-8 h-8 animate-spin mb-4 text-brand-blue"/>
                                    <p className="font-semibold">Analyzing matches...</p>
                                    <p className="text-xs">The AI is cross-referencing all requirements.</p>
                                </div>
                            )}

                            {!isMatching && hasSearchedMatches && matches.length === 0 && (
                                 <div className="text-center h-full flex flex-col justify-center items-center text-gray-500">
                                    <p className="font-semibold">No Strong Matches Found</p>
                                    <p className="text-xs">The property did not meet the core criteria for any tracked operators.</p>
                                </div>
                            )}

                            {!isMatching && matches.length > 0 && (
                                <div className="space-y-3">
                                    {matches.map(match => {
                                        const { operator, confidenceScore, summary } = match;
                                        const categoryColor = OPERATOR_CATEGORY_COLORS[operator.category] || OPERATOR_CATEGORY_COLORS.Default;
                                        return (
                                            <div key={operator.id} className="bg-white p-3 rounded-lg border-l-4 shadow-sm" style={{ borderColor: categoryColor.accent.replace('bg-','') }}>
                                                <div className="flex justify-between items-start">
                                                    <div>
                                                        <p className={`text-xs font-bold uppercase tracking-wider ${categoryColor.text}`}>{operator.category}</p>
                                                        <h5 className="font-bold text-brand-blue">{operator.name}</h5>
                                                    </div>
                                                    <div className="text-right">
                                                        <p className="text-xs text-gray-500">Confidence</p>
                                                        <p className="text-2xl font-bold text-gray-800">{confidenceScore}%</p>
                                                    </div>
                                                </div>
                                                <p className="text-xs text-gray-600 mt-2 bg-gray-50 p-2 rounded border border-gray-200">{summary}</p>
                                                <button onClick={() => handleTrackDeal(match)} className="w-full mt-3 flex items-center justify-center bg-green-100 text-green-800 font-semibold py-2 px-4 rounded-md hover:bg-green-200">
                                                    <BriefcaseIcon className="w-4 h-4 mr-2"/> Track This Match
                                                </button>
                                            </div>
                                        );
                                    })}
                                </div>
                            )}
                         </div>
                    </div>
                </div>
            </div>
        </div>
    );
}

export const PropertySearchView: React.FC<PropertySearchViewProps> = ({ onAddToDealFlow, operators, requirements, serpApiKey }) => {
    const [location, setLocation] = useState('');
    const [radius, setRadius] = useState('5');
    const [type, setType] = useState('All');
    const [minSize, setMinSize] = useState('');
    const [maxSize, setMaxSize] = useState('');
    const [dateFilter, setDateFilter] = useState<string>('newest'); 
    
    const [results, setResults] = useState<IntelItem[]>([]);
    const [isLoading, setIsLoading] = useState(false);
    const [hasSearched, setHasSearched] = useState(false);
    const [error, setError] = useState<string | null>(null);
    
    const [selectedProperty, setSelectedProperty] = useState<IntelItem | null>(null);
    const [matches, setMatches] = useState<PotentialMatch[]>([]);
    const [isMatching, setIsMatching] = useState(false);
    const [hasSearchedMatches, setHasSearchedMatches] = useState(false);

    useEffect(() => {
        if (selectedProperty) {
            setMatches([]);
            setHasSearchedMatches(false);
        }
    }, [selectedProperty]);

    const handleFindMatchesInModal = async (property: IntelItem) => {
        setIsMatching(true);
        setHasSearchedMatches(true);
        setMatches([]);
        try {
            const results = await findOperatorMatches(property, operators, requirements);
            setMatches(results);
        } catch (e) {
            console.error(e);
            alert("Failed to find matches. The AI service may be unavailable or returned an unexpected format.");
        } finally {
            setIsMatching(false);
        }
    };

    const handleSearch = async (e: React.FormEvent) => {
        e.preventDefault();
        if (!serpApiKey) {
            setError("Please configure your SerpAPI Key in the Settings page to use Property Search.");
            return;
        }
        setIsLoading(true);
        setHasSearched(true);
        setError(null);
        setResults([]);
        try {
            const searchResults = await searchProperties(serpApiKey, {
                location,
                radius,
                type,
                minSize: minSize ? parseInt(minSize) : undefined,
                maxSize: maxSize ? parseInt(maxSize) : undefined,
                dateFilter,
            });
            setResults(searchResults);
        } catch (err) {
            setError(err instanceof Error ? err.message : 'An unknown error occurred during search.');
        } finally {
            setIsLoading(false);
        }
    };

    return (
        <div className="h-full flex flex-col">
            <div className="flex justify-between items-center mb-6">
                <div>
                    <h2 className="text-3xl font-bold text-gray-800">Property Search</h2>
                    <p className="text-gray-600 mt-1">Scan live property portals for on-market opportunities.</p>
                </div>
            </div>

            <form onSubmit={handleSearch} className="bg-white p-4 rounded-lg shadow-md border mb-6 flex flex-wrap items-end gap-4">
                <div className="flex-grow min-w-[200px]">
                    <label className="text-xs font-bold text-gray-600">Location</label>
                    <input type="text" required placeholder="e.g., Soho, London or W1" className="w-full p-2 border border-gray-300 rounded-md" value={location} onChange={e => setLocation(e.target.value)} />
                </div>
                 <div>
                    <label className="text-xs font-bold text-gray-600">Radius</label>
                    <select className="w-full p-2 border border-gray-300 rounded-md bg-white" value={radius} onChange={e => setRadius(e.target.value)}>
                        <option value="1">1 mile</option><option value="5">5 miles</option><option value="10">10 miles</option><option value="20">20 miles</option>
                    </select>
                </div>
                 <div>
                    <label className="text-xs font-bold text-gray-600">Property Type</label>
                    <select className="w-full p-2 border border-gray-300 rounded-md bg-white" value={type} onChange={e => setType(e.target.value)}>
                        <option value="All">All Commercial</option>
                        {Object.keys(PROPERTY_TYPE_MAPPING).map(t => <option key={t} value={t}>{t}</option>)}
                    </select>
                </div>
                 <div>
                    <label className="text-xs font-bold text-gray-600">Min Size (sqft)</label>
                    <input type="number" placeholder="500" className="w-full p-2 border border-gray-300 rounded-md" value={minSize} onChange={e => setMinSize(e.target.value)} />
                </div>
                 <div>
                    <label className="text-xs font-bold text-gray-600">Max Size (sqft)</label>
                    <input type="number" placeholder="5000" className="w-full p-2 border border-gray-300 rounded-md" value={maxSize} onChange={e => setMaxSize(e.target.value)} />
                </div>
                <div>
                    <label className="text-xs font-bold text-gray-600">Listed</label>
                    <select className="w-full p-2 border border-gray-300 rounded-md bg-white" value={dateFilter} onChange={e => setDateFilter(e.target.value)}>
                        <option value="newest">Newest</option><option value="24h">Last 24h</option><option value="7d">Last 7 days</option><option value="30d">Last 30 days</option>
                    </select>
                </div>
                <button type="submit" disabled={isLoading} className="bg-brand-blue text-white font-bold py-2 px-6 rounded-md shadow hover:bg-brand-blue/90 flex items-center h-10 disabled:bg-gray-400">
                    {isLoading ? <ArrowPathIcon className="w-5 h-5 mr-2 animate-spin" /> : <MagnifyingGlassIcon className="w-5 h-5 mr-2" />}
                    {isLoading ? 'Searching...' : 'Search'}
                </button>
            </form>

            <div className="flex-1 bg-gray-50 p-4 rounded-lg border shadow-inner overflow-y-auto">
                {isLoading && <div className="text-center text-gray-500">Scanning live portals...</div>}
                {error && <div className="text-center text-red-600">{error}</div>}
                {!isLoading && !error && hasSearched && results.length === 0 && <div className="text-center text-gray-500">No listings found matching your criteria.</div>}
                {!isLoading && !error && !hasSearched && (
                    <div className="text-center text-gray-400 pt-10">
                        <MagnifyingGlassIcon className="w-12 h-12 mx-auto mb-3 opacity-50"/>
                        <p>Enter your search criteria above to begin.</p>
                    </div>
                )}
                <div className="grid grid-cols-1 lg:grid-cols-2 2xl:grid-cols-3 gap-6">
                    {results.map(item => <PropertyCard key={item.id} item={item} onSelect={() => setSelectedProperty(item)} />)}
                </div>
            </div>
            
            {selectedProperty && (
                <PropertyDetailsModal 
                    property={selectedProperty} 
                    onClose={() => setSelectedProperty(null)} 
                    onAddToDealFlow={onAddToDealFlow}
                    matches={matches}
                    isMatching={isMatching}
                    hasSearchedMatches={hasSearchedMatches}
                    onFindMatches={handleFindMatchesInModal}
                />
            )}
        </div>
    );
};