import React, { useState } from 'react';
import { SparklesIcon, ArrowPathIcon } from './icons/Icons';
import type { IntelItem } from '../types';
import { analyzeSocialIntel } from '../services/geminiService';

interface SocialIntelViewProps {
    onAddIntel: (item: IntelItem) => void;
}

export const SocialIntelView: React.FC<SocialIntelViewProps> = ({ onAddIntel }) => {
    const [inputText, setInputText] = useState('');
    const [isAnalyzing, setIsAnalyzing] = useState(false);
    const [result, setResult] = useState<IntelItem | null>(null);
    const [error, setError] = useState<string | null>(null);

    const handleAnalyze = async () => {
        if (!inputText.trim()) return;
        
        setIsAnalyzing(true);
        setError(null);
        setResult(null);

        try {
            const intelItem = await analyzeSocialIntel(inputText);
            setResult(intelItem);
        } catch (err) {
            setError("Failed to analyze text. Please ensure your Gemini API key is configured and try again.");
        } finally {
            setIsAnalyzing(false);
        }
    };

    const handleAdd = () => {
        if (result) {
            onAddIntel(result);
            setInputText('');
            setResult(null);
        }
    };

    return (
        <div className="max-w-5xl mx-auto">
            <div className="flex items-center mb-6">
                <div className="bg-brand-blue p-2 rounded-lg mr-4 shadow-md">
                    <SparklesIcon className="w-8 h-8 text-white" />
                </div>
                <div>
                    <h2 className="text-3xl font-bold text-gray-800">Social & Portal Analyzer</h2>
                    <p className="text-gray-600">Manually extract structured data from any text source using AI.</p>
                </div>
            </div>

            <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
                {/* Left: Input Area */}
                <div className="bg-white p-6 rounded-lg shadow-lg flex flex-col">
                    <div className="mb-4 bg-blue-50 border border-blue-200 rounded p-3 text-sm text-blue-800 flex items-start">
                        <strong className="mr-2">How to use:</strong>
                        <span>For portals requiring a login (e.g., EGI, CoStar) or social feeds, copy the relevant property description and paste it below. The AI will structure it into a usable intel item.</span>
                    </div>
                    
                    <textarea
                        value={inputText}
                        onChange={(e) => setInputText(e.target.value)}
                        placeholder="Paste text from EGI, CoStar, LinkedIn, etc. here..."
                        className="w-full flex-grow p-4 border border-gray-300 rounded-lg focus:ring-2 focus:ring-brand-blue focus:border-transparent resize-none min-h-[200px]"
                    />

                    <div className="flex justify-end mt-4 pt-4 border-t">
                        <button
                            onClick={handleAnalyze}
                            disabled={isAnalyzing || !inputText.trim()}
                            className="bg-brand-blue text-white px-6 py-3 rounded-lg shadow-md hover:bg-brand-blue/90 transition-all flex items-center disabled:bg-gray-400 disabled:cursor-not-allowed"
                        >
                            {isAnalyzing ? (
                                <ArrowPathIcon className="w-5 h-5 mr-2 animate-spin" />
                            ) : (
                                <SparklesIcon className="w-5 h-5 mr-2" />
                            )}
                            {isAnalyzing ? 'Analyzing...' : 'Analyze Text'}
                        </button>
                    </div>
                </div>

                {/* Right: Result Area */}
                <div className="flex flex-col">
                     {error && (
                        <div className="bg-red-50 border border-red-200 text-red-700 p-4 rounded-lg mb-4">
                            {error}
                        </div>
                    )}

                    {result ? (
                        <div className="bg-white rounded-lg shadow-lg border-2 border-brand-gold overflow-hidden flex-grow flex flex-col">
                            <div className="bg-brand-gold/10 p-4 border-b border-brand-gold/20">
                                <h3 className="font-bold text-brand-blue">AI Extracted Opportunity</h3>
                            </div>
                            
                            <div className="p-6 flex-grow space-y-3">
                                <p><strong className="font-semibold">Headline:</strong> {result.headline}</p>
                                <p><strong className="font-semibold">Summary:</strong> {result.summary}</p>
                                <p><strong className="font-semibold">Property Type:</strong> {result.propertyType}</p>
                                <p><strong className="font-semibold">Size:</strong> {result.sizeSqFt?.toLocaleString()} sq ft</p>
                                <p><strong className="font-semibold">Confidence:</strong> {result.confidenceScore}%</p>
                            </div>

                            <div className="p-4 bg-gray-50 border-t flex justify-end">
                                <button 
                                    onClick={handleAdd}
                                    className="bg-green-600 text-white px-6 py-2 rounded-md shadow hover:bg-green-700 font-bold"
                                >
                                    Add to Intel Feed
                                </button>
                            </div>
                        </div>
                    ) : (
                        <div className="h-full border-2 border-dashed border-gray-300 rounded-lg flex items-center justify-center p-10 bg-gray-50 text-gray-400">
                            <p>Results will appear here...</p>
                        </div>
                    )}
                </div>
            </div>
        </div>
    );
};