import React from 'react';
import type { IntelLog } from '../types';

interface IntelLogViewProps {
    logs: IntelLog[];
}

export const IntelLogView: React.FC<IntelLogViewProps> = ({ logs }) => {
    return (
        <div className="bg-white p-6 rounded-lg shadow-lg">
            <h2 className="text-3xl font-bold text-gray-800 mb-6">Intel Log</h2>
            <p className="text-gray-600 mb-8">This log records the history of data refreshes and system status, including performance metrics.</p>

            <div className="overflow-x-auto">
                <table className="min-w-full bg-white">
                    <thead className="bg-gray-100 text-gray-600">
                        <tr>
                            <th className="text-left py-3 px-4 uppercase font-semibold text-sm">Timestamp</th>
                            <th className="text-left py-3 px-4 uppercase font-semibold text-sm">Status</th>
                            <th className="text-left py-3 px-4 uppercase font-semibold text-sm w-1/2">Message</th>
                            <th className="text-left py-3 px-4 uppercase font-semibold text-sm">Items Fetched</th>
                            <th className="text-left py-3 px-4 uppercase font-semibold text-sm">Latency (ms)</th>
                        </tr>
                    </thead>
                    <tbody className="text-gray-700">
                        {logs.map((log, index) => (
                            <tr key={index} className="border-b border-gray-200 hover:bg-gray-50">
                                <td className="py-3 px-4 whitespace-nowrap">{log.timestamp.toLocaleString()}</td>
                                <td className="py-3 px-4">
                                    <span className={`px-2 inline-flex text-xs leading-5 font-semibold rounded-full ${
                                        log.status === 'Success' ? 'bg-green-100 text-green-800' : 'bg-red-100 text-red-800'
                                    }`}>
                                        {log.status}
                                    </span>
                                </td>
                                <td className="py-3 px-4">{log.message}</td>
                                <td className="py-3 px-4 text-center font-medium">{log.itemCount ?? 'N/A'}</td>
                                <td className="py-3 px-4 text-right">{log.latencyMs ? `${log.latencyMs.toLocaleString()} ms` : 'N/A'}</td>
                            </tr>
                        ))}
                    </tbody>
                </table>
            </div>
             {logs.length === 0 && (
                <div className="text-center py-8 text-gray-500">
                    No log entries yet. Refresh the intel feed to start logging.
                </div>
            )}
        </div>
    );
};