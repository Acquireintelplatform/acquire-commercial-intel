import { create } from 'zustand';
import { persist } from 'zustand/middleware';
import type { View, Operator, Requirement, IntelItem, Alert, IntelLog, Settings, Deal, NewsItem, Agent, LeaseExpiry, ChatMessage, Viewing, CalendarEvent, Landlord, TeamMember, Source } from '../types';
import { initialOperators, initialRequirements, ALL_SOURCES, initialAgents, TEAM_MEMBERS, initialLandlords } from '../constants';
import { generateIntel, generateIndustryNews, generateLeaseExpiries } from '../services/geminiService';

const REFRESH_INTERVAL_SECONDS = 300; // 5 minutes

interface AppState {
    // Data
    intelFeed: IntelItem[];
    distressFeed: IntelItem[];
    industryNews: NewsItem[];
    operators: Operator[];
    requirements: Requirement[];
    agents: Agent[];
    deals: Deal[];
    logs: IntelLog[];
    leaseExpiries: LeaseExpiry[];
    chatHistory: ChatMessage[];
    viewings: Viewing[];
    calendarEvents: CalendarEvent[];
    landlords: Landlord[];
    sources: Source[];
    
    // Derived Data
    alerts: Alert[];

    // UI State
    isLoading: boolean;
    error: string | null;
    lastSync: Date | null;
    secondsUntilRefresh: number;
    
    // User/Settings
    currentUser: TeamMember;
    settings: Settings;

    // Actions
    fetchAllData: () => Promise<void>;
    processIntel: () => void;
    addOpportunityToDealFlow: (intelItem: IntelItem, operator: Operator, requirement: Requirement) => void;
    addAlertToDealFlow: (alertId: string) => void;

    // Setters
    setDeals: (deals: Deal[] | ((prev: Deal[]) => Deal[])) => void;
    setOperators: (operators: Operator[] | ((prev: Operator[]) => Operator[])) => void;
    setRequirements: (requirements: Requirement[] | ((prev: Requirement[]) => Requirement[])) => void;
    setAgents: (agents: Agent[] | ((prev: Agent[]) => Agent[])) => void;
    setLandlords: (landlords: Landlord[] | ((prev: Landlord[]) => Landlord[])) => void;
    setChatHistory: (history: ChatMessage[] | ((prev: ChatMessage[]) => ChatMessage[])) => void;
    setViewings: (viewings: Viewing[] | ((prev: Viewing[]) => Viewing[])) => void;
    setCalendarEvents: (events: CalendarEvent[] | ((prev: CalendarEvent[]) => CalendarEvent[])) => void;
    setSettings: (settings: Settings) => void;
}

export const useStore = create<AppState>()(
    persist(
        (set, get) => ({
            // --- STATE ---
            intelFeed: [],
            distressFeed: [],
            industryNews: [],
            operators: initialOperators,
            requirements: initialRequirements,
            agents: initialAgents,
            deals: [],
            logs: [],
            leaseExpiries: [],
            chatHistory: [],
            viewings: [],
            calendarEvents: [],
            landlords: initialLandlords,
            sources: ALL_SOURCES,
            alerts: [],
            isLoading: false,
            error: null,
            lastSync: null,
            secondsUntilRefresh: REFRESH_INTERVAL_SECONDS,
            currentUser: TEAM_MEMBERS[0],
            settings: {
                enabled: false, email: '', frequency: 'daily',
                // Essential
                serpApiKey: '7b794692c6c0c1d9b2b29905977ac7e5f89416969b1927c42cf2a252bbf98bc0',
                companiesHouseApiKey: '',
                googleMapsApiKey: '',
                
                // Data Portals
                egiUsername: '',
                egiPassword: '',
                coStarUsername: '',
                coStarPassword: '',
                propertyDataApiKey: '',
                
                // Listing Portals
                reallaApiKey: '',
                rightmoveApiKey: '',
                novaLocaApiKey: '',
                zooplaApiKey: '',
                loopnetApiKey: '',
            
                // News & Specialist
                insolvencyInsiderApiKey: '',
                businessSaleReportUsername: '',
                businessSaleReportPassword: '',
                propelUsername: '',
                propelPassword: '',
                mcaInsightUsername: '',
                mcaInsightPassword: '',
                theRequirementListApiKey: '',
            },
            
            // --- ACTIONS ---
            fetchAllData: async () => {
                set({ isLoading: true, error: null });
                const startTime = Date.now();
                const { settings } = get();

                if (!settings.serpApiKey) {
                    set({
                        error: "Missing SerpAPI Key. Please configure your SerpAPI key in Settings to fetch live data.",
                        isLoading: false,
                        logs: [{ timestamp: new Date(), status: 'Error', message: 'SerpAPI Key is missing.' }, ...get().logs],
                    });
                    return;
                }

                try {
                    const [intelResult, newsResult, expiryResult] = await Promise.allSettled([
                        generateIntel(settings.serpApiKey),
                        generateIndustryNews(settings.serpApiKey),
                        generateLeaseExpiries(settings.serpApiKey)
                    ]);

                    let itemCount = 0;
                    if (intelResult.status === 'fulfilled') {
                        const newIntelItems = intelResult.value;
                        itemCount += newIntelItems.length;
                        set(state => ({
                            intelFeed: newIntelItems.filter(item => item.sourceCategory !== 'Distress'),
                            distressFeed: newIntelItems.filter(item => item.sourceCategory === 'Distress')
                        }));
                    } else { throw intelResult.reason; }

                    if (newsResult.status === 'fulfilled') {
                        itemCount += newsResult.value.length;
                        set({ industryNews: newsResult.value });
                    } else { console.error("News fetch failed:", newsResult.reason); }

                    if (expiryResult.status === 'fulfilled') {
                        itemCount += expiryResult.value.length;
                        set({ leaseExpiries: expiryResult.value });
                    } else { console.error("Lease Expiry fetch failed:", expiryResult.reason); }


                    const latencyMs = Date.now() - startTime;
                    set(state => ({
                        logs: [{ timestamp: new Date(startTime), status: 'Success', message: `Fetched ${itemCount} total items.`, itemCount, latencyMs }, ...state.logs],
                        lastSync: new Date()
                    }));
                } catch (err) {
                    const errorMessage = err instanceof Error ? err.message : 'An unknown error occurred';
                    set(state => ({
                        error: errorMessage,
                        logs: [{ timestamp: new Date(startTime), status: 'Error', message: errorMessage, itemCount: 0, latencyMs: Date.now() - startTime }, ...state.logs],
                    }));
                } finally {
                    set({ isLoading: false, secondsUntilRefresh: REFRESH_INTERVAL_SECONDS });
                    get().processIntel(); // Process new intel
                }
            },

            processIntel: () => {
                const { intelFeed, distressFeed, operators, requirements } = get();
                const allIntel = [...intelFeed, ...distressFeed];
                const newAlerts: Alert[] = [];

                allIntel.forEach(item => {
                    operators.forEach(op => {
                        const operatorRegex = new RegExp(`\\b${op.name.replace(/ /g, '\\s?')}\\b`, 'i');
                        if (operatorRegex.test(item.headline) || operatorRegex.test(item.summary)) {
                            const req = requirements.find(r => r.operatorId === op.id);
                            if (req && item.confidenceScore >= 75 && !newAlerts.some(a => a.intel.id === item.id)) {
                                newAlerts.push({ id: `${item.id}-${op.id}`, intel: item, operator: op, requirement: req });
                            }
                        }
                    });
                });
                newAlerts.sort((a, b) => b.intel.confidenceScore - a.intel.confidenceScore);
                set({ alerts: newAlerts });
            },
            
            addOpportunityToDealFlow: (intelItem, operator, requirement) => {
                const { deals } = get();
                if (deals.some(d => d.intel.id === intelItem.id)) {
                    alert("This opportunity is already being tracked in Deal Flow.");
                    return;
                }
                const newDeal: Deal = {
                    id: `${intelItem.id}-${operator.id}`,
                    intel: intelItem, operator, requirement, status: 'New', notes: ''
                };
                set(state => ({
                    deals: [newDeal, ...state.deals],
                    alerts: state.alerts.filter(a => a.intel.id !== intelItem.id)
                }));
            },

            addAlertToDealFlow: (alertId) => {
                const alertToAdd = get().alerts.find(a => a.id === alertId);
                if (alertToAdd) {
                    get().addOpportunityToDealFlow(alertToAdd.intel, alertToAdd.operator, alertToAdd.requirement);
                }
            },
            
            // --- SETTERS ---
            setDeals: (updater) => set(state => ({ deals: typeof updater === 'function' ? updater(state.deals) : updater })),
            setOperators: (updater) => set(state => ({ operators: typeof updater === 'function' ? updater(state.operators) : updater })),
            setRequirements: (updater) => set(state => ({ requirements: typeof updater === 'function' ? updater(state.requirements) : updater })),
            setAgents: (updater) => set(state => ({ agents: typeof updater === 'function' ? updater(state.agents) : updater })),
            setLandlords: (updater) => set(state => ({ landlords: typeof updater === 'function' ? updater(state.landlords) : updater })),
            setChatHistory: (updater) => set(state => ({ chatHistory: typeof updater === 'function' ? updater(state.chatHistory) : updater })),
            setViewings: (updater) => set(state => ({ viewings: typeof updater === 'function' ? updater(state.viewings) : updater })),
            setCalendarEvents: (updater) => set(state => ({ calendarEvents: typeof updater === 'function' ? updater(state.calendarEvents) : updater })),
            setSettings: (newSettings) => set({ settings: newSettings }),
        }),
        {
            name: 'app_settings_persistence', // unique name
            partialize: (state) => ({ 
                settings: state.settings,
                deals: state.deals,
                operators: state.operators,
                requirements: state.requirements,
                agents: state.agents,
                landlords: state.landlords,
                chatHistory: state.chatHistory,
                viewings: state.viewings,
                calendarEvents: state.calendarEvents,
            }), // Persist settings and user-editable data
            version: 1, // Add versioning for future-proofing state changes
        }
    )
);

// --- Initialize Auto-Refresh Timer ---
// Initial check when the app loads
if (!useStore.getState().settings.serpApiKey) {
    useStore.setState({ error: "Welcome! Please go to Settings to add your SerpAPI key to begin fetching live data." });
}

setInterval(() => {
    useStore.setState(state => {
        if (state.secondsUntilRefresh <= 1) {
            // Only fetch if the key exists, preventing errors
            if (state.settings.serpApiKey) {
                console.log("Auto-refreshing data...");
                state.fetchAllData();
            }
            return { secondsUntilRefresh: REFRESH_INTERVAL_SECONDS };
        }
        return { secondsUntilRefresh: state.secondsUntilRefresh - 1 };
    });
}, 1000);