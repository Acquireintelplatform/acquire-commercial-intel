// In a real production app, this key would be stored securely on a backend server
// and accessed via an authenticated API, never exposed on the client.
// We are using a client-side JSONP approach here to bypass CORS without a proxy.
const SERP_API_BASE_URL = "https://serpapi.com/search.json";

interface SerpApiParams {
  [key: string]: any;
}

/**
 * A centralized function to call SerpAPI using JSONP to bypass CORS.
 * This involves dynamically creating a <script> tag.
 */
const callSerpApi = (apiKey: string, params: SerpApiParams): Promise<any> => {
    if (!apiKey) {
        return Promise.reject(new Error("SerpAPI key is not provided."));
    }

    return new Promise((resolve, reject) => {
        // Create a unique callback function name to avoid conflicts
        const callbackName = `serpApiCallback_${Date.now()}_${Math.floor(Math.random() * 1000)}`;

        const script = document.createElement('script');
        
        // Build the URL parameters
        const urlParams = new URLSearchParams({
            ...params,
            api_key: apiKey,
            output: 'jsonp',
            callback: callbackName,
        });

        script.src = `${SERP_API_BASE_URL}?${urlParams.toString()}`;

        // Define the global callback function that will be executed by the JSONP response
        (window as any)[callbackName] = (data: any) => {
            // Check for SerpAPI-specific errors in the response
            if (data && data.error) {
                reject(new Error(`SerpAPI Error: ${data.error}`));
            } else {
                resolve(data);
            }
            
            // Cleanup: remove the script tag and the global callback function
            try {
                delete (window as any)[callbackName];
                document.body.removeChild(script);
            } catch (e) {
                // Ignore errors during cleanup, the main job is done.
            }
        };

        // Handle network errors (e.g., if the script fails to load)
        script.onerror = (err) => {
            reject(new Error('Failed to load data from SerpAPI. Please check your network connection, ensure the SerpAPI key in Settings is valid, and that you have not exceeded your search quota.'));
            
            // Cleanup on error as well
            try {
                delete (window as any)[callbackName];
                document.body.removeChild(script);
            } catch(e) {
                // Ignore
            }
        };

        // Append the script to the body to initiate the request
        document.body.appendChild(script);
    });
};


/**
 * Performs a standard Google Search.
 * @param apiKey Your SerpAPI key.
 * @param query The search query.
 * @param location The geographical location for the search.
 * @returns The search results from SerpAPI.
 */
export const searchGoogle = (apiKey: string, query: string, location: string = "United Kingdom") => {
    const params = {
        engine: 'google',
        q: query,
        location: location,
        gl: 'uk',
        hl: 'en',
    };
    return callSerpApi(apiKey, params);
};

/**
 * Performs a Google News search.
 * @param apiKey Your SerpAPI key.
 * @param query The search query for news articles.
 * @param tbs Time-based search parameter (e.g., 'qdr:w' for past week).
 * @returns The news results from SerpAPI.
 */
export const searchGoogleNews = (apiKey: string, query: string, tbs?: string) => {
    const params: SerpApiParams = {
        engine: 'google',
        q: query,
        gl: 'uk',
        hl: 'en',
        tbm: 'nws', // Specifies news search
    };
    if (tbs) {
        params.tbs = tbs;
    }
    return callSerpApi(apiKey, params);
};

/**
 * Fetches details for a specific place using Google Maps search.
 * @param apiKey Your SerpAPI key.
 * @param query The name or address of the place to search for.
 * @returns The place details from SerpAPI.
 */
export const searchGoogleMapsPlace = async (apiKey: string, query: string) => {
    const params = {
        engine: 'google_maps',
        q: query,
        ll: '@51.5072,-0.1276,15z', // Default to London if no specific coords
        gl: 'uk',
        hl: 'en',
        type: 'search',
    };
    const results = await callSerpApi(apiKey, params);
    // Return the first, most relevant place result
    return results?.place_results || results?.local_results?.[0];
};