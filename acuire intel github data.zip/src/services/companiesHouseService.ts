import type { Operator } from '../types';

const API_BASE_URL = 'https://api.company-information.service.gov.uk';

interface CompanyProfile {
    company_name: string;
    company_number: string;
    company_status: string;
    accounts: {
        next_due: string;
        overdue: boolean;
        last_accounts: {
            made_up_to: string;
            type: string;
        };
    };
    date_of_creation: string;
}

export const getCompanyProfile = async (
    companyNumber: string,
    apiKey: string
): Promise<{ companyStatus: string; accountsStatus: string } | null> => {
    if (!companyNumber || !apiKey) {
        return null;
    }

    try {
        const response = await fetch(`${API_BASE_URL}/company/${companyNumber}`, {
            headers: {
                'Authorization': 'Basic ' + btoa(apiKey + ':')
            }
        });

        if (!response.ok) {
            if (response.status === 404) {
                 return { companyStatus: 'Not Found', accountsStatus: 'N/A' };
            }
            throw new Error(`Companies House API error: ${response.statusText}`);
        }

        const data: CompanyProfile = await response.json();

        let accountsStatus = 'Up to date';
        if (data.accounts?.overdue) {
            accountsStatus = 'OVERDUE';
        } else if (data.accounts?.next_due) {
            accountsStatus = `Due by ${new Date(data.accounts.next_due).toLocaleDateString()}`;
        }

        return {
            companyStatus: data.company_status || 'Unknown',
            accountsStatus: accountsStatus
        };

    } catch (error) {
        console.error(`Failed to fetch profile for company ${companyNumber}:`, error);
        return { companyStatus: 'API Error', accountsStatus: 'N/A' };
    }
};