export type View = 'DASHBOARD' | 'LIVE_ALERTS' | 'INTEL_FEEDS' | 'DISTRESS_FEEDS' | 'SOURCE_INDEX' | 'OPERATORS_MASTER' | 'REQUIREMENTS_MASTER' | 'INTEL_LOG' | 'SETTINGS' | 'DEAL_FLOW' | 'OPPORTUNITY_FINDER' | 'INDUSTRY_NEWS' | 'ACQUISITION_AGENTS' | 'SOCIAL_INTEL' | 'LANDLORDS_MASTER' | 'MAP_INDEX' | 'LEASE_EXPIRY_RADAR' | 'AI_ASSISTANT' | 'PROPERTY_SEARCH' | 'CALENDAR_VIEW';

export type OperatorCategory = 'Restaurant' | 'Coffee' | 'QSR' | 'Grocer' | 'Bakery' | 'Pubs' | 'Gyms' | 'Nursery' | 'Leisure' | 'Retail' | 'Mixed';

export interface Operator {
    id: string;
    name: string;
    category: OperatorCategory;
    logoUrl?: string;
    companyNumber?: string;
    companyStatus?: string;
    accountsStatus?: string;
    distressScore?: number;
    riskSummary?: string;
    lastRiskCheck?: string;
}

export interface Requirement {
    id: string;
    operatorId: string;
    sizeMin: number;
    sizeMax: number;
    locations: string[];
    useClass: string;
    notes: string;
}

export interface IntelItem {
    id: string;
    timestamp: string;
    source: string;
    sourceCategory?: 'General' | 'Distress' | 'Social';
    headline: string;
    summary: string;
    url: string;
    triggerKeywords: string[];
    confidenceScore: number;
    propertyType: string;
    sizeSqFt: number;
    useClass?: string;
    coordinates?: { lat: number; lng: number };
    dateListed?: string;
    agent?: { name: string; company: string; phone: string; email: string };
}

export interface NewsItem {
    id: string;
    timestamp: string;
    source: string;
    headline: string;
    summary: string;
    url: string;
    tags: string[];
}

export interface Alert {
    id: string;
    intel: IntelItem;
    operator: Operator;
    requirement: Requirement;
}

export type DealStatus = 'New' | 'Under Review' | 'Contacting Agent' | 'Offer Made' | 'Acquired' | 'Rejected';

export interface Deal {
    id: string;
    intel: IntelItem;
    operator: Operator;
    requirement: Requirement;
    status: DealStatus;
    notes: string;
    investmentMemo?: string;
}

export interface IntelLog {
    timestamp: Date;
    status: 'Success' | 'Error';
    message: string;
    itemCount?: number;
    latencyMs?: number;
}

export interface Source {
    name: string;
    category: 'Property Portal' | 'Distress Feed' | 'Industry News' | 'Expansion / Requirements' | 'Ownership / Mapping' | 'Supplementary' | 'Planning & Development' | 'Major Landlord / Transport Hub' | 'Property Agency';
}

export interface Agent {
    id: string;
    name: string;
    company: string;
    category: OperatorCategory;
    phone: string;
    email: string;
}

export interface Settings {
    enabled: boolean;
    email: string;
    frequency: 'instant' | 'hourly' | 'daily';
    // Essential
    serpApiKey?: string;
    companiesHouseApiKey?: string;
    googleMapsApiKey?: string;
    
    // Data Portals
    egiUsername?: string;
    egiPassword?: string;
    coStarUsername?: string;
    coStarPassword?: string;
    propertyDataApiKey?: string;
    
    // Listing Portals
    reallaApiKey?: string;
    rightmoveApiKey?: string;
    novaLocaApiKey?: string;
    zooplaApiKey?: string;
    loopnetApiKey?: string;

    // News & Specialist
    insolvencyInsiderApiKey?: string;
    businessSaleReportUsername?: string;
    businessSaleReportPassword?: string;
    propelUsername?: string;
    propelPassword?: string;
    mcaInsightUsername?: string;
    mcaInsightPassword?: string;
    theRequirementListApiKey?: string;
}

export interface CategoryColor {
    bg: string;
    text: string;
    border: string;
    accent: string;
}

export type CategoryColorMap = Record<OperatorCategory, CategoryColor> & { Default: CategoryColor };

export interface TeamMember {
    id: string;
    name: string;
    initials: string;
    title: string;
    email: string;
}

export interface Landlord {
    id: string;
    name: string;
    contactTeam: string;
    email: string;
    focusNotes: string;
    lastUpdated: string;
}

export interface Viewing {
    id: string;
    dealId: string;
    dealHeadline: string;
    operatorName: string;
    location: string;
    date: Date;
    attendeeId: string;
    notes: string;
}

export type CalendarEventType = 'Viewing' | 'Meeting' | 'Call' | 'Task';

export interface CalendarEvent {
    id: string;
    title: string;
    type: CalendarEventType;
    date: Date;
    notes?: string;
    dealId?: string;
    recipientEmail?: string;
}

export interface LeaseExpiry {
    id: string;
    address: string;
    timeRemaining: string;
    currentOccupier: { name: string };
    landlord: { name: string };
    propertyType: string;
    useClass: string;
    sizeSqFt?: number;
    coordinates?: { lat: number; lng: number };
}

export interface ChatMessage {
    id: string;
    role: 'user' | 'model';
    text: string;
    timestamp: Date;
}

export interface FootfallData {
    weekdayAverage: number;
    weekendAverage: number;
    categoryDensity: Record<string, number>;
    yoyVariance: number;
    dataSource: string;
    lastUpdated: string;
}

export interface PotentialMatch {
    operator: Operator;
    requirement: Requirement;
    confidenceScore: number;
    summary: string;
}